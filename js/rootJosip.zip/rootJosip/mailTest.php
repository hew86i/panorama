
<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary1.php" ?>
<?php header("Content-type: text/html; charset=utf-8")?>
<?php
	require_once '/usr/share/php/swift_required.php';
	
	opendb();
	
	//zakomentirano na 29.08.2014 - poradi zabelska od polyesterday
	//RunSQL("select alarmnewign()");
	
	$dsSendMail = query("select * from send_mail where flag='0'");
	
	while($row = pg_fetch_array($dsSendMail))
	{
		SendEmailDB($row["tomail"], $row["subject"], $row["body"]);
		RunSQL("update send_mail set flag='1' where id=".$row["id"]);
	}
	
	SendEmailDB('marjan@gps.mk', 'Test subj', 'Test body');
	
	function SendEmailDB($toemail, $subject, $body){
		$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
	  	->setUsername('sysinfo@gps.mk')
	 	->setPassword('geo!net123*$');
		$mailer = Swift_Mailer::newInstance($transport);
	
		$message = Swift_Message::newInstance($subject)
		  ->setFrom(array('sysinfo@gps.mk' => 'Geonet GPS Solutions'))
		  ->setBody('Geonet GPS')
		  ->addPart($body, 'text/html');
		
		$failedRecipients = array();
		$message->setTo($toemail);
		$mailer->send($message, $failedRecipients);
	}

	echo 1;
	closedb();
 ?>
