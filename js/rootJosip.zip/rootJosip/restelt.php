<?php
	$output = shell_exec('/etc/init.d/Phoenix_teltonika.sh restart');
?>
