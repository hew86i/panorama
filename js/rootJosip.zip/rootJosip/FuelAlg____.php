﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="./amcharts/amcharts.js" type="text/javascript"></script>
<link rel="stylesheet" href="./amcharts/style.css" type="text/css">

 <link rel="stylesheet" href="http:////code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
			lang = '<?php echo $cLang?>'
	</script>
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="/js/jquery.js"></script>
	
	<link href="/css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="/js/jquery-ui.js"></script>
    
<style>
	.hov123:hover{ opacity: 0.8; }
	#Operations {
		width	: 100%;
		height	: 50px;
	}
	#chartdiv {
		width	: 100%;
		height	: 300px;
	}
	#raphaelIgn {
		width	: 100%;
		height	: 200px;
		position: absolute;
		top: 70px;
		opacity: 0.3;
	}
</style>
</head>
	
<?php
	opendb();
	$cntHavaData = 0;
	$Allow = getPriv("distance", $uid);
	if ($Allow == false) echo header ('Location: ../permission/?l=' . $cLang);
		   
	$user_id = $uid; //154;//$_SESSION['user_id'];//nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
	$client_id = $cid;//154;// $_SESSION['client_id'];//nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
			    
	$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
	
	$pts = '';
	
	$vid = getQUERY("vid");
	$dt1 = getQUERY("dt1");
	$dt2 = getQUERY("dt2");
	if($vid == '')
	{
		$cid = 432;
		$vid = 2992;
		$dt1 = '2014-12-05';
		$dt2 = '2014-12-05';
	}
	$cid = dlookup("select clientid from vehicles where id=" . $vid);
	
	$dtraph = '';
	$ignraph = '';
	$datet = '';
	
	$diffsec = dlookup("select abs(datediff('d', '" . $dt1 . "', '" . $dt2 . "'))");
	$vkdist = dlookup("select getdistance('" . $dt1 . " 00:00:00', '" . $dt2 . " 23:59:59', " . $vid .")");
	/*$dsReconstruction1 = query("select datetime, ignition from rshortreport where vehicleid=" . $vid . " and Datetime>='" . $dt1 . " 00:00:00' and Datetime<='" . $dt2 . " 23:59:59' order by datetime asc");
   	while ($row1 = pg_fetch_array($dsReconstruction1)) {
		$dtraph .= "," . $row1["datetime"];
		$ignraph .= "," . $row1["ignition"];
	}*/

?>

<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="">
<div id="Operations">
	&nbsp;&nbsp;&nbsp;<span class="text1-">Почеток</span>&nbsp;&nbsp;&nbsp;<span class="text1-" style="margin-left: 86px;">Крај</span>&nbsp;&nbsp;&nbsp;<span class="text1-" style="margin-left: 136px;">Клиенти</span>&nbsp;&nbsp;&nbsp;<span class="text1-" style="margin-left: 123px;">Возила</span><br>
	&nbsp;&nbsp;&nbsp;<input type="text" class="text2" width="50px" height="25px" id="datepickerS" value="<?php echo $dt1?>">&nbsp;&nbsp;&nbsp;
	<input type="text" class="text2" width="50px" height="25px" id="datepickerE" value="<?php echo $dt2?>">
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<select id="clients" onchange="LoadVehicles()">
		<?php
			$dsph = query("select name, id from clients where id in (select clientid from vehicles where allowfuel='1') order by name asc");
			while($row = pg_fetch_array($dsph)) {
				$sel = '';
				if($row["id"] == $cid)
					$sel = 'selected';
				echo '<option value="' . $row["id"] . '" ' . $sel . '>' . $row["name"] . '</option>';
			}
		?>
	</select>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<select id="vehicles" onchange="LoadFuel()">
		<?php
		$dsph = query("select registration, code, id from vehicles where clientid=" . $cid . " and allowfuel='1' order by code::int asc");
		while($row = pg_fetch_array($dsph)) {
			$sel = '';
			if($row["id"] == $vid)
				$sel = 'selected';
			echo '<option onclick="LoadFuel()" value="' . $row["id"] . '" ' . $sel . '>' . $row["registration"] . '(' . $row["code"] . ')' . '</option>';
		}
		?>
	</select>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<span id="vkdist" class="text1-">
		Поминато растојание: <?=round($vkdist/1000)?> Km
	</span>
</div>
<!--div id="raphaelIgn"></div-->
<?php
if($diffsec <= 5) {
?>
<div id="chartdiv"></div>
<div id="scrolldiv" style="width:100%; height:70%; position: absolute; top: 300px; text-align:left; background-color:#fff; overflow-y:auto; overflow-x:hidden" class="corner5">
	
<?php
		
?>

<div id="testscr" style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%; overflow: auto;" class="corner5">
	<table align="center" width=90% class="text5" style="margin-top:10px; font-size: 11px;">
		<tr>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Реден број</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Гориво</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Гориво со алгоритам</strong></td>
			<td width="150px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Датум</strong></td>
			<td width="300px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Брзина</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Сателити</strong></td>
			<td width="100px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Мотор</strong></td>
			<td width="100px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Време разлика</strong></td>
		</tr>
	<?php
	$cnt = 0;
	$prevFA = -1;
	$dsph = query("select * from getreconstructionbeton1(" . $vid . ", '" . $dt1 . " 00:00:00','" . $dt2 . " 23:59:59')");
	while($row = pg_fetch_array($dsph)) {
		$pts .= $row["dt"] . '|' . $row["fuelalg"] . '|' . $row["_speed"] . '|' . $row["ignition"] . '#';
		$datet .= $row["dt"] . ',';
		if($row["ignition"] == '1') {
			$motor = 'Вклучен';
			$bgcolor = 'ADD6AD';
			$color = '363636';
		} else {
			$motor = 'Исклучен';
			$bgcolor = 'EEA6A6';
			$color = 'fff';
		}
		$id = '';
		if($prevFA != $row["fuelalg"]) {
			$cnt++;
			$id = 'row_' . ($cnt-1);
		}
			
		$prevFA = $row["fuelalg"];
		
		?>
		<tr id="<?=$id?>" class="hov123" style="background-color: #<?=$bgcolor?>; color: #<?=$color?>;">
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$cnt?></td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=round($row["fuel"], 2)?> L</td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["fuelalg"]?> L</td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["dt"]?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=round($row["_speed"])?> Km/h</td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["_status"]?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$motor?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["dtdiff"]?> секунди</td>
		</tr>
		<?php
		
	}
	?>
	</table>
</div><br><br>
</div>
<?php
}

closedb();
?>
</body>
</html>
<script>
	function LoadVehicles() {
		$('#vehicles').load('FuelAlgVeh.php?cid=' + $('#clients').val());
	}
	function LoadFuel() {
		window.location = "http://panorama.gps.mk/FuelAlg.php?vid=" + $('#vehicles').val() + "&dt1=" + $("#datepickerS").val() + "&dt2=" + $("#datepickerE").val();
	}
	$(document).ready(function () {
        var _h = $(document).height();
        $('#testscr').height(_h - 410);
        $( "#datepickerS" ).datepicker({
	    	dateFormat: 'yy-mm-dd',
	    	onSelect: function () {
	    		var val = $('#datepicker').val();
	            //window.location = "http://panorama.gps.mk/BufferChart.php?dt=" + val;
	        }
	    });
	    $( "#datepickerE" ).datepicker({
	    	dateFormat: 'yy-mm-dd',
	    	onSelect: function () {
	    		var val = $('#datepicker').val();
	            //window.location = "http://panorama.gps.mk/BufferChart.php?dt=" + val;
	        }
	    });
    });
	var datet = '<?=$datet?>';
	datet = datet.substring(0,datet.length-1);
	var datenew = '<?=$dtraph?>';
	var ignitionNew = '<?=$ignraph?>';
	
	var diffsec = '<?=$diffsec?>';
	
	var _PointCount = 0
	
	var metricUnit = "Km/h";
	var chart;
	var chartData = [];
	var _pts = '<?=$pts?>';
	_pts = _pts.split('#');
	if(parseInt(diffsec, 10) <= 5 && _pts.length > 5) {
		AmCharts.ready(function () {
			generateChartData1();
			createSerialChart();
		});
	} else {
		alert('Избраниот период е многу голем или нема податоци!');
	}
	function generateRect1(_start, _end)
	{
		$('#raphaelIgn').html('');
		dt = datenew.split(",");
		var tempEnd = datet.split(",")[datet.split(",").length-2].split(".")[0];
		var tempStart = datet.split(",")[0].split(".")[0];
		if(tempEnd.split(".")[0] == _end.split(".")[0] && tempStart.split(".")[0] == _start.split(".")[0])
		{
			var startTime = getSeconds(_start.split(" ")[1]);
	        var endTime = getSeconds(_end.split(" ")[1]);
	        
	        var x = startTime;
	        var proc = 100 / (endTime-startTime);
	        
	        for (var i = 1; i < dt.length; i++) {
			
				var sec = getSeconds(dt[i].split(" ")[1].split(":")[0] +":"+ dt[i].split(" ")[1].split(":")[1] +":"+ dt[i].split(" ")[1].split(":")[2].split(".")[0]);
				var w = (sec-x) * proc;
				
				//var clr = "#89A54E";
				var clr = "#1aa815";
				if (ignitionNew.split(",")[i] == "1")
					var clr = "#db2f24";
				
				var _div = '<div style="display:block; width: '+w+'%; background-color:'+clr+'; height: 100%; float: left"></div>';
				$('#raphaelIgn').html($('#raphaelIgn').html() + _div);
				x = sec;
			}
			if(x < endTime)
			{
				var w = (endTime-x) * proc;
				var clr = "#1aa815";
				if (ignitionNew.split(",")[i-1] == "0")
					var clr = "#db2f24";
					//var clr = "#9E312E";

				var _div = '<div style="display:block; width: '+w+'%; background-color:'+clr+'; height: 100%; float: left"></div>';
				$('#raphaelIgn').html($('#raphaelIgn').html() + _div);
			}
		} else
		{
			var startTime = getSeconds(_start.split(" ")[1]);
	        var endTime = getSeconds(_end.split(" ")[1]);
	        
			var _s = 1;
			var _e = dt.length-1;
			var startBool = true;
			
			for (var i = 1; i < dt.length; i++) {
				if(startTime < getSeconds(dt[i].split(" ")[1]) && startBool)
				{
					_s = i;
					startBool = false;
				}
				if(getSeconds(dt[i].split(" ")[1]) > endTime)
				{
					_e = i-1;
					break;
				}
			}
	        
	        var x = startTime;
	        var proc = 100 / (endTime-startTime);
	        if(!startBool)
	        {
				for (var i = _s; i <= _e; i++) {
					
					var sec = getSeconds(dt[i].split(" ")[1].split(":")[0] +":"+ dt[i].split(" ")[1].split(":")[1] +":"+ dt[i].split(" ")[1].split(":")[2].split(".")[0]);
					var w = (sec-x) * proc;
					
					//var clr = "#89A54E";
					var clr = "#1aa815";
					if (ignitionNew.split(",")[i] == "1")
						var clr = "#db2f24";
					var _div = '<div style="display:block; width: '+w+'%; background-color:'+clr+'; height: 100%; float: left"></div>';
					$('#raphaelIgn').html($('#raphaelIgn').html() + _div);
					
					x = sec;
				}
			}
			if(x < endTime)
			{
				var w = (endTime-x) * proc;
				var clr = "#1aa815";
				if (ignitionNew.split(",")[i-1] == "0")
					var clr = "#db2f24";
					//var clr = "#9E312E";

				var _div = '<div style="display:block; width: '+w+'%; background-color:'+clr+'; height: 100%; float: left"></div>';
				$('#raphaelIgn').html($('#raphaelIgn').html() + _div);
			} 
		}
	}
	function generateChartData1()
	{
	    var dt = [];
	    dt[0] = _pts[0].split("|")[0];
	    //var firstDate = new Date(dt[0].split(" ")[0].split("-")[0], parseInt(dt[0].split(" ")[0].split("-")[1], 10)-1, dt[0].split(" ")[0].split("-")[2], dt[0].split(" ")[1].split(":")[0], dt[0].split(" ")[1].split(":")[1], dt[0].split(" ")[1].split(":")[2].split(".")[0]);
	    for (var i = 0; i < _pts.length - 1; i++) {
	    	if(_pts[i].split('|')[1] != '') {
	    		if(i == 0 || _pts[i].split('|')[1] != _pts[i-1].split('|')[1]) {
			    	dt[i] = _pts[i].split("|")[0];
			    	var newDate = new Date(dt[i].split(" ")[0].split("-")[0], parseInt(dt[i].split(" ")[0].split("-")[1], 10)-1, dt[i].split(" ")[0].split("-")[2], dt[i].split(" ")[1].split(":")[0], dt[i].split(" ")[1].split(":")[1], dt[i].split(" ")[1].split(":")[2].split(".")[0]);
					if(i > 0)
					{
						if(parseInt(_pts[i].split("|")[2], 10) > 7 && parseInt(_pts[i-1].split("|")[2], 10) <= 7)
						{
							var _speed = 0;
						}
						else
							var _speed = _pts[i].split("|")[2];
					}
					putInChartData1(i, newDate, "Speed", "Fuel", _speed, _pts[i].split("|")[1]);
				}
			}
		}
	}
	function putInChartData1(_i, dt, vehid1, vehid2, value1, value2)
	{
		var obj = {};
		obj["date"] = dt;
		//obj[vehid1]= value1;
		
		// chartData[chartData.length-1].Fuel
		//if(parseInt(value2, 10) > 3)
		//{
			obj[vehid2]= value2;
		//}
		chartData.push(obj);
	}
	function padStr(i) {
	    return (i < 10) ? "0" + i : "" + i;
	}
	function moveChartNew(_i)
	{
		if(parseInt(_i, 10) > 1)
			if(_pts[_i-1].split("|")[0].split(".")[0] == _pts[_i].split("|")[0].split(".")[0])
				return false;
		
		chart.chartCursor.showCursorAt(new Date(_pts[_i].split("|")[0].split(" ")[0].split("-")[0], parseInt(_pts[_i].split("|")[0].split(" ")[0].split("-")[1],10)-1, parseInt(_pts[_i].split("|")[0].split(" ")[0].split("-")[2],10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[0], 10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[1], 10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[2], 10)));
		if(chart.chartCursor.categoryBalloon.set == null)
		{
			_i++;
			_PointCount = _i;
			IndexRec = _i;
			//moveChartNew(_i);
			//PlayForwardNewRec();
		}
		if(_pts[_i].split("|")[3] == "1")
		{
			
			chart.chartCursor.set.node.children[0].attributes[5].value = "#008000";
			if(chart.chartCursor.categoryBalloon.set != null)
			{
				chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#008000';
			}
		} else
		{
			chart.chartCursor.set.node.children[0].attributes[5].value = '#CC0000'
			if(chart.chartCursor.categoryBalloon.set != null)
			{
				chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#CC0000';
			}
		}
	}
	function getSeconds(strTime){
        var strTimes = strTime.split(":")
        var h = 0
        var m = 0
        var s = 0


        if(strTimes[0].charAt(0) == 0 && strTimes[0].charAt(0) == '0'){
            h = parseInt(strTimes[0].charAt(1), 10);
        }
        else{
            h = parseInt(strTimes[0], 10);
        }
        if(strTimes[1].charAt(0) == 0 && strTimes[1].charAt(0) == '0'){
            m = parseInt(strTimes[1].charAt(1), 10);
        }
        else{
            m = parseInt(strTimes[1], 10);
        }
        if(strTimes[2].charAt(0) == 0 && strTimes[2].charAt(0) == '0'){
            s = parseInt(strTimes[2].charAt(1), 10);
        }
        else{
            s = parseInt(strTimes[2], 10);
        }
        var sec = h*3600 + m*60 + s
        return sec
    }
	function moveChartFromHide(_i)
	{
		if(String(chart.chartCursor.previousMousePosition) != "NaN")
			chart.chartCursor.showCursorAt(new Date(_pts[_i].split("|")[0].split(" ")[0].split("-")[0], parseInt(_pts[_i].split("|")[0].split(" ")[0].split("-")[1],10)-1, parseInt(_pts[_i].split("|")[0].split(" ")[0].split("-")[2],10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[0], 10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[1], 10), parseInt(_pts[_i].split("|")[0].split(" ")[1].split(":")[2], 10)));
		else
			IndexRec = 1;
		if(_pts[_i].split("|")[3] == "1")
		{
			chart.chartCursor.set.node.children[0].attributes[5].value = "#008000";
			if(chart.chartCursor.categoryBalloon.set != null)
			{
				chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#008000';
			}
		} else
		{
			chart.chartCursor.set.node.children[0].attributes[5].value = '#CC0000'
			if(chart.chartCursor.categoryBalloon.set != null)
			{
				chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#CC0000';
			}
		}
	}
	function goToPointIdxNew(_i)
	{
		if(_i != undefined)
		{
			if(_pts[_i].split("|")[3] == "1")
			{
				chart.chartCursor.set.node.children[0].attributes[5].value = "#008000";
				if(chart.chartCursor.categoryBalloon.set != null)
				{
					chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#008000';
				}
			} else
			{
				chart.chartCursor.set.node.children[0].attributes[5].value = '#CC0000'
				if(chart.chartCursor.categoryBalloon.set != null)
				{
					chart.chartCursor.categoryBalloon.set.node.children[0].attributes[7].value = '#CC0000';
				}
			}
			
			_PointCount = _i;
			IndexRec = _PointCount;
			var container = $('#testscr'),
		    scrollTo = $('#row_'+_PointCount);
		    var _h = $(document).height();
			$('#testscr').scrollTop(parseInt(scrollTo.offset().top - container.offset().top + container.scrollTop() - _h/4, 10));
			$('.hov123').css({opacity: 1})
			$('#row_'+_PointCount).css({opacity: 0.5})
		}
	}
	function createSerialChart()
	{
		// SERIAL CHART    
	    chart = new AmCharts.AmSerialChart();
	    chart.pathToImages = "./amcharts/images/";
	    chart.zoomOutButton = {
	        backgroundColor: '#ff0000',
	        backgroundAlpha: 0.15
	    };
	    chart.zoomOutText = 'Zoom Out';
	    chart.dataProvider = chartData;
	    chart.categoryField = "date";
	
	    // listen for "dataUpdated" event (fired when chart is inited) and call zoomChart method when it happens
	    //chart.addListener("dataUpdated", zoomChart);
	
	    // AXES
	    // category                
	    var categoryAxis = chart.categoryAxis;
	    categoryAxis.parseDates = true; // as our data is date-based, we set parseDates to true
	    categoryAxis.minPeriod = "ss"; // our data is daily, so we set minPeriod to DD
	    categoryAxis.dashLength = 2;
	    categoryAxis.gridAlpha = 0.15;
	    categoryAxis.axisColor = "#DADADA";
	
	    // first value axis (on the left)
	    var valueAxis1 = new AmCharts.ValueAxis();
	    valueAxis1.axisThickness = 2;
	    valueAxis1.gridAlpha = 0.1;
	    //valueAxis1.gridColor = "#FF6600";
	    chart.addValueAxis(valueAxis1);
		valueAxis1.addListener('axisChanged',
	        function (event) {
	        	//$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
	   			//$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
	   			
	   			//if(Browser() != "Chrome" && Browser() != "Safari")
					chart.chartCursor.set.node.children[0].attributes[3].value = "3";
				//else
					//chart.chartCursor.set.node.childNodes[0].attributes[3].value = "3";
	        });
		
		// second value axis (on the right) 
	    var valueAxis2 = new AmCharts.ValueAxis();
	    valueAxis2.position = "right"; // this line makes the axis to appear on the right
	    valueAxis2.axisColor = "#FCD202";
	    valueAxis2.gridAlpha = 0.1;
	    //valueAxis2.gridColor = "#FCD202";
	    valueAxis2.axisThickness = 2;
	    chart.addValueAxis(valueAxis2);
		valueAxis2.addListener('axisChanged',
	        function (event) {
	        	//$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
	   			//$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
	   			
	   			//if(Browser() != "Chrome" && Browser() != "Safari")
					chart.chartCursor.set.node.children[0].attributes[3].value = "3";
				//else
					//chart.chartCursor.set.node.childNodes[0].attributes[3].value = "3";
	        });
	
		// GUIDES are vertical (can also be horizontal) lines (or areas) marking some event.
	    
	    // GRAPHS
	    // first graph
	    var graph1 = new AmCharts.AmGraph();
	    graph1.valueAxis = valueAxis1; // we have to indicate which value axis should be used
	    graph1.type = "smoothedLine"; // this line makes the graph smoothed line.
	    graph1.lineColor = "#387CB0";
	    graph1.bullet = "round";
	    graph1.bulletSize = 7;
	    graph1.lineThickness = 2;
	    graph1.title = 'Брзина';
	    graph1.valueField = "Speed";
	    graph1.balloonText = "[[value]] " + metricUnit;
	    graph1.legendValueText = "[[value]] " + metricUnit;
	    graph1.hideBulletsCount = 130;
	    //chart.addGraph(graph1);
		
		// second graph                
	    var graph2 = new AmCharts.AmGraph();
	    //graph2.lineColor = "#000000";
	    graph2.valueAxis = valueAxis2; // we have to indicate which value axis should be used
	    graph2.type = "smoothedLine"; // this line makes the graph smoothed line.
	    graph2.bullet = "round";
    	graph2.bulletSize = 7;
    	graph2.connect = false;
    	graph2.lineThickness = 2;
	    graph2.title = 'Гориво';
	    graph2.valueField = "Fuel";
	    graph2.balloonText = "[[value]] L";
	    graph2.legendValueText = "[[value]] L";
	    graph2.hideBulletsCount = 100;
	    
	    chart.addGraph(graph2);
	
	    // CURSOR
	    var chartCursor = new AmCharts.ChartCursor();
	    chartCursor.cursorPosition = "start";
	    chartCursor.categoryBalloonDateFormat = "JJ:NN:SS";
	    chart.addChartCursor(chartCursor);
		
		
		
		chart.chartCursor.addListener("changed", function(event){
			if(event.index != undefined)
				goToPointIdxNew(event.index);
		});
		chart.chartCursor.addListener("onHideCursor", function(event){
			if(_PointCount != undefined && _PointCount != 0 && _PointCount != 1)
			{
				_i = _PointCount;
				moveChartFromHide(_i);			
	    		goToPointIdxNew(_i);
	    	}
		});
		
	    // SCROLLBAR
	    var chartScrollbar = new AmCharts.ChartScrollbar();
	    chartScrollbar.graph = graph2;
	    chartScrollbar.scrollbarHeight = 30;
	    chartScrollbar.autoGridCount = true;
	    chartScrollbar.color = "#000000";
	    //chartScrollbar.gridColor = "#00FFFF";
	    chart.addChartScrollbar(chartScrollbar);
	
	    // LEGEND
	    var legend = new AmCharts.AmLegend();
	    legend.marginLeft = 110;
	    legend.markerType = "circle";
	    chart.addLegend(legend);
		
		/*chart.addListener('zoomed',
	        function (event) {
	        	var datetimeStr1 = event.startDate;
			   	var datetimeStr2 = event.endDate;
			   	var start = padStr(datetimeStr1.getFullYear()) + "-" +
	                  padStr(1 + datetimeStr1.getMonth()) + "-" +
	                  padStr(datetimeStr1.getDate()) + " " +
	                  padStr(datetimeStr1.getHours()) + ":" +
	                  padStr(datetimeStr1.getMinutes()) + ":" +
	                  padStr(datetimeStr1.getSeconds());
			   	var end = padStr(datetimeStr2.getFullYear()) + "-" +
	                  padStr(1 + datetimeStr2.getMonth()) + "-" +
	                  padStr(datetimeStr2.getDate()) + " " +
	                  padStr(datetimeStr2.getHours()) + ":" +
	                  padStr(datetimeStr2.getMinutes()) + ":" +
	                  padStr(datetimeStr2.getSeconds());
			   	//alert(start + "  " + end)
			   	generateRect1(start, end);
        });*/

		chart.write("chartdiv");
		
		chart.chartCursor.set.node.children[0].attributes[3].value = "3";

    	moveChartNew(1);
    	goToPointIdxNew(1);
    
		/*var datetimeStr1 = chart.startDate;
	   	var datetimeStr2 = chart.endDate;
	   	var start = padStr(datetimeStr1.getFullYear()) + "-" +
	          padStr(1 + datetimeStr1.getMonth()) + "-" +
	          padStr(datetimeStr1.getDate()) + " " +
	          padStr(datetimeStr1.getHours()) + ":" +
	          padStr(datetimeStr1.getMinutes()) + ":" +
	          padStr(datetimeStr1.getSeconds());
	   	var end = padStr(datetimeStr2.getFullYear()) + "-" +
	          padStr(1 + datetimeStr2.getMonth()) + "-" +
	          padStr(datetimeStr2.getDate()) + " " +
	          padStr(datetimeStr2.getHours()) + ":" +
	          padStr(datetimeStr2.getMinutes()) + ":" +
	          padStr(datetimeStr2.getSeconds());
	   	//alert(start + "  " + end)
	   	$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
	   	$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
	   	generateRect1(start, end);*/
	   	
	   	window.onresize = resizeChart();
	}
	function resizeChart()
	{
		var chartDiv = document.getElementById("chartdiv");
		//chartDiv.style.height=document.documentElement.clientHeight+"px";
		
		//$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
		//$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
		
	}
	window.onresize = resizeChart;
	
</script>