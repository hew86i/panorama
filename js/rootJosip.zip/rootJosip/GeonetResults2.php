﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
        <style>
			.textQ {
				font-family:Arial, Helvetica, sans-serif; 
				font-size:24px; 
				font-weight:normal; 
				color:#ffffff; 1
				text-decoration: none
			}
  			td {
  				border:1px solid #ffffff;
  			}
        </style>
</head>
	<script>
		lang = 'mk'
	</script>
	
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.customQ.css">	
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/iScroll.js"></script>
    <script src="./js/jquery-ui.js"></script>
    
    <script type="text/javascript">
	    function SetHeightLiteG(){
			var _h = document.body.offsetHeight;
		    $('#divRes').css({ height: (_h - 500) + 'px' });
		}
	</script>
    	
<?php
    opendb();
	
	$dsCandidates = query("select *, (select geonetgetresults(id)) totalres from geonetcandidate order by typetest desc, totalres desc");
	//$dsCandidates = query("select *, (select geonetgetresults(id)) totalres from geonetcandidate order by id asc");
	$dsTotalQ = query("select count(*) c, qgroupnum from geonetquestions group by qgroupnum order by qgroupnum asc");
	//$totalQ = dlookup("select count(*) from geonetquestions");
	
	$totalCss = pg_fetch_result($dsTotalQ, 0, "c");
	$totalJs = pg_fetch_result($dsTotalQ, 1, "c");
	$totalPhp = pg_fetch_result($dsTotalQ, 2, "c");
	$totalNet = pg_fetch_result($dsTotalQ, 3, "c");
	$totalPg = pg_fetch_result($dsTotalQ, 4, "c");
	$totalIq = pg_fetch_result($dsTotalQ, 5, "c");
?>

<body style="margin:0px 0px 0px 0px; overflow: auto; padding:0px 0px 0px 0px" onResize="SetHeightLiteG()">
	<div id="divRes" style="width:100%; height:100%; color:#ffffff; padding-top:20px;" class="textQ">
		<table width=90% style="margin:0 auto; ">
			<tr height=40px style="font-weight:bold">
				<td width=4% align="left" class="text2" style="padding-left:7px; color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Р. бр.</td>
				<td width=18% align="left" class="text2" style="padding-left:7px; color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Име на кандидат</td>
				<?php
				/*for ($i=1; $i<=10; $i++) {
				?>
				<td align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Прашање <?=$i?></td>
				<?php
				}*/
				?>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">CSS (<?=$totalCss?>)</td>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Java Script (<?=$totalJs?>)</td>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">PHP (<?=$totalPhp?>)</td>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">.Net (<?=$totalNet?>)</td>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Postgres (<?=$totalPg?>)</td>
				<td width=10% align="center" class="text2" style="color:#fff; background-color:#f7962b; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">IQ (<?=$totalIq?>)</td>
				
				<td width=1% align="center" class="text2" style="">&nbsp</td>
				<td width=17% align="center" class="text2" style="color:#fff; background-color:#ff6633; border:1px dotted #ff6633; color:#153B75; font-size: 12px; font-weight: bold">Резултати</td>
			</tr>
		
			<?php
			$cntC = 1;
			
			while($drCandidate = pg_fetch_array($dsCandidates)) {
				if ($drCandidate["typetest"] == ".Net") {
					$totalQ = dlookup("select count(*) from geonetquestions where qgroup <> 'PHP'");
				}
				if ($drCandidate["typetest"] == "PHP") {
					$totalQ = dlookup("select count(*) from geonetquestions where qgroup <> '.Net'");
				}
							
				$css = 0;
				$js = 0;
				$php = 0;
				$net = 0;
				$pg = 0;
				$iq = 0;
				$notQ = 0;
				$totalTime = 0;
				
				for ($i=1; $i <= 36; $i++) {
					$totalTime += nnull($drCandidate["answertime".$i],0);
				}
				$cntTrue = 0;


$currQ = dlookup("select geonetlastq(".$drCandidate["id"].");");
if ($currQ == -1) $currQ = "Сите";

			?>
			<tr height=30px>
				<td align="left" class="text2" style="padding-left:7px; font-size: 12px; font-weight: bold; border:1px dotted #2f5185;"><?=$cntC?></td>
				<td align="left" class="text2" style="padding-left:7px; font-size: 12px; font-weight: bold; border:1px dotted #2f5185;"><?=$drCandidate["fullname"] . " "?>(<font style="font-weight:normal;"><?= $currQ?>)</font>
					<br><font style="font-style: italic; font-weight: normal; color: #ff6600"><?=$drCandidate["typetest"]?></font></td>
				<?php
				for ($i=1; $i<=36; $i++) {
				?>
				<!--td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;"-->
					<?php
					$Ans = query("select * from geonetquestions where num = " . $i);
					$trueAns = pg_fetch_result($Ans, 0, "trueanswer");// dlookup("select trueanswer from geonetquestions where num = " . $i);
					$AnsGr = pg_fetch_result($Ans, 0, "qgroupnum");
										
					$a = "<img height=15px  src='./images/stikla3.png' height=20px border='0' align='absmiddle' />";
					if (nnull($drCandidate["answer".$i], "/") == "/") {
						if ($drCandidate["typetest"] == "PHP") {							
							if (($i >= 1 && $i < 18) || ($i > 26 && $i <= 36)) {
								$notQ++;
							}	
						}
						if ($drCandidate["typetest"] == ".Net") {
							if (($i >= 1 && $i < 13) || ($i > 17 && $i <= 36)) {
								$notQ++;
							}	
						}
					}
					if ($drCandidate["answer".$i] == $trueAns) {
						$a = "<img height=15px src='./images/stikla2.png' border='0' align='absmiddle' />";
						if ($AnsGr == 1) $css++;
						if ($AnsGr == 2) $js++;
						if ($AnsGr == 3) $php++;
						if ($AnsGr == 4) $net++;
						if ($AnsGr == 5) $pg++;
						if ($AnsGr == 6) $iq++;
						$cntTrue++;
					}
					//echo $a . " (" . Sec2Str($drCandidate["answertime".$i]) . ")";
					?>
				<!--/td-->
				<?php	
				}
				if ($totalCss == $css) $colCss = "green"; else $colCss ="red";
				if ($totalJs == $js) $colJs = "green"; else $colJs ="red";
				if ($totalPhp == $php) $colPhp = "green"; else $colPhp ="red";
				if ($totalNet == $net) $colNet = "green"; else $colNet ="red";
				if ($totalPg == $pg) $colPg = "green"; else $colPg ="red";
				if ($totalIq == $iq) $colIq = "green"; else $colIq ="red";
				?>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">Точни: <b><?=$css?></b> | Оцена: <b><?= round(5/$totalCss*$css,1)?></b></td>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">Точни: <b><?=$js?></b> | Оцена: <b><?= round(5/$totalJs*$js,1)?></b></td>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">
					<?php
					if ($drCandidate["typetest"] == "PHP") {
					?>
					Точни: <b><?=$php?></b> | Оцена: <b><?= round(5/$totalPhp*$php,1)?></b>
					<?php	
					} else echo "/";
					?>
				</td>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">
					<?php
					if ($drCandidate["typetest"] == ".Net") {
					?>
					Точни: <b><?=$net?></b> | Оцена: <b><?= round(5/$totalNet*$net,1)?></b
					<?php	
					} else echo "/";
					?>
					
				</td>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">Точни: <b><?=$pg?></b> | Оцена: <b><?= round(5/$totalPg*$pg,1)?></b</td>
				<td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;">Точни: <b><?=$iq?></b> | Оцена: <b><?= round(5/$totalIq*$iq,1)?></b</td>
				<td align="center" class="text2" style="">&nbsp;</td>
				<td align="center" class="text2" style="font-size: 12px; background-color:#E5E3E3; border:1px dotted #2f5185;">
					<?php
					if ($drCandidate["timeexpired"] == '0') {
						?>
						Време на решавање: <b><?= Sec2Str($totalTime)?></b><br>Точни: <b><?=$cntTrue ." / ".$totalQ?></b> | Оцена: <b><?= round(5/$totalQ*$cntTrue,1)?></b>
						<?php
					} else {
						?>
						<b>Истечено време</b> - Неодговорени: <b><?=$notQ?></b><br>Точни: <b><?=$cntTrue ." / ".$totalQ?></b> | Оцена: <b><?= round(5/$totalQ*$cntTrue,1)?></b>
						<?php
					}
					?>
				</td>
			</tr>	
			
				
					<?php	
			//echo $css . " " . $js . " " . $php . " " . $net . " " . $pg . " " . $iq;	
			$cntC++; 
			}
			?>
							
		</table>
		<br>
	</div>
	


    <?php
    closedb();
    ?>
    
</body>
<script type="text/javascript">
SetHeightLiteG();
setInterval(function(){ location.reload();}, 5000);
</script>
</html>


