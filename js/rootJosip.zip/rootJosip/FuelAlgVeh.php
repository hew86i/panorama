﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php
	opendb();
	$cid = getQUERY("cid");
	$str = '';
	$dsph = query("select registration, code, id from vehicles where clientid=" . $cid . " and allowfuel='1' order by code::int asc");
	while($row = pg_fetch_array($dsph)) {
		$str .= '<option value="' . $row["id"] . '">' . $row["registration"] . '(' . $row["code"] . ')' . '</option>';
	}
	echo $str;
	closedb();
?>

