﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php

	//brisenje fajlovi od savePDF postari od 1 den
	$dir = "/var/www/panorama/savePDF/";
	$dirHandle = opendir($dir); 
	$yesterday = addToDate(now(), -1, "days");
	
	while ($file = readdir($dirHandle)) { 
	    if(!is_dir($file)) {
			$lastModified = date ("Y-m-d H:i:s", filemtime($dir . $file));
			if ($lastModified < $yesterday) {
				echo $dir . $file . "<br>";
				unlink($dir . $file);
			}
	    }
	}
	closedir($dirHandle);
	
	//brisenje fajlovi od home/Logs postari od 1 mesec
	$dir1 = "/home/Logs/";
	$dirHandle1 = opendir($dir1); 
	$lastMonth = addToDate(now(), -1, "month");
	
	while ($file1 = readdir($dirHandle1)) {		 
	    if(is_file($dir1 . $file1)) {
			$lastModified1 = date ("Y-m-d H:i:s", filemtime($dir1 . $file1));
			if ($lastModified1 < $lastMonth) {
				echo $dir1 . $file1 . "<br>";
				unlink($dir1 . $file1);
			}
	    }
	}
	closedir($dirHandle1);
		
	//brisenje fajlovi od home/Logs/schedulerNew postari od 1 mesec
	$dir2 = "/home/Logs/schedulerNew/";
	$dirHandle2 = opendir($dir2); 
	$lastMonth = addToDate(now(), -1, "month");
		
	while ($file2 = readdir($dirHandle2)) { 
	    if(!is_dir($file2)) {
			$lastModified2 = date ("Y-m-d H:i:s", filemtime($dir2 . $file2));
			if ($lastModified2 < $lastMonth) {
				echo $dir2 . $file2 . "<br>";
				unlink($dir2 . $file2);
			}
	    }
	}
	closedir($dirHandle2);
	
?>

