<html>
<head>
	
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	<link rel="stylesheet" type="text/css" href="./style.css">


	

    
	<script type="text/javascript" src="./js/OpenLayers.js"></script>
	
	
	
<script>
	var map, drawControls;
	function init(){
		map = new OpenLayers.Map('map');
		var wmsLayer = new OpenLayers.Layer.WMS( "OpenLayers WMS", "http://192.168.2.51:8080/geoserver/wms", {'layers': 'geonet:testMapa'});
		var pointLayer = new OpenLayers.Layer.Vector("Point Layer");
		var lineLayer = new OpenLayers.Layer.Vector("Line Layer");
		var polygonLayer = new OpenLayers.Layer.Vector("Polygon Layer");
		var boxLayer = new OpenLayers.Layer.Vector("Box layer");
		map.addLayers([wmsLayer, pointLayer, lineLayer, polygonLayer, boxLayer]);
		map.addControl(new OpenLayers.Control.LayerSwitcher());
		map.addControl(new OpenLayers.Control.MousePosition());
		drawControls = {
			line: new OpenLayers.Control.DrawFeature(lineLayer, OpenLayers.Handler.Path)
		};
		for(var key in drawControls) {
			map.addControl(drawControls[key]);
		}
		map.setCenter(new OpenLayers.LonLat(22.773614, 41.967404), 15);
		//document.getElementById('noneToggle').checked = true;
		drawControls['line'].activate();
	}
	function toggleControl(element) {
		for(key in drawControls) {
			var control = drawControls[key];
			if(element.value == key && element.checked) {
				control.activate();
			} else {
				control.deactivate();
			}
		}
	}
	function allowPan(element) {
		var stop = !element.checked;
		for(var key in drawControls) {
			drawControls[key].handler.stopDown = stop;
			drawControls[key].handler.stopUp = stop;
		}
	} 
	
	</script>
</head>
	
<body onload="init()">

        <div id="map"></div>

</body>
</html>