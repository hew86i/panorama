// JavaScript Document

function getVal(arr, name){
	var itm
	for (var i=0; i<arr.length; i++){
		itm = arr[i].split(":")
		if (itm[0].toUpperCase()==name.toUpperCase()) return itm[1]
	}
	return ''
}
//darkoooooooooooooooooooooooooo ---->


function OnMouseOutMarker(e) {
    $$('#gnToolTip1').remove()
}
var noI = -1
var ret = -1
var vozila

function qsort(array, begin, end) {

    if (end - 1 > begin) {
        var pivot = begin + Math.floor(Math.random() * (end - begin));

        pivot = partition(array, begin, end, pivot);

        qsort(array, begin, pivot);
        qsort(array, pivot + 1, end);
    }
}

function partition(array, begin, end, pivot) {
    var pom = array[pivot].split("#")
    var piv = parseInt(pom[0]);
    array.swap(pivot, end - 1);
    var store = begin;
    var ix;
    for (ix = begin; ix < end - 1; ++ix) {
        pom = array[ix].split("#")
        pom = parseInt(pom[0])
        if (pom <= piv) {

            array.swap(store, ix);
            ++store;
        }
    }
    array.swap(end - 1, store);

    return store;
}

Array.prototype.swap = function (a, b) {
    var tmp = this[a];
    this[a] = this[b];
    this[b] = tmp;
}



function OnMouseOverMarker(i, iZoom, e) {
    if (noI != i) {
        noI = i
        ret = m.OnMouseOverMarker(i, iZoom)
    }

    if (ret != -1) {

        vozila = ret.split("%")

        qsort(vozila, 0, vozila.length)
		
	
        var s = ''
        if (vozila.length > 5) {
            var redovi = Math.sqrt(vozila.length)
            var koloni = vozila.length / redovi
        }
        else {
            koloni = vozila.length
        }
        var red = 0
        var kol = 0
        var koll = koloni
        for (var i = 0; i < vozila.length; i++) {
            if (kol >= koloni) {
                koll = kol
                kol = 0;
                red++;
            }

            var vozilo = vozila[i].split('#');
            s += '<div class="' + vozilo[1] + ' fontMainMenu" style=" position:absolute; left:' + ((25 * kol) + 5) + 'px; top:' + ((25 * red) + 5) + 'px "><strong>' + vozilo[0] + '</strong></div>'
            kol++
        }


        var gnTT = document.getElementById('gnToolTip1')
        if (gnTT == null) {
            gnTT = document.createElement('div')
            gnTT.setAttribute("id", "gnToolTip1")
            document.body.appendChild(gnTT)
        }
        gnTT.style.position = 'absolute'

        gnTT.style.left = (e.clientX) + 'px'
        gnTT.style.width = 25 * (koll) + 'px'
        gnTT.style.height = 25 * (red + 1) + 'px'
        gnTT.style.top = (e.clientY + 20) + 'px'
        gnTT.innerHTML = s
        gnTT.style.zIndex = '9999'
        gnTT.className = "gn-shadow"
    }

}





function InitLoadVehicle() {
    var xmlHttp; var str = ''
    try { xmlHttp = new XMLHttpRequest(); } catch (e) {
        try
	  { xmlHttp = new ActiveXObject("Msxml2.XMLHTTP"); }
        catch (e) { try { xmlHttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) { alert("Your browser does not support AJAX!"); return false; } } 
    }

    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4) {
            str = xmlHttp.responseText

            if (str != '') {
                var strVisible = '<table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td>'
                var vehicles = str.split("#")
                for (var i = 0; i < vehicles.length; i++) {

                    var items = vehicles[i].split("@")
                    var vehicleID = getVal(items, 'vehicleID')
                    var NumberOfVehicle = getVal(items, 'NumberOfVehicle')
                    var Boja = getVal(items, 'Color')
                    var _Visible = true
                    var area = getVal(items, 'AreaID')
                    var _VehicleInArea = getVal(items, 'VehicleInArea')
                    var _v = getVal(items, 'Visible')
                    if (_v == 'False') _Visible = false
                    var _op = '1'
                    if (_Visible == true) { _op = '1' } else { _op = '0.5' }


                    var m1 = new gnMarker('', NumberOfVehicle, parseFloat(getVal(items, 'Longitude')), parseFloat(getVal(items, 'Latitude')), 48, 48, _Visible, '', vehicleID, NumberOfVehicle, Boja)
                    m.AddMarker(m1)
                    strVisible = strVisible + '<a onclick="top.ChangeVisibility(' + NumberOfVehicle + ')" id="vehicle-visible-' + NumberOfVehicle + '" class="gnVisible' + Boja + ' fontMainMenu gn-corner2" style="opacity:' + _op + '">' + NumberOfVehicle + '</a>'
                    top._VehicleVisibility[NumberOfVehicle] = _Visible
                    top._VehicleAlarmID[NumberOfVehicle] = getVal(items, 'AlarmID')


                    if (area != -1) {
                        var pom2 = "VozilaZona" + area
                        var pom3 = top.document.getElementById(pom2)


                        if (pom3) {
                            if (_VehicleInArea == '1')
                                pom3.innerHTML += '<div id="VehicleInArea" class="gn-corner1 fontMainMenu" style="background-color:green">' + NumberOfVehicle + '</div> '
                            else
                                pom3.innerHTML += '<div id="VehicleInArea" class="gn-corner1 fontMainMenu" style="background-color:#D92626">' + NumberOfVehicle + '</div> '
                        }
                    }
                }
                strVisible = strVisible + '</td></tr></table>'
                var panelVisible = top.document.getElementById('Right-panel-1')
                if (panelVisible != null) { panelVisible.innerHTML = strVisible }
            }
            m.LoadMarkers()
            setTimeout("LoadVehiclePosition()", 5000)
        }
    }
    var panelVisible = top.document.getElementById('Right-panel-1')
    if (panelVisible != null) {
        panelVisible.innerHTML = '<span class="fontMainMenu"><br>&nbsp;Loading...<br>&nbsp;</span>'
    }
    xmlHttp.open("GET", '../server/getCurrentPosition.aspx', true);
    xmlHttp.send(null);
    //
}


function MoveVehicle() {
    noI = -1//darkoooooooooooooooooooooooooo
    ret = -1//darkoooooooooooooooooooooooooo
    var xmlHttp; var str = ''
    try { xmlHttp = new XMLHttpRequest(); } catch (e) {
        try
	  { xmlHttp = new ActiveXObject("Msxml2.XMLHTTP"); }
        catch (e) { try { xmlHttp = new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) { alert("Your browser does not support AJAX!"); return false; } } 
    }

    xmlHttp.onreadystatechange = function () {
        if (xmlHttp.readyState == 4) {
            try { $.stopAnimations() } catch (ex) { }

            str = xmlHttp.responseText
            if (str != '') {
                var zon

                zon = top.document.getElementsByName("VozilaZona")
                for (var i = 0; i < zon.length; i++) {
                    zon[i].innerHTML = ""
                }
                var vehicles = str.split("#")
                for (var i = 0; i < vehicles.length; i++) {

                    var items = vehicles[i].split("@")
                    var NumberOfVehicle = getVal(items, 'NumberOfVehicle')
                    var Boja = getVal(items, 'Color')
                    var _Visible = true
                    var area = getVal(items, 'AreaID')
                    var _VehicleInArea = getVal(items, 'VehicleInArea')
                    if (getVal(items, 'Visible') == 'False') _Visible = false
                    var _op = '1'
                    if (_Visible == false) _op = '0.5'
                    top._VehicleVisibility[NumberOfVehicle] = _Visible
                    var el = top.document.getElementById('vehicle-visible-' + NumberOfVehicle)

                    //darkooooooooooooooooooo
                    if (area != -1) {
                        var pom2 = "VozilaZona" + area
                        var pom3 = top.document.getElementById(pom2)


                        if (pom3) {

                            if (_VehicleInArea == '1')
                                pom3.innerHTML += '<div id="VehicleInArea" class="gn-corner1 fontMainMenu" style="background-color:green">' + NumberOfVehicle + '</div> '
                            else
                                pom3.innerHTML += '<div id="VehicleInArea" class="gn-corner1 fontMainMenu" style="background-color:#D92626">' + NumberOfVehicle + '</div> '
                        }
                    }

                    el.className = 'gnVisible' + Boja + ' fontMainMenu gn-corner2'
                    el.style.opacity = _op
                    m.MarkerNewLL(NumberOfVehicle, parseFloat(getVal(items, 'Longitude')), parseFloat(getVal(items, 'Latitude')), Boja, '', '', '', NumberOfVehicle, _Visible)
                }


            }
        }
    }
    
    xmlHttp.open("GET", '../server/getCurrentPosition.aspx', true);
    xmlHttp.send(null);

    //
}
//<------darkoooooo














function LoadVehiclePosition(){
    MoveVehicle()
	$$(top.document.getElementById('Right-panel-2')).ajax('../server/getVehicleList.aspx', null, false)
	setTimeout("LoadVehiclePosition()",10000)
}


function AjaxLoadArea(_id, _bgC, _bc/*darkoo*/) {
	var xmlHttp; var str=''
	try {xmlHttp=new XMLHttpRequest();} catch (e) { try
	  {xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");}
	catch (e){try  {xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");}  catch (e)   {alert("Your browser does not support AJAX!");return false;}}}

	xmlHttp.onreadystatechange = function () {
	    if (xmlHttp.readyState == 4) {
	        try { $.stopAnimations() } catch (ex) { }

	        str = xmlHttp.responseText
	        if (str != '') {
	            //alert(m.id);
	            var _pts = str.split("@");
	            //alert(_pts);
	            _pts[_pts.length] = _pts[0];
	            m.AddPolygon(_pts, _bgC, _bc/*darkoo*/, 2, _id + '');
	            m.ClearRaphaelPaper();
	            m.DrawGraphic();
	        }
	    }
	}
	xmlHttp.open("GET",'../server/getArea.aspx?id='+_id,true);
	xmlHttp.send(null);
	//
}

function LoadArea(_tf, _id, _bgC, _bc/*darkoo*/) {
	//alert(_tf+'  '+_id)
	if (_tf==true) {
	    AjaxLoadArea(_id, _bgC, _bc/*darkoo*/)
	} else {
		m.RemoveFromGraphic(_id+'')	
	}
}