﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
        <style>
			.textQ {
				font-family:Arial, Helvetica, sans-serif; 
				font-size:24px; 
				font-weight:normal; 
				color:#ffffff; 1
				text-decoration: none
			}
  			td {
  				border:1px solid #ffffff;
  			}
        </style>
</head>
	<script>
		lang = 'mk'
	</script>
	
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.customQ.css">	
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/iScroll.js"></script>
    <script src="./js/jquery-ui.js"></script>
    
    <script type="text/javascript">
	    function SetHeightLiteG(){
			var _h = document.body.offsetHeight;
		    $('#divRes').css({ height: (_h - 500) + 'px' });
		}
	</script>
    	
<?php
    opendb();
	
	$dsCandidates = query("select *, (select geonetgetresults(id)) totalres from geonetcandidate order by typetest desc, totalres desc");
	//$dsCandidates = query("select *, (select geonetgetresults(id)) totalres from geonetcandidate order by id asc");
	$dsTotalQ = query("select count(*) c, qgroupnum from geonetquestions group by qgroupnum order by qgroupnum asc");
	//$totalQ = dlookup("select count(*) from geonetquestions");
	
	$totalCss = pg_fetch_result($dsTotalQ, 0, "c");
	$totalJs = pg_fetch_result($dsTotalQ, 1, "c");
	$totalPhp = pg_fetch_result($dsTotalQ, 2, "c");
	$totalNet = pg_fetch_result($dsTotalQ, 3, "c");
	$totalPg = pg_fetch_result($dsTotalQ, 4, "c");
	$totalIq = pg_fetch_result($dsTotalQ, 5, "c");
?>

<body style="margin:0px 0px 0px 0px; overflow: auto; padding:0px 0px 0px 0px" onResize="SetHeightLiteG()">
	<div id="divRes" style="width:100%; height:100%; color:#ffffff; padding-top:20px;" class="textQ">
		<table width=90% style="margin:0 auto; ">
			
			<?php
			$cntC = 1;
			
			while($drCandidate = pg_fetch_array($dsCandidates)) {
				if ($drCandidate["typetest"] == ".Net") {
					$totalQ = dlookup("select count(*) from geonetquestions where qgroup <> 'PHP'");
				}
				if ($drCandidate["typetest"] == "PHP") {
					$totalQ = dlookup("select count(*) from geonetquestions where qgroup <> '.Net'");
				}
							
				$css = 0;
				$js = 0;
				$php = 0;
				$net = 0;
				$pg = 0;
				$iq = 0;
				$notQ = 0;
				$totalTime = 0;
				
				$cssWrong = '';
				$jsWrong = '';
				$phpWrong = '';
				$netWrong = '';
				$pgWrong = '';
				$iqWrong = '';
				
				for ($i=1; $i <= 36; $i++) {
					$totalTime += nnull($drCandidate["answertime".$i],0);
				}
				$cntTrue = 0;
			?>
			<tr height=30px>
				<td align="left" class="text2" style="padding-left:7px; font-size: 12px; font-weight: bold; border:1px dotted #2f5185;"><?=$cntC?>. <?=$drCandidate["fullname"]?>
					<br><font style="font-style: italic; font-weight: normal; color: #ff6600"><?=$drCandidate["typetest"]?></font></td>
				<?php
				for ($i=1; $i<=36; $i++) {
				?>
				<!--td align="center" class="text2" style="font-size: 12px; border:1px dotted #2f5185;"-->
					<?php
					$Ans = query("select * from geonetquestions where num = " . $i);
					$trueAns = pg_fetch_result($Ans, 0, "trueanswer");// dlookup("select trueanswer from geonetquestions where num = " . $i);
					$AnsGr = pg_fetch_result($Ans, 0, "qgroupnum");
										
					$a = "<img height=15px  src='./images/stikla3.png' height=20px border='0' align='absmiddle' />";
					if (nnull($drCandidate["answer".$i], "/") == "/") {
						if ($drCandidate["typetest"] == "PHP") {							
							if (($i >= 1 && $i < 18) || ($i > 26 && $i <= 36)) {
								$notQ++;
							}	
						}
						if ($drCandidate["typetest"] == ".Net") {
							if (($i >= 1 && $i < 13) || ($i > 17 && $i <= 36)) {
								$notQ++;
							}	
						}
					}
					if ($drCandidate["answer".$i] == $trueAns) {
						$a = "<img height=15px src='./images/stikla2.png' border='0' align='absmiddle' />";
						if ($AnsGr == 1) $css++;
						if ($AnsGr == 2) $js++;
						if ($AnsGr == 3) $php++;
						if ($AnsGr == 4) $net++;
						if ($AnsGr == 5) $pg++;
						if ($AnsGr == 6) $iq++;
						$cntTrue++;
					} else {
						if ($AnsGr == 1) {
							if ($cssWrong == "") $cssWrong = "<b>CSS</b><br>";
							$cssWrong .= "- " . str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i)) . "<br>";
							if ($drCandidate["answer".$i] > 4)
								$cssWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
							else
								$cssWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
						}
						if ($AnsGr == 2) {
							if ($jsWrong == "") $jsWrong = "<b>JavaScript / jQuery</b><br>";
							$jsWrong .= "- " . str_replace('"', '\'', str_replace(">", "> ", str_replace("<", "< ", str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i))))) . "<br>";
							if ($drCandidate["answer".$i] > 4)
								$jsWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
							else
								$jsWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
						}
						if ($AnsGr == 3 and $drCandidate["typetest"] == "PHP") {
							if ($phpWrong == "") $phpWrong = "<b>PHP</b><br>";
							$phpWrong .= "- " . str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i)) . "<br>";
							if ($drCandidate["answer".$i] > 4)
								$phpWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
							else
								$phpWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
						}
						if ($AnsGr == 4 and $drCandidate["typetest"] == ".Net") {
							if ($netWrong == "") $netWrong = "<b>.Net</b><br>";
							$netWrong .= "- " . str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i)) . "<br>";
							if ($drCandidate["answer".$i] > 4)
								$netWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
							else
								$netWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
						}
						if ($AnsGr == 5) {
							if ($pgWrong == "") $pgWrong = "<b>SQL</b><br>";
							$pgWrong .= "- " . str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i)) . "<br>";
							if ($drCandidate["answer".$i] > 4)
								$pgWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
							else
								$pgWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
						}
						if ($AnsGr == 6) {
							if ($iqWrong == "") $iqWrong = "<b>IQ</b><br>";
							if ($i == 34) {
								$iqWrong .= "- I слика<br>";
								$iqWrong .= "Одговор: ". nnull($drCandidate["answer".$i], "/") ."<br><br>";
							} else {
								if ($i == 35) {
									$iqWrong .= "- II слика<br>";
									$iqWrong .= "Одговор: ". nnull($drCandidate["answer".$i], "/") ."<br><br>";
								} else {
									if ($i == 36) {
										$iqWrong .= "- III слика<br>";
										$iqWrong .= "Одговор: ". nnull($drCandidate["answer".$i], "/") ."<br><br>";
									} else {
										$iqWrong .= "- " . str_replace('"', '\'', str_replace(">", "> ", str_replace("<", "< ", str_replace("<br>", " ", dlookup("select question from geonetquestions where num = " . $i))))) . "<br>";		
										if ($drCandidate["answer".$i] > 4)
											$iqWrong .= "Одговор: Ниту едно од горенаведените<br><br>";
										else
											$iqWrong .= "Одговор: " . nnull(str_replace("<br>", " ", dlookup("select answer".$drCandidate["answer".$i]." from geonetquestions where num = " . $i)), "/") . "<br><br>";
									}
								}
	
							}
						}
					?>
						<!--span style="font-style: italic; font-weight: normal; color: #ff6600"><?=$i . "<br>"?></span-->
					<?php
					}
					//echo $a . " (" . Sec2Str($drCandidate["answertime".$i]) . ")";
					?>
				<!--/td-->
				<?php	
				}
				if ($totalCss == $css) $colCss = "green"; else $colCss ="red";
				if ($totalJs == $js) $colJs = "green"; else $colJs ="red";
				if ($totalPhp == $php) $colPhp = "green"; else $colPhp ="red";
				if ($totalNet == $net) $colNet = "green"; else $colNet ="red";
				if ($totalPg == $pg) $colPg = "green"; else $colPg ="red";
				if ($totalIq == $iq) $colIq = "green"; else $colIq ="red";
				?>
				
			</tr>	
			
			<tr>
				<td class="text2">
					<?=$cssWrong?>
					<?=$jsWrong?>
					<?=$phpWrong?>
					<?=$netWrong?>
					<?=$pgWrong?>
					<?=$iqWrong?>
				</td>
			</tr>
				
					<?php	
			//echo $css . " " . $js . " " . $php . " " . $net . " " . $pg . " " . $iq;	
			$cntC++; 
			}
			?>
							
		</table>
		<br>
	</div>
	


    <?php
    closedb();
    ?>
    
</body>
<script type="text/javascript">
SetHeightLiteG();
setInterval(function(){ location.reload();}, 20000);
</script>
</html>


