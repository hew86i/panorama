<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
</head>
<body>
	<textarea id="prevod" value="" style="width: 1400px; height: 800px; border: 0px;"></textarea>
	<script>
		var aLang = new Array();
		
		aLang[0]="succSaved;Successfully Saved !;Успешно зачувано !;sauvegardé avec succès";
	    aLang[1]="en;English;Англиски;Anglais";
	    aLang[2]="fr;France;Француски;France";
	    aLang[3]="logout;Logout;Одјава;Déconnexion";
	    aLang[4]="home;Home;Дома;Maison";
	    aLang[5]="reports;Reports;Извештаи;Rapports";
	    aLang[6]="live;Live tracking;Следење во живо;Suivi en direct";
	    aLang[7]="sett;Settings;Подесувања;Réglages";
	    aLang[8]="help;Help;Помош;Aider";
	    aLang[9]="resSett;Restore settings;Врати ги подесувањата;Restaurer les paramètres";
	    aLang[10]="sepScreen;Separate screen;Одделен екран;Ecran séparé";
	    aLang[11]="addPoi;Add POI;Додади точка од интерес;Ajouter POI";
	    aLang[11]="addPoi1;Add POI;Додади точка од интерес;Ajouter POI";
	    aLang[12]="splitScr;Split screen;Поделба екран;L'écran partagé";
	    aLang[13]="addPoi1;Add point of interest;Додади точка од интерес;Ajouter un point d'intérêt";
	    aLang[14]="chooseGroupPoi;Choose group(s) for point of interest;Избери група(и) за точка од интерес;Choisissez le groupe (s) pour le point d'intérêt";
	    aLang[15]="showGeoFence;Show GeoFence;Прикажи зона;Afficher la zone";
	    aLang[16]="chooseGroupGF;Choose group(s) for GeoFence;Избери група(и) за зона;Choisissez le groupe (s) pour la zone";
	    aLang[17]="actScr;Choose active screen;Избери активен екран;Choisissez l'écran actif";
	    aLang[18]="enterUser;Enter username !;Внеси корисничко име !;Entrez le nom !";
	    aLang[19]="enterFull;Enter fullname !;Внеси цело име !;Entrez le nom complet !";
	    aLang[20]="enterPass;Enter password !;Внеси лозинка !;Entrez le mot de passe !";
	    aLang[21]="enterEmail;Enter e-mail !;Внеси е-маил !;Entrez l'adresse e-mail !";
	    aLang[22]="selectUserDel;Select user to delete !;Избери корисник за бришење !;Sélectionnez l'utilisateur à supprimer !";
	    aLang[23]="selUser;Select user !;Избери корисник !;Sélectionnez l'utilisateur !";
	    aLang[24]="wait;Please wait . . . ;Ве молиме почекајте . . . ;S'il vous plaît patienter. . .";
	    aLang[25]="EnterGroupName;Enter group name !;Внеси име на група !;Entrez le nom du groupe !";
	    aLang[26]="selGroupEdit;Select group for edit !;Избери група за измена !;Sélectionnez le groupe pour l'édition !";
	    aLang[27]="groupCannotMod;This group cannot be modified !;Оваа група не може да биде променета !;Ce groupe ne peut pas être modifié !";
	    aLang[28]="selGroupDel;Select group to delete !;Избери група за бришење !;Sélectionnez le groupe à supprimer !";
	    aLang[29]="delGroup;Delete only group;Избриши само група;Supprimer le groupe uniquement";
	    aLang[30]="delWithPoi;Delete with POI;Избриши со точка од интерес;Supprimer avec POI";
	    aLang[31]="No;No;Не;Pas";
	    aLang[32]="mustOnePoiMod;Must select one point of interest to modify !;Мора да изберете една точка од интерес за промена !;Vous devez sélectionner un point d'intérêt à modifier !";
	    aLang[33]="cancel;Cancel;Откажи;Annuler";
	    aLang[34]="enterPoi;Enter point of interest !;Внеси точка од интерес !;Entrez un point d'intérêt !";
	    aLang[35]="mustPoiDel;Must select point of interest to delete !;Мора да изберете точка од интерес за бришење !;Vous devez sélectionner un point d'intérêt à supprimer !";
	    aLang[36]="yes;Yes;Да;Oui";
	    aLang[37]="mustPoi;Must select Point of Interest !;Мора да изберете точка од интерес !;Vous devez sélectionner Point d'intérêt !";
	    aLang[38]="mustGeoFenceMod;Must select one GeoFence to modify !;Мора да изберете една зона за промена !;Devez en sélectionner un GeoFence modifier !";
	    aLang[39]="enterGFName;Enter GeoFence Name !;Внеси име на зона !;Entrez le nom GeoFence !";
	    aLang[40]="MustGFDel;Must select GeoFence to delete !;Мора да изберете зона за бришење !;Vous devez sélectionner GeoFence à supprimer !";
	    aLang[41]="MustGF;Must select GeoFence !;Мора да изберете зона !„;Vous devez sélectionner GeoFence!";
	    aLang[42]="SelGrDel;Select group to delete !;Изберете група за бришење !;Sélectionnez le groupe à supprimer !";
	    aLang[43]="DelWithGF;Delete with GeoFence;Избриши со зона;Supprimer avec GeoFence";
	    aLang[44]="MustSelGFAdd;Must select one GeoFence to add vehicles !;Мора да изберете една зона за да додадете возила;Devez en sélectionner un GeoFence d'ajouter des véhicules !";
	    aLang[45]="showPoi;Show Point Of Interest;Прикажи точки од интерес;Afficher point d'intérêt";
	    aLang[46]="selUserEdit;Select user for edit !;Изберете корисник за промена !;Sélectionnez l'utilisateur pour l'édition!";
	    aLang[47]="OneClick;It's necessary one click on any map to add a POI (Point of interest).;Потребен е еден клик на било која мапа за да се додаде ТОИ (Точка од интерес).;Il faut un seul clic sur une carte pour ajouter un POI (Points d'intérêt).";
	    aLang[48]="Poi;Point of interest;Точка од интерес;Point d'intérêt";
	    aLang[49]="initialView;Initial view;Почетен поглед;Vue initiale";
	    aLang[50]="switchMap;Switch map;Смени мапа;Changer de carte";
	    aLang[51]="switchTypeMap;Switch type of map;Смени тип на мапа;Mettez le type de carte";
	    aLang[52]="add;Add;Додади;Аjouter";
	    aLang[53]="GeoFence;GeoFence;Зона;GeoFence";
	    aLang[54]="Save;Save;Сними;Sauver";
	    aLang[55]="AddGFPoi;Adding GeoFence or Point of interest;Додавање на зона или точка од интерес;GeoFence Ajout ou Point d'intérêt";
	    aLang[56]="AddGF;Add new GeoFence;Додади нова зона;Ajouter GeoFence nouvelle";
	    aLang[57]="Ruler;Ruler;Линијар;Règle";
	    aLang[58]="Measure;Measure;Мерење;Mesurer";
	    aLang[59]="RulerMeasure;Ruler for distance measuring;Линијар за мерење на растојание;Règle pour mesurer la distance";
	    aLang[60]="search;Search;Пребарувај;Rechercher";
	    aLang[61]="searchByName;Search streets, points of interest;Пребарувај улици, точки од интерес;Rues de la recherche, les points d'intérêt";
	    aLang[62]="Vehicles;Vehicles;Возила;Véhicules";
	    aLang[63]="ListVehicles;List of vehicles;Листа на возила;Liste des véhicules";
	    aLang[64]="ChooseVehicles;Choose the visible vehicles on the map;Избери ги видливите возила на мапата;Choisissez les véhicules visibles sur la carte";
	    aLang[65]="allVehicles;All vehicles;Сите возила;Tous les véhicules";
	    aLang[66]="all;All;Сите;Tous";
	    aLang[67]="symbol;Symbol;Симбол;Symbole";
	    aLang[68]="group;Group;Група;Groupe";
	    aLang[69]="selGroup;Please select group;Изберете група;S'il vous plaît sélectionner le groupe";
	    aLang[70]="ClickDraw;Click on the map to start drawing new GeoFence !;Кликнете на мапата за да започнете со цртање на нова зона !;Cliquez sur la carte pour commencer à dessiner GeoFence nouvelle !";
	    aLang[71]="EndDraw;To finish drawing press double click.;За да престанете со цртање кликнете два пати.;Pour terminer le tracé de presse clic double.";
	    aLang[72]="NoGF;There is no GeoFence for saving !!!;Нема зона за зачувување !!!;Il n'y a pas GeoFence pour économiser!!!";
	    aLang[73]="ChooseActScr;Choose active screen;Избери акривен екран;Choisissez l'écran actif";
	    aLang[74]="CurrTimeDate;Current date and time;Моментален датум и време;Date et heure actuelles";
	    aLang[75]="Name;Name;Име;Nom";
	    aLang[76]="Edit;Edit;Измени;Editer";
	    aLang[77]="Delete;Delete;Избриши;Effacer";
	    aLang[78]="updateGF;Update GeoFence;Ажурирање на зона;Mise à jour GeoFence";
	
	    aLang[79]="EnterGFName;Enter GeoFence name !!!;Внеси го името на зоната !!!;Entrez le nom GeoFence!!!";
	    aLang[80]="SelectGroup;Select a group for this GeoFence !!!;Избери група за оваа зона !!!;Sélectionnez un groupe pour ce GeoFence!!!";
	    aLang[81]="ReqFields;Please enter the required fields...;Ве молиме внесете ги потребните полиња...;S'il vous plaît entrer les champs requis ...";
	    aLang[82]="AddInfo;Additional info;Дополнителни информации;Informations complémentaires";
	    aLang[83]="Group;Group;Група;Groupe";
	    aLang[84]="EditPoi;Edit POI;Измени точка од интерес;Modifier POI";
	    aLang[85]="Update;Update;Ажурирај;Mettre à jour";
	    aLang[86]="Error;Error;Грешка;Erreur";
	    aLang[87]="5dinara;This option is charged 5 denars per message,<br />if you want to activate, enter the password!!!;Оваа опција се наплаќа 5 денари по порака,<br />доколку сакате да ја активирате внесете ја лозинката!!!;Cette option est facturée 5 dinars par message, <br /> si vous souhaitez activer, entrez le mot de passe!";
	    aLang[88]="EnterPass;Enter password: ;Внесете лозинка: ;Entrez le mot de passe:";
	    aLang[89]="alerttGF;Alert GeoFence;Информативна Порака;GeoFence alerte";
	    aLang[90]="WrongPass;Wrong password !!!;Погрешна лозинка !!!;Mot de passe incorrect!!!";
	    aLang[91]="GFWSD;GeoFence was successfully deleted !!!;Зоната е успешно избришана !!!;GeoFence a été supprimé avec succès!!!";
	    aLang[92]="mesec;,Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec;,Јан,Фев,Мар,Апр,Мај,Јун,Јул,Авг,Сеп,Окт,Ное,Дец;, Janvier, Février, Mars, Avril, Mai, Juin, Juillet, Août, Septembre, Octobre, Novembre, Décembre";
	    aLang[93]="vehToFollow;Follow;Следи;Suivre";
	    aLang[94]="FollowVehicles;Select vehicles for live tracking;Избор на возила за следење на мапа;Sélectionnez véhicules pour le suivi en direct";
	    aLang[95]="cancelOper;Cancel operation;Откажи операција;Annulez l'opération";
		aLang[96]="SucAddSch;Successfully added scheduler !!!;Успешно додаден распоред !!!;Vous avez joint l'ordonnanceur!";
	    aLang[97]="NoData;No data for the requested period !!!;Нема податоци за бараниот период !!!;Pas de données pour la période demandée";
	    aLang[98]="Only7Days;You can choose up to 7 days !!!;Може да изберете максимум за 7 дена !!!;Vous pouvez choisir jusqu'à 7 jours!!!";
	    aLang[99]="StartEnd;The start datetime must be smaller or equal to the end datetime !!!;Почетниот датум и време мора да се помали или еднакви на крајниот датум и време !!!;Le datetime de début doit être inférieure ou égale à la valeur datetime fin!!!";
	    aLang[100]="EndToday;The end datetime must be smaller or equal to today's datetime !!!;Крајниот датум и време мора да се помали или еднакви на денешниот датум !!!;Le datetime de fin doit être inférieure ou égale à datetime aujourd'hui!";
	    aLang[101]="CancelOper;Cancel operation;Откажи операција;Annulez l'opération";
	    aLang[102]="biggerThan1;Please choose a range greater than 1 hour !!!;Ве молиме изберете опсег поголем од 1 час !!!;S'il vous plaît choisir une portée supérieure à 1 heure !!!";
	    aLang[103]="validSFormat;Please enter valid format of the start datetime !!!;Ве молиме внесете правилен формат на почетниот датум и време !!!;S'il vous plaît entrez format valide de la date initiale et le temps !!!";
	    aLang[104]="validEFormat;Please enter valid format of the end datetime !!!;Ве молиме внесете правилен формат на крајниот датум и време !!!;S'il vous plaît entrez le format valide de la date et l'heure !!!";
	    aLang[105]="selRadius;Please select radius;Изберете радиус;S'il vous plaît sélectionner le rayon";
	    aLang[106]="spleetScreenInfo;The module Split screen because of its complexity requires a better configuration. <br /> Otherwise you may have trouble while loading!!!;Модулот Поделба на екран, поради својата комплексност има потреба од подобра конфигурација.<br />Во спротивно можно е да имате проблем при вчитување!!!;Le Split screen module raison de sa complexité exige une meilleure configuration. <br /> Sinon, vous pouvez avoir de la difficulté pendant le chargement!!!";
	    aLang[107]="Street;Street:;Улица:;Rue:";
	    
	    aLang[108]="GFVeh;Zone in which the vehicle is:;Зона во која што се наоѓа возилото:;Zone dans laquelle le véhicule est:";
	    aLang[109]="RouteForV;Path of vehicle:;Патека на возилото:;Chemin de véhicule:";
	    aLang[110]="Number;Number;Број;Nombre";
	    aLang[111]="From;From;Од;De";
	    aLang[112]="To;To;До;à";
	    aLang[113]="Route;Route;Рута;Route";
	    aLang[114]="EmailSucSend;The report is successfully sent to your email.;Извештајот е успешно испратен на вашиот е-маил.;Le rapport est envoyé avec succès à votre e-mail.";
	    aLang[115]="EmailNotSend;The еmail can not be sent.;Е-маилот не може да биде испратен.;L'e-mail ne peut pas être envoyé.";
	    aLang[116]="Sending;Sending...;Испраќање...;Еnvoi...";
	    aLang[117]="SelectDriver;Select the driver;Изберете возач;Sélectionnez le pilote";
	    aLang[118]="CantModifyPOI;You do not have privileges to modify this point of interest;Немате привилегии да ја менувате оваа точка од интерес;Vous ne disposez pas des privilèges pour modifier ce point d'intérêt";
	    aLang[119]="CantModifyGF;You do not have privileges to modify this GeoFence;Немате привилегии да ја менувате оваа зона;Vous ne disposez pas des privilèges pour modifier cette zone";
		aLang[120]="next;Next;Следно;Prochain";
	    aLang[121]="back;Back;Назад;Dos";
	    aLang[122]="show;Show;Прикажи;Montrer";
	    aLang[123]="newCom;For a new comparison click;За нова споредба кликнете;Pour un clic nouvelle comparaison";
	    aLang[124]="here;here;тука;ici";
	    aLang[125]="ResLoading;Loading the comparison results...;Вчитување на резултатите од споредбата...;Résultats de récupération des comparaison...";
	    aLang[126]="twoVeh;Choose at least two vehicles for comparison !!!;Изберете најмалку две возила за споредба !!!;Choisissez au moins deux véhicules pour la comparaison !!!";
	    aLang[127]="oneCat;Choose at least one category for comparison !!!;Изберете најмалку една категорија за споредба !!!;Choisissez au moins une catégorie de comparaison !!!";
	    aLang[128]="showPOIbtn;Show POI;Прикажи ТОИ;Afficher PDI";
	    aLang[129]="Streets;Streets;Улици;Rues";
	    aLang[130]="Pois;Points of interest;Точки од интерес;Points d'intérêt";
	    aLang[131]="searchStreetsByName;Search streets by name; Пребарувај улици по име;Rues de la recherche par nom";
	    aLang[132]="Registration;Registration;Регистрација;Inscription";
	    aLang[133]="Date;Date;Датум;Date";
	    aLang[134]="Time;Time;Време;Тemps";
	    aLang[135]="Speed;Speed;Брзина;Vitesse";
	    aLang[136]="SelectRoute;Select a route;Изберете рута;Sélectionnez un itinéraire";
	    aLang[137]="SelectVeh;Select a vehicle;Изберете возило;Sélectionnez un véhicule";
	    aLang[138]="SelectDriver;Select the Driver;Изберете возач;Sélectionnez le pilote";
	    aLang[139]="InfoRoute1;Fill in the required information, the input of a route!!!;Пополнете ги потребните информации, за внесување на една рута!!!;Remplissez les informations demandées, l'entrée d'une route!!!";
	    aLang[140]="InfoRoute2;No data for the selected day!!!;Нема податоци за избраниот ден!!!;Pas de données pour le jour sélectionné!!!";
	    aLang[141]="InfoRoute3;Error, please try again!!!;Грешка, ве молиме обидете се повторно!!!;Erreur, s'il vous plaît essayer à nouveau!!!";
	    aLang[142]="Start;Start;Почеток;Commencer";
	    aLang[143]="InfoRoute4;No data for today!!!;Нема внесено рути!!!;Pas de données pour le jour sélectionné!!!";
	    aLang[144]="Welcome;Welcome to your destination.;Добредојдовте на вашата дестинација.;Bienvenue à votre destination.";
	    aLang[145]="Distance;Distance;Одалеченост;Distance";
	    aLang[146]="Narrative;Narrative;Narrative;Récit";
	    aLang[147]="YourTrip;Your trip is ;Вашето патување изнесува: ;Votre voyage est ";
	    aLang[148]="forward;Forward;Напред;Avant";
	    aLang[149]="pause;Pause;Пауза;Pause";
	    aLang[150]="no;No;Не;Aucun";
	    aLang[151]="End;End;Крај;Fin";
	    aLang[152]="addAllDriver;Add allowed driver;Додади дозволен возач;Ajout d'un pilote a permis";
	    aLang[153]="addAllVehicle;Add allowed vehicle;Додади дозволено возило;Ajouter des véhicules autorisés";
	    aLang[154]="addOrgUnit;Add organizational unit;Додади организациона единица;Ajouter l`unité d'organisation";
	    aLang[155]="modOrgUnit;Modify organizational unit;Промени организациона единица;Modifier l'unité d'organisation";
	    aLang[156]="change;Change;Промени;Changer"
	    aLang[157]="delEnt;Delete entry;Бришење на запис;Effacer l`entrée"
	    aLang[158]="STOS;Start time of stopping;Почетно време на застанување;Heure de début de l`arrêt"
	    aLang[159]="ETOS;End time of stopping;Крајно време на застанување;Heure de fin de l`arrêt"
	    aLang[160]="TTOS;Total time of standing;Вкупно време на стоење;La durée totale de debout"
	    aLang[161]="hide;Hide;Сокри;Cacher"
	    aLang[162]="alarm;Alarm for stop outside the route longer than x minutes;Аларм за застанување надвор од рута подолго од х минути;Arrêt d'alarme en dehors de la route plus de x minutes"
	    aLang[163]="print;Print;Печати;Imprimer"
	
	    aLang[164] = "noEmail;* You did not enter any email !;* Немате внесено ниту еден е-маил !;* Vous n'avez pas entrer dans un e-mail !";
	    aLang[165] = "uncorrEmail;* You entered an invalid email format !;* Внесовте невалиден формат на е-маил !;* Vous avez entré un format email invalide !";
	    aLang[166] = "SchNote;* To enter multiple e-mails separate by ,<br /> Example: n1@example.com, n2@example.com,;* За внес на повеќе е-маилови одделувајте со ,<br />Пример:n1@example.com,n2@example.com,;* Pour entrer plusieurs adresses e-mails séparés les e-mails par ,<br /> Exemple: n1@example.com,n2@example.com,";
	    aLang[167] = "noEmail1;* You did not enter email !;* Немате внесено е-маил !;* Vous n'avez pas entré e-mail !";
	
	    var index = 3;
	    /*if (lang == "en")
	        index = 1
	    if (lang == "mk")
	        index = 2
	    if (lang == "fr")
	        index = 3
		*/
	    var l = 0
	    l = aLang.length;
		var html="";
	
	    for (i1=0;i1<l;i1++) {
	         html += "<" + aLang[i1].split(";")[0] + ">" + aLang[i1].split(";")[index] + "</" + aLang[i1].split(";")[0] + ">\n";
	    }
	    debugger;
	    document.getElementById("prevod").value = html;
	</script>
</body>
</html>