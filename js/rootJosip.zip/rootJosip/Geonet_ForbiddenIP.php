﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
        <style>
			.textQ {
				font-family:Arial, Helvetica, sans-serif; 
				font-size:24px; 
				font-weight:normal; 
				color:#ffffff; 
				text-decoration: none
			}
  		
        </style>
</head>
	<script>
		lang = 'mk'
	</script>
	
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.customQ.css">	
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/iScroll.js"></script>
    <script src="./js/jquery-ui.js"></script>


<body>
	
	<div style="width:100%; height:100%">
		<!DOCTYPE html><head><title>Error 404</title><meta charset="utf-8" /><meta name="Author" content="Panorama Inc." /><meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0; user-scalable=0;" /><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7, IE=9" /></head><style>.box{width: 600px; height: 200px; display: block; position: absolute; left: calc(50% - 300px); top: calc(50% - 100px)}.kf36{font-size:36px; font-family: sans-serif; font-weight: 300}.kf15{font-size:15px; font-family: sans-serif; font-weight: 300}.kBlue{color: #009be4}.kOrange{color: #f27935}.kGray{color:#262626}.kBold{font-weight: bold}.kLGray{color:#a2a1a1}</style><body><div class="box"><img src="https://tafoma.com/images/404.png" align="right" height="200px" /><span style="float:left" class="kf36 kBlue"><img src="http://panorama.gps.mk/images/GeonetLogo.png" /></span><br><br><br><br><br><span class="kf15 kGray"><span class="kBold">404</span>. That is an error</Span><br><br><span class="kf15 kGray">The requested URL was not found on this server</Span><br><span class="kf15 kLGray">That is all we know.</Span>    </div></body> </html>    
		
		
		
	</div>
	


    <?php
    closedb();
    ?>
    
</body>
<script type="text/javascript">

</script>
</html>


