
function GlobsyMaps(elementID, apikey){
	// ***** Variables ***** //
	this.goran = '1234'
	//this.LonCent = '22.773614';
	//this.LatCent = '41.967404';
	var Container = document.getElementById(elementID);
	var cElement;
	var ms = new gnMapsSet();
	
	var cZoom = 6;
	var isdrag = false;
	var ie=document.all; var nn6=document.getElementById&&!document.all;
	var x,y; 
	var arr  = new Object();
	var cntCell = 0
	var Markers = new Object();
	var PinP = new Object();
	var MarkersCount = 0
	var cZoomTrack
	var screenX, screenY;
	var inZoomProc = false;
	var FromScrool = false
	var filter = '0:true;1:true;2:true;3:true;4:true;5:true;6:true;'
	var MapType = "GLOBSY"
	var gmap
	HaveZone = false;
	var GoogleLevel = 8
	this.HaveRaphael = false
	this.ZonePoints
	this.ApiKey = apikey;
	this.GpolygonA = new Array();
	this.GpolylineA = '';
	this.CurrentMapSet = '';
	var RaphaelPaper
	var Graphic = new Object();
	var GraphicCount = 0;


	// ***** Public functions ***** //
	this.getCenterMap = function () {
	    var MapCenter = new Object();
	    MapCenter[0] = m.LonCent;
	    MapCenter[1] = m.LatCent;
	    return MapCenter;
	}

	function SetCenter(lon, lat) {
	    m.LonCent = String(lon);
	    m.LatCent = String(lat);
	}

	this.setMapset = function(ms){
		CurrentMapSet = ms
	}
	
	this.getCZoom = function(){return cZoom}
	this.DrowMode = function(tf){
		if (tf==true) {btnStationAdd=1} else {btnStationAdd=0}
	}

	this.init = function (iZoom, iLon, iLat) {
	    this.ApiKey = apikey
	    Container.style.overflow = 'hidden';
	    Container.style.width = document.body.clientWidth+'px';
	    Container.style.height = document.body.clientHeight + 'px'
	    cZoom = iZoom;
	    ms.getNewarestCity(iLon, iLat);
	    CreateBoard(iZoom);
	    //CreateNavigator();
	    CreateLogo();
	    //CreateBtnStation();
	    //CreateBtnGoogle();
	    //CreateBtnZones();
	    //CreateBtnFilter();
	    //CreateBtnAreas();
	    //CreatePopup();
	    pSetCenterLL(iLon, iLat)
	    //cZoomTrack.style.top = 170 - (12.85 * iZoom)
	    if (getHref(location.href) == false) alert('You use unregistred version of GLOBSY MAPS API !!!')
	};
	
	this.getMarkersCount = function(){return MarkersCount}
	this.setVisibleMarkers = function(aid,v){
		for (var j=0; j<MarkersCount; j++) {
			if (aid==Markers[j].alarmid){Markers[j].visible=v}
		}	
	}
	
	this.getGMarker = function(aid){
		for (var j=0; j<MarkersCount; j++) {
			if (aid==Markers[j].alarmid){return Markers[j].gMarker}
		}
	}
	
	this.getMapType = function(){
		return MapType;	
	}
	this.SetCenterLL  = function (lon, lat){
		pSetCenterLL(lon, lat)	
	}
	
	this.AddMarker = function(gnM){
		Markers[MarkersCount] = gnM
		MarkersCount = MarkersCount + 1
	}

	this.LoadMarkers = function(){
			DrowMarkers(cZoom);
	}

	function GetVisiblePinPoints()
    {
        var uu1 = new Array(2);
        var uu2 = new Array(2);
        var aa = new Array(2);
        var bb = new Array(2);
        var coo = new Coordinates();
        if (MapType == "GOOGLE")
        {
            uu1[1] = gmap.getBounds().getSouthWest().x;
            uu1[0] = gmap.getBounds().getSouthWest().y;
            uu2[1] = gmap.getBounds().getNorthEast().x;
            uu2[0] = gmap.getBounds().getNorthEast().y;
        } else
        {
            var p1X = (0 - cElement.offsetLeft) - (cWidth())
            var p1Y = (0 - cElement.offsetTop) + (cHeight())
            var p2X = (0 - cElement.offsetLeft) + (cWidth())
            var p2Y = (0 - cElement.offsetTop) - (cHeight())
            p1Y = cElement.offsetHeight - p1Y
            p2Y = cElement.offsetHeight - p2Y
            uu1 = ms.XY2LonLat(p1X, p1Y, cZoom)
            uu2 = ms.XY2LonLat(p2X, p2Y, cZoom)
        }

        aa = coo.LLtoUTM(uu1[1], uu1[0])
		bb = coo.LLtoUTM(uu2[1], uu2[0])
		//alert(parseInt(aa[0])+'  '+parseInt(aa[1]))
		//alert(parseInt(bb[0])+'  '+parseInt(bb[1]))
		
		/*if (document.getElementById('btnStation').style.display=='none') {
			//$('.gn-pinpoint').remove();
		}else {
			if (btnStation == 1) {
				LoadPinPoints(parseInt(aa[0]), parseInt(aa[1]), parseInt(bb[0]), parseInt(bb[1]))
			} else {
				//$('.gn-pinpoint').remove();
			}
		}*/
		
		
	}
	
	function LoadPinPoints(x1, y1, x2, y2){
		var xmlHttp;var str = '';
		try {xmlHttp=new XMLHttpRequest();} catch (e) { try
		  {xmlHttp=new ActiveXObject("Msxml2.XMLHTTP");}
		catch (e){try  {xmlHttp=new ActiveXObject("Microsoft.XMLHTTP");}  catch (e)   {alert("Your browser does not support AJAX!");return false;}}}

		xmlHttp.onreadystatechange = function () {
		    if (xmlHttp.readyState == 4) {
		        if (btnStation == 0) return false
		        //if (document.getElementById('btnStation').style.display == 'none') return false
		        str = xmlHttp.responseText
		        var ss = str.split("$$**$$")
		        var cH = cElement.offsetHeight;
		        $$('-gn-pinpoint').remove();
		        var mBox = 6;

		        if (MapType == "GOOGLE") {
		            var baseIcon = new Array();
		            function createMarker(point, index, title) {
		                baseIcon[index] = new GIcon();
		                baseIcon[index].image = "./Images/marker.png";
		                baseIcon[index].iconSize = new GSize(25, 25);
		                baseIcon[index].shadowSize = new GSize(20, 20);
		                baseIcon[index].iconAnchor = new GPoint(9, 34);
		                baseIcon[index].infoWindowAnchor = new GPoint(9, 2);
		                baseIcon[index].infoShadowAnchor = new GPoint(18, 25);
		                // Create a lettered icon for this point using our icon class
		                var icon = new GIcon(baseIcon[index]);
		                var marker = new GMarker(point, icon);
		                GEvent.addListener(marker, "click", function () {
		                    marker.openInfoWindowHtml(title);
		                });
		                return marker;
		            }
		            for (var i = 1; i < ss.length; i++) {
		                var pp = ss[i].split("@^@");
		                var point = new GLatLng(parseFloat(pp[2]), parseFloat(pp[1]));
		                gmap.addOverlay(createMarker(point, i, pp[0]));
		            }
		        } else {
		            for (var i = 0; i < ss.length; i++) {
		                var pp = ss[i].split("@^@");
		                var cMarker = document.createElement('div');
		                cMarker.setAttribute("id", "gnMarker_station_" + i)
		                cMarker.title = pp[0]
		                cMarker.style.width = mBox + 'px'
		                cMarker.style.height = mBox + 'px'
		                cMarker.className = "gn-pinpoint"
		                cMarker.setAttribute('name', 'gn-pinpoint')

		                var yfac = 10;
		                var lon = pp[1];
		                var lat = pp[2];

		                var uu = new Array(2)
		                uu = ms.LonLat2XY(parseFloat(lon), parseFloat(lat), cZoom)

		                var npx = Math.round(uu[0]) - (mBox / 2)
		                var npy = Math.round((cH - uu[1] - (mBox / 2)))

		                cMarker.style.left = npx + 'px'
		                cMarker.style.top = npy + 'px'

		                cMarker.style.zIndex = '299';
		                cMarker.style.position = 'absolute';

		                cMarker.style.border = "1px solid #515151"
		                cMarker.style.backgroundColor = "#00eaff"
		                cMarker.style.cursor = 'pointer'
		                cElement.appendChild(cMarker);

		                //cMarker.style.backgroundImage = 'URL(images/pin.png)'
		                cMarker.innerHTML = "";
		            }
		        }
		    }
		}
	    xmlHttp.open("GET", 'getPinPoints.aspx?x1=' + x1 + '&y1=' + y1 + '&x2=' + x2 + '&y2=' + y2, true);
		xmlHttp.send(null);			
	}

	this.MarkerNewLL = function (mtitle, lon, lat, colo, imgpath, html, tag, label, visible) {

	    //alert(mtitle + "  " + lon + "  " + lat + "  " + colo + "  " + imgpath + "  " + html + "  " + tag + "  " + label + "  " + visible);
	    var cH = cElement.offsetHeight;
	    for (var j = 0; j < MarkersCount; j++) {
	        if (Markers[j].title == mtitle) {

	            Markers[j].tag = tag
	            Markers[j].setLL(lon, lat);
	            Markers[j].ImagePath = imgpath
	            Markers[j].label = label
	            Markers[j].color = colo
	            Markers[j].visible = visible
	            var mar = document.getElementById('gnMarker_' + mtitle)
	            if (mar != null) {
	                Markers[j].html = html
	                if (mar.style.left != '-99999px') {

	                    //darkooooooooooooooooooooo
	                    mar.setAttribute("onMouseOver", 'OnMouseOverMarker(' + j + ',' + cZoom + ', event)')
	                    mar.setAttribute("onMouseOut", 'OnMouseOutMarker(event)')



	                    var npx = Math.round(Markers[j].getX(cZoom) - (Markers[j].width / 2))
	                    var npy = Math.round((cH - Markers[j].getY(cZoom) - (Markers[j].height / 2)))

	                    var dX = npx - mar.offsetLeft
	                    var dY = npy - mar.offsetTop
	                    var alfa = Math.round(Math.atan2((-1) * dY, dX) * (180 / Math.PI))
	                    var colorY = "0px"
	                    var colorX = ((-1) * alfa * 48) + 'px'
	                    var textColor = 'FFFFFF';
	                    if (colo == '22') { colorY = '0px' }
	                    if (colo == '16') { colorY = '-48px' }
	                    if (colo == '23') { colorY = '-96px' }
	                    if (colo == '08') { colorY = '-144px'; textColor = '0000000' }
	                    if (colo == '18') { colorY = '-192px' }

	                    //mar.style.backgroundImage = 'URL(images/statuses.png)' //  'URL('+imgpath+')'

	                    //mar.style.backgroundPosition = colorX + ' '+ colorY
	                    //Markers[j].SetImageXY(parseInt(colorX), parseInt(colorY) * (-1))

	                    //var inst = '<div align="center" style="margin-top:16px; font-family:Arial, Helvetica, sans-serif; font-size:11px; font-weight:bold; color:#'+textColor+';">'+label+'</div>'
	                    //mar.innerHTML = inst
	                    alfa = alfa * (-1)
	                    var radius = 14
	                    var pi = 3.14159
	                    var cosAlfa = Math.cos(alfa * (pi / 180))
	                    var sinAlfa = Math.sin(alfa * (pi / 180))

	                    var nPozX = ((cosAlfa * radius) - 4) + 24
	                    var nPozY = ((sinAlfa * radius) - 4) + 24

	                    var MarkerColor = colo  // LightBlue, Red, DarkBlue, Green, Yellow, Gray, Black, Orange, RedBlue

	                    mar.innerHTML = '<div class="gnMarker' + MarkerColor + ' fontMainMenu"><strong>' + Markers[j].label + '</strong></div><div class="gnMarkerPointer' + MarkerColor + '" style="left:' + nPozX + 'px; top:' + nPozY + 'px; height:6px; width:6px; position:absolute"></div>'

	                    if (Markers[j].visible == false) { mar.style.display = 'none' } else { mar.style.display = '' }
	                    $$('#gnMarker_' + mtitle).animate(npx, npy, 10000, cElement.id)
	                    //$$('#gnMarker_'+mtitle).css(['left:'+npx+'px','top:'+npy+'px'])
	                    //$('#gnMarker_'+mtitle).stop().animate({top: ''+npy, left: ''+npx}, 10000, function() {});
	                }

	                Markers[j].html = html
	                return true
	            } else {
	                if (Markers[j].gMarker != null) {
	                    var colorY
	                    if (colo == 'Green') { colorY = '0' }
	                    if (colo == 'Red') { colorY = '48' }
	                    if (colo == 'DarkBlue') { colorY = '96' }
	                    if (colo == 'LightBlue') { colorY = '144'; textColor = '0000000' }
	                    if (colo == 'Orange') { colorY = '192' }
	                    var p1 = gmap.fromLatLngToDivPixel(Markers[j].gMarker.getLatLng());
	                    var p2 = gmap.fromLatLngToDivPixel(new GLatLng(lat, lon));
	                    var dX = p2.x - p1.x;
	                    var dY = p2.y - p1.y;
	                    var alfa = Math.round(Math.atan2((-1) * dY, dX) * (180 / Math.PI))
	                    if (alfa < 0)
	                        var colorX = (180 * 48) + ((180 - Math.abs(alfa)) * 48);
	                    else
	                        var colorX = (alfa * 48);
	                    Markers[j].gMarker.setImage("getIcon.aspx?x=" + colorX + "&y=" + colorY + "&label=" + Markers[j].label);
	                    Markers[j].gMarker.setLatLng(new GLatLng(lat, lon));
	                }
	            }
	        }
	    }
	    return false
	}
	
	
	
	this.setFilter = function (f){
		filter = f	
	}
	this.getFilter = function (){
		return filter
	}
	
	function getFilterByRoute(route_Id){
		var f = filter.split(";")
		for (var i=0; i<f.length-1;i++){
			var a = f[i].split(":")
			if (a[0]==route_Id) {return a[1]}
		}
	}   
	
	this.ApplayFilter = function(){
		pApplayFilter()
	}
	function pApplayFilter(){
		for (var j=0; j<MarkersCount; j++) {

			if (Markers[j].tag!=null){
				var tf = getFilterByRoute(Markers[j].tag)
				var mar = document.getElementById('gnMarker_'+Markers[j].title)
				if (tf=='true') {mar.style.display=''} else {mar.style.display='none'}
			}
		}	
	}
	
	this.SetCenterMarker = function(mtitle){
		for (var j=0; j<MarkersCount; j++) {
			if (Markers[j].title==mtitle){
				if (MapType=="GLOBSY") {
					pSetCenterLL(Markers[j].lon, Markers[j].lat)
					return true
				} else {
					
					gmap.setCenter(new google.maps.LatLng(Markers[j].lat, Markers[j].lon), gmap.getZoom());
				}
			}
		}
		return false
	}	
	// ***** Private functions ***** //
	
	// Get Container width
	function cWidth(){return Container.offsetWidth;};
	// Get Container height
	function cHeight(){return Container.offsetHeight;};
	// get body width
	function bWidth(){return document.body.clientWidth;};
	// get body height
	function bHeight(){return document.body.clientHeight;}
	// Prefill 
	function prefill2(str){str = str+''; if (str.length==1) {str = '0'+str}; return str;}
	
	
	function CreateNavigator(){
		var cnCont= document.createElement('div');
		cnCont.setAttribute("id","gnNavigator")
		
		cnCont.style.width = '40px'
		cnCont.style.overflow ='hidden'
		cnCont.style.height = '210px'
		cnCont.style.position = 'absolute';
		cnCont.style.left = '10px'
		cnCont.style.top = '5px'
		cnCont.style.zIndex = 2000
		Container.appendChild(cnCont);
		
		var cnTop= document.createElement('div');
		
		cnTop.style.width = '17px'
		cnTop.style.height = '17px'
		cnTop.style.background = 'URL(Images/navi.png) no-repeat';
		cnTop.style.backgroundPosition = '0px 0px'
		
		cnTop.style.position = 'absolute';
		cnTop.style.left = '13px'
		cnTop.style.top = '10px'
		cnTop.style.zIndex = 2000
		cnCont.appendChild(cnTop);
		cnTop.style.cursor='pointer'
		cnTop.setAttribute("onclick","m.AnimeToCenter2(0, 4, 10)")
		
		var cnLeft= document.createElement('div');
		cnLeft.style.width = '17px'
		cnLeft.style.height = '17px'
		cnLeft.style.background = 'URL(Images/navi.png) no-repeat';
		cnLeft.style.backgroundPosition = '-17px 0px'
		cnLeft.style.position = 'absolute';
		cnLeft.style.left = '3px'
		cnLeft.style.top = '28px'
		cnLeft.style.zIndex = 2000
		cnCont.appendChild(cnLeft);
		cnLeft.style.cursor='pointer'
		cnLeft.setAttribute("onclick","m.AnimeToCenter2(4, 0, 10)")
		
		var cnRight= document.createElement('div');
		cnRight.style.width = '17px'
		cnRight.style.height = '17px'
		cnRight.style.background = 'URL(Images/navi.png) no-repeat';
		cnRight.style.backgroundPosition = '-34px 0px'
		cnRight.style.position = 'absolute';
		cnRight.style.left = '21px'
		cnRight.style.top = '28px'
		cnRight.style.zIndex = 2000
		cnCont.appendChild(cnRight);
		cnRight.style.cursor='pointer'
		cnRight.setAttribute("onclick","m.AnimeToCenter2(-2, 0, 10)")
		
		var cnDown= document.createElement('div');
		cnDown.style.width = '17px'
		cnDown.style.height = '17px'
		cnDown.style.background = 'URL(Images/navi.png) no-repeat';
		cnDown.style.backgroundPosition = '-51px 0px'
		cnDown.style.position = 'absolute';
		cnDown.style.left = '13px'
		cnDown.style.top = '46px'
		cnDown.style.zIndex = 2000
		cnCont.appendChild(cnDown);		
		cnDown.style.cursor='pointer'
		cnDown.setAttribute("onclick","m.AnimeToCenter2(0, -2, 10)")
		
		var cnScroll= document.createElement('div');
		cnScroll.style.width = '3px'
		cnScroll.style.height = '100px'
		cnScroll.style.backgroundColor = '#d9ecff';
		cnScroll.style.position = 'absolute';
		cnScroll.style.left = '19px'
		cnScroll.style.top = '83px'
		cnScroll.style.border = '1px solid #99bbe8'
		cnScroll.style.zIndex = 2000
		cnCont.appendChild(cnScroll);
		
		
		var cnPlus= document.createElement('div');
		cnPlus.style.width = '17px'
		cnPlus.style.height = '17px'
		cnPlus.style.background = 'URL(Images/navi.png) no-repeat';
		cnPlus.style.backgroundPosition = '0px -17px'
		cnPlus.style.position = 'absolute';
		cnPlus.style.left = '13px'
		cnPlus.style.top = '65px'
		cnPlus.style.zIndex = 2000
		cnCont.appendChild(cnPlus);		
		cnPlus.style.cursor='pointer'
		cnPlus.setAttribute("onclick","m.ZoomIn()")
	
		var cnMinus= document.createElement('div');
		cnMinus.style.width = '17px'
		cnMinus.style.height = '17px'
		cnMinus.style.background = 'URL(Images/navi.png) no-repeat';
		cnMinus.style.backgroundPosition = '-17px -17px'
		cnMinus.style.position = 'absolute';
		cnMinus.style.left = '13px'
		cnMinus.style.top = '186px'
		cnMinus.style.zIndex = 2000
		cnCont.appendChild(cnMinus);		
		cnMinus.style.cursor='pointer'
		cnMinus.setAttribute("onclick","m.ZoomOut()")
		
		var cnTrack= document.createElement('div');
		cnTrack.style.width = '17px'
		cnTrack.style.height = '17px'
		cnTrack.style.background = 'URL(Images/navi.png) no-repeat';
		cnTrack.style.backgroundPosition = '-34px -17px'
		cnTrack.style.position = 'absolute';
		cnTrack.style.left = '13px'
		cnTrack.style.top = '170px'
		cnTrack.style.zIndex = 2000
		cnCont.appendChild(cnTrack);		
		cZoomTrack = cnTrack; 

		cnTrack.style.cursor='n-resize'
	}
	
	var btnStation = 0
	var btnStationAdd = 0
	
	function CreateBtnStation(){
		var cBtn= document.createElement('div');
		cBtn.style.display='none'
		cBtn.setAttribute("id","btnStation")
		cBtn.style.width = '24px'
		cBtn.style.height = '18px'
		cBtn.style.backgroundImage = 'URL(Images/poi1.png)';
		cBtn.style.position = 'absolute';
		cBtn.style.left =  '130px'
		cBtn.style.top = '15px'
		cBtn.style.zIndex = 5000
		cBtn.style.border = '0px solid #000000'
		Container.appendChild(cBtn);
		cBtn.style.cursor = "pointer"
		
		cBtn.setAttribute("onclick","m.StationClick()")
		
		//cBtn.title="Show / Hide Point Of Interes"
		cBtn.setAttribute('onmouseover','$.tooltip(event,\'Show / Hide Point Of Interes\')')
		cBtn.setAttribute('onmouseout','$$(\'#gnToolTip\').remove()')

		var cBtn1= document.createElement('div');
		cBtn1.setAttribute("id","btnStationAdd")
		cBtn1.style.width = '32px'
		cBtn1.style.height = '32px'
		cBtn1.style.backgroundImage = 'URL(Images/addpoi.png)';
		cBtn1.style.position = 'absolute';
		cBtn1.style.left =  '140px'
		cBtn1.style.display = 'none'
		cBtn1.style.top = '90px'
		cBtn1.style.zIndex = 5000
		cBtn1.style.border = '0px solid #000000'
		Container.appendChild(cBtn1);
		cBtn1.style.cursor = "pointer"
		
		cBtn1.setAttribute("onclick","m.AddStationClick()")
		
		cBtn1.title="Add Point Of Interes"
	}
	
	function CreateBtnGoogle(){
		
		//GLOBSY
		var cBtn1= document.createElement('a');
		cBtn1.setAttribute("id","btnGlobsy")
		cBtn1.style.width = '24px'
		cBtn1.style.height = '18px'
		cBtn1.style.backgroundImage = 'URL(Images/globsy1.png)';
		cBtn1.style.backgroundPosition = '0px -18px';
		
		cBtn1.style.position = 'absolute';
		cBtn1.style.left =  '70px'
		cBtn1.style.top = '15px'
		cBtn1.style.zIndex = 5000
		cBtn1.style.border = '0px solid #000000'
		cBtn1.style.cursor = "pointer"
		Container.appendChild(cBtn1);
		
		cBtn1.setAttribute("onclick","m.GlobsyClick()")
		
		cBtn1.title=""
		cBtn1.setAttribute('onmouseover','$.tooltip(event,\'Switch to GLOBSY MAPS\')')
		cBtn1.setAttribute('onmouseout','$$(\'#gnToolTip\').remove()')

		// Google
		var cBtn= document.createElement('div');
		cBtn.setAttribute("id","btnGoogle")
		cBtn.style.width = '24px'
		cBtn.style.height = '18px'
		cBtn.style.backgroundImage = 'URL(Images/google1.png)';
		cBtn.style.position = 'absolute';
		cBtn.style.left =  '100px'
		cBtn.style.top = '15px'
		cBtn.style.zIndex = 5000
		cBtn.style.border = '0px solid #000000'
		cBtn.style.cursor = "pointer"
		Container.appendChild(cBtn);

		cBtn.setAttribute("onclick","m.GoogleClick()")

		//cBtn.title="Switch to GOOGLE MAPS"
		cBtn.setAttribute('onmouseover','$.tooltip(event,\'Switch to GOOGLE MAPS\')')
		cBtn.setAttribute('onmouseout','$$(\'#gnToolTip\').remove()')

	}
	
	function CreateBtnZones(){

		//GLOBSY
		var cBtn1= document.createElement('div');
		cBtn1.setAttribute("id","btnZones")
		cBtn1.style.width = '32px'
		cBtn1.style.height = '32px'
		cBtn1.style.backgroundImage = 'URL(Images/zones.png)';
		cBtn1.style.backgroundPosition = '0px 0px';
		cBtn1.style.display = 'none'
		cBtn1.style.position = 'absolute';
		cBtn1.style.left =  '180px'
		cBtn1.style.top = '90px'
		cBtn1.style.zIndex = 5000
		cBtn1.style.border = '0px solid #000000'
		cBtn1.style.cursor = "pointer"
		Container.appendChild(cBtn1);
			
		cBtn1.setAttribute("onclick","m.ShowHideZones()")

		cBtn1.title="Show / Hide Areas"
	}
	
	function CreateBtnFilter(){
		var cBtn= document.createElement('div');
		cBtn.setAttribute("id","btnFilter")
		cBtn.style.width = '70px'
		cBtn.style.height = '19px'
		cBtn.style.backgroundImage = 'URL(Images/btn_filter.png)';
		cBtn.style.position = 'absolute';
		cBtn.style.left =  '360px'
		cBtn.style.top = '100px'

		cBtn.style.zIndex = 5000
		cBtn.style.border = '0px solid #000000'
		Container.appendChild(cBtn);
		cBtn.style.opacity = 0.5;
		cBtn.style.filter = 'alpha(opacity=' + 5 + ')';
		cBtn.setAttribute("onmouseover","this.style.opacity = 0.9; this.style.filter = 'alpha(opacity=90)'")
		cBtn.setAttribute("onmouseout","this.style.opacity = 0.5; this.style.filter = 'alpha(opacity=50)'")
		//cBtn.setAttribute("onclick","m.StationClick()")
	}
	
	function CreateBtnAreas(){
		return false
		var cBtn= document.createElement('div');
		cBtn.setAttribute("id","btnAreas")
		cBtn.style.width = '70px'
		cBtn.style.height = '19px'
		cBtn.style.backgroundImage = 'URL(Images/btn_zoni.png)';
		cBtn.style.position = 'absolute';
		cBtn.style.left =  '440px'
		cBtn.style.display = 'none'
		cBtn.style.top = '100px'
		cBtn.style.zIndex = 5000
		cBtn.style.border = '0px solid #000000'
		Container.appendChild(cBtn);
		cBtn.style.opacity = 0.5;
		cBtn.style.filter = 'alpha(opacity=' + 5 + ')';
		cBtn.setAttribute("onmouseover","this.style.opacity = 0.9; this.style.filter = 'alpha(opacity=90)'")
		cBtn.setAttribute("onmouseout","this.style.opacity = 0.5; this.style.filter = 'alpha(opacity=50)'")
		cBtn.setAttribute("onclick","m.btnAreasClick()")
	}

	this.ClearGraphic = function() {
	    RaphaelPaper.clear()
	    Graphic = new Object();
	    GraphicCount = 0;
	}
	this.ClearRaphaelPaper = function(){
		RaphaelPaper.clear()
	}

	this.RemoveFromGraphic = function (_id) {
	    if (MapType == "GOOGLE") {
	        gmap.removeOverlay(this.GpolygonA[_id]);
	    } else {
	        var t = []
	        var _c = GraphicCount
	        for (var i = 0; i < GraphicCount; i++) {
	            if (Graphic[i].id != _id) {
	                t[t.length] = Graphic[i]
	            } else {
	                _c = _c - 1
	                Graphic[i].element.remove()
	            }
	        }
	        Graphic = t
	        GraphicCount = _c
	    }
	}

	function CreateRaphael() {
        var cBtn = document.createElement('div')
        cBtn.setAttribute("id", "divRaph")
        cBtn.style.width = cElement.offsetWidth + 'px'
        cBtn.style.height = cElement.offsetHeight + 'px'
        cBtn.style.position = 'absolute';
        cBtn.style.left = '0px'
        cBtn.style.top = '0px'
        cBtn.style.zIndex = 299
        cBtn.style.border = '0px solid #000000'
        cElement.appendChild(cBtn);
        RaphaelPaper = Raphael(cBtn, cElement.offsetWidth, cElement.offsetHeight);
        pDrawGraphic()
	}

	this.AddPath = function(LonLatPoints, PathColor, PathWidth) {
        var gr = new gnGraphic('Path', LonLatPoints, '#000', PathColor, PathWidth)
	    Graphic[GraphicCount] = gr
	    GraphicCount = GraphicCount + 1
	}

	this.AddPolygon = function (LonLatPoints, BackColor, BorderColor, BorderWidth, _id) {
	    if (MapType == "GLOBSY") {
	        var gr = new gnGraphic('Poly', LonLatPoints, BackColor, BorderColor, BorderWidth);
	        gr.id = _id;
	        Graphic[GraphicCount] = gr;
	        GraphicCount = GraphicCount + 1;
	    } else {
	        pointsArray = new Array();
	        for (i = 0; i < LonLatPoints.length; i++) {
	            pointsArray.push(new GLatLng(LonLatPoints[i].substring(LonLatPoints[i].indexOf(";") + 1, LonLatPoints[i].length), LonLatPoints[i].substring(0, LonLatPoints[i].indexOf(";"))));
	        }
	        pointsArray.push(new GLatLng(LonLatPoints[0].substring(LonLatPoints[0].indexOf(";") + 1, LonLatPoints[0].length), LonLatPoints[0].substring(0, LonLatPoints[0].indexOf(";"))));
	        var polygon = new GPolygon(pointsArray, "#d7150b", 2, 1, "#701b17", 0.2);
	        
	        this.GpolygonA[_id] = polygon;
	        gmap.addOverlay(polygon);
	    }
	}

	this.AddCircle = function(LonLatPoints, BackColor, BorderColor, BorderWidth) {
	    var gr = new gnGraphic('Circ', LonLatPoints, BackColor, BorderColor, BorderWidth)
	    Graphic[GraphicCount] = gr
	    GraphicCount = GraphicCount + 1
	}
	
	var GraphPoint = null
	this.AddPoint = function(LonLatPoints, BackColor, BorderColor, BorderWidth) {
	    var gr = new gnGraphic('Circ', LonLatPoints, BackColor, BorderColor, BorderWidth)
	    GraphPoint  = gr
	}
	
	this.AddImage = function(LonLatPoints, BackColor, BorderColor, BorderWidth) {
	    var gr = new gnGraphic('Img', LonLatPoints, BackColor, BorderColor, BorderWidth)
	    Graphic[GraphicCount] = gr
	    GraphicCount = GraphicCount + 1
	}
	
	this.AddIcon = function(LonLatPoints, ImgPath, width, height, paddingLeft, paddingTop) {
	    var gr = new gnGraphic('Icon', LonLatPoints)
		gr.width = width
		gr.height = height
		gr.path = ImgPath
		gr.paddingLeft = paddingLeft
		gr.paddingTop = paddingTop
		
	    Graphic[GraphicCount] = gr
	    GraphicCount = GraphicCount + 1
	}

	this.DrawGraphic = function() {
	    pDrawGraphic()
	}
	this.MoveGraphPoint = function(lon, lat, _color){
		if (_color==null) _color = '#F00'
		if (GraphPoint!=null) {
			var cH = cElement.offsetHeight;
			var uu = new Array(2)
			uu = ms.LonLat2XY(parseFloat(lon), parseFloat(lat), cZoom, ms.Items[5])
			var llLeft = Math.round(uu[0])
			var llTop = Math.round(cH - uu[1])

			var xx = llLeft - GraphPoint.element.getBBox().x 
			var yy = llTop - GraphPoint.element.getBBox().y 
			
			GraphPoint.element.translate(parseInt(xx), parseInt(yy));
			GraphPoint.element.attr({fill: '#'+_color })

			GraphPoint.points[0] = lon+';'+lat
			
		}	
	}
	function pDrawGraphic() {
		//if (flagBtnZones==0) return false
	    var cH = cElement.offsetHeight;

	    for (var j = 0; j < GraphicCount; j++) {
	        
	            var str = ''

				
					
	            for (var i = 0; i < Graphic[j].points.length; i++) {
	                var ll = Graphic[j].points[i].split(";")

	                var uu = new Array(2)
	                uu = ms.LonLat2XY(parseFloat(ll[0]), parseFloat(ll[1]), cZoom)

	                var llLeft = Math.round(uu[0])
	                var llTop = Math.round(cH - uu[1])


	                if (i == 0) {
	                    str = 'M' + llLeft + ',' + llTop + 'L'
	                } else {
	                    str = str + ',' + llLeft + ',' + llTop
	                }
					
	                if (Graphic[j].type == 'Circ') {
	                    var p = RaphaelPaper.circle(llLeft, llTop, 5)
	                    //p.attr({ stroke: Graphic[j].fColor, "stroke-width": Graphic[j].width + "", opacity: 0.8, fill: Graphic[j].bColor })
						if (i==0) {
								p.attr({ stroke: '#0F0', "stroke-width": Graphic[j].width + "", fill: '#0F0' })		
								p.node.setAttribute('title','First Point. Click on point to delete')
						} else {
							if (i==Graphic[j].points.length-1){
								p.attr({ stroke: '#F00', "stroke-width": Graphic[j].width + "", fill: '#F00' })	
								p.node.setAttribute('title','Last Point. Click on point to delete')
							} else {
								p.attr({ stroke: Graphic[j].fColor, "stroke-width": Graphic[j].width + "", fill: Graphic[j].bColor })
								p.node.setAttribute('title','Point number : '+(i+1)+'. Click on point to delete')
							}
						}
						//p.attr({ stroke: Graphic[j].fColor, "stroke-width": Graphic[j].width + "", fill: Graphic[j].bColor })

						p.node.setAttribute('onmouseover', 'this.style.cursor=\'pointer\'; m.DrowMode(false)')
						p.node.setAttribute('onmouseout', 'this.style.cursor=\'pointer\'; m.DrowMode(IsInDrowMode)')
						p.node.setAttribute('onclick', 'DeletePoint('+i+'); m.DrowMode(IsInDrowMode)')
						//p.node.setAttribute('title','Click on point to delete')
						
						
	                }
					if (Graphic[j].type == 'Icon') {
	                   var ii = RaphaelPaper.image(Graphic[j].path, llLeft-Graphic[j].paddingLeft, llTop-Graphic[j].paddingTop, Graphic[j].width, Graphic[j].height);

	                } //Icon
	            }
			
	        
	        if (Graphic[j].type == 'Path') {
	            var p = RaphaelPaper.path(str)
	            p.attr({ stroke: Graphic[j].fColor, "stroke-width": Graphic[j].width + "", opacity: 0.8 })
				
	        }
	        if (Graphic[j].type == 'Poly') {
				
	            var p = RaphaelPaper.path(str)
				str=str.replace("M","")
				str=str.replace("L","")
				//alert(str)
	            p.attr({ stroke: Graphic[j].fColor, "stroke-width": Graphic[j].width + "", opacity: 0.3, fill: Graphic[j].bColor })
				Graphic[j].element=p
				
	        }
	        if (GraphPoint!=null && j==GraphicCount-1){
				var ll = GraphPoint.points[0].split(";")
				var uu = new Array(2)
				uu = ms.LonLat2XY(parseFloat(ll[0]), parseFloat(ll[1]), cZoom, ms.Items[5])
				var llLeft = Math.round(uu[0])
				var llTop = Math.round(cH - uu[1])
				var p = RaphaelPaper.circle(llLeft, llTop, 7)
				p.attr({ stroke: GraphPoint.fColor, "stroke-width": GraphPoint.width + "", fill: GraphPoint.bColor })	
				GraphPoint.element = p

			}
	    }

	}
	
	function pDrowPath(paper, pts, clr){
		var str = ''
		var cH = cElement.offsetHeight;
		for (var i=0; i<pts.length; i++) {
			var ll = pts[i].split(";")	
			
			var uu = new Array(2)
			uu = ms.LonLat2XY(parseFloat(ll[0]),parseFloat(ll[1]), cZoom)

			var llLeft = Math.round(uu[0])
			var llTop = Math.round(cH -uu[1])


			if (i==0) {
				str = 'M'+llLeft+','+llTop+'L'
			} else {
				str = str + ','+llLeft+','+llTop
			}
		}
		var p = this.RaphaelPaper.path(str)
		var sw = cZoom*2
		if (cZoom==6) {sw=100}
		p.attr({stroke: clr, "stroke-width" : 2+"" , opacity: 0.8})
	}
	
	this.btnAreasClick = function(){
		if (HaveZone==false) {
			HaveZone = true;
			document.getElementById('btnAreas').style.backgroundPosition = '0px -19px'
			drowZones()
		} else {
			document.getElementById('btnAreas').style.backgroundPosition = '0px 0px'
			cElement.removeChild(document.getElementById('divRaph'))
			HaveZone = false;
		}
	}
	
	
	this.drowZones = function(){
		if (this.HaveRaphael==false) return false
		var cH = cElement.offsetHeight;
	    CreateRaphael()
		
		
		// Saraj - Avtokomanda 
		//DrowPath(paper, ['21.325600;41.997700','21.330244;42.001508','21.332304;42.004505','21.332744;42.006738','21.336381;42.007104','21.340093;42.007080','21.344567;42.006052','21.345972;42.005972','21.359866;42.006738','21.363171;42.006746','21.363900;42.006817','21.365789;42.007224','21.367310;42.007234','21.368233;42.008605','21.382309;42.004906','21.382931;42.004811','21.413273;42.000569','21.425461;41.998097','21.428164;41.997364','21.429516;41.998895','21.440438;41.998751','21.439837;42.002594','21.440395;42.003981','21.443077;42.003519','21.446081;42.000697','21.448377;41.999405','21.451167;41.999166','21.465179;42.001653'], '#FF0')
		//DrowPath(paper, ['21.339591;42.010216', '21.339810;42.009144', '21.339783;42.007099', '21.340807;42.007003', '21.344659;42.006047', '21.345844;42.005988', '21.359373;42.006690', '21.363761;42.006785', '21.365542;42.007248', '21.367173;42.007232', '21.369756;42.005895', '21.379069;42.000266', '21.380163;41.999820', '21.388167;41.998432', '21.391236;41.998193', '21.418183;41.994562', '21.425865;41.995391', '21.432254;41.994180', '21.432683;41.993957', '21.435224;41.990666', '21.440352;41.993106', '21.441554;41.993983', '21.451167;41.988162', '21.459553;41.989044', '21.478693;41.979410', '21.483586;41.985120'], '#00F')
		if (this.ZonePoints.length > 2) {
			DrowPath(paper, this.ZonePoints, '#00F')		
		}
		
		
	}
	
	
	function CreatePopup(){
		var cPopup= document.createElement('div');
		cPopup.setAttribute("id","popupStation")
		cPopup.style.width = '242px'
		cPopup.style.height = '52px'
		cPopup.style.backgroundImage = 'URL(Images/popup.png)';
		cPopup.style.position = 'absolute';
		cPopup.style.left =  '230px'
		cPopup.style.top = '100px'
		cPopup.style.zIndex = 5000
		cPopup.style.border = '0px solid #000000'
		Container.appendChild(cPopup);
		cPopup.style.display='none'
		
	}
	this.GlobsyX = 0
	this.GlobsyY = 0
	
	var flagBtnZones = 0
	this.ShowHideZones = function(){
		if (flagBtnZones==0){
			var obj = document.getElementById('btnZones')
			obj.style.backgroundPosition = '0px -32px'
			flagBtnZones = 1
			pDrawGraphic()
			
		} else {
			var obj = document.getElementById('btnZones')
			obj.style.backgroundPosition = '0px 0px'			
			flagBtnZones = 0
			RaphaelPaper.clear()
		}
	}

	this.GlobsyClick = function () {
	    if (MapType == "GOOGLE") {
	        for (var j = 0; j < MarkersCount; j++) {
	            Markers[j].SetgMarker(null)
	        }
	        //var gmzoom = gmap.getZoom();
	        if (btnStation == 1)
	            m.StationClick();
            gmap = null;
	        document.getElementById('gnNavigator').style.display = 'block';
	        var obj = document.getElementById('btnGoogle')
	        obj.style.backgroundPosition = '0px 0px'
	        var obj1 = document.getElementById('btnGlobsy')
	        obj1.style.backgroundPosition = '0px -18px'

	        Container.removeChild(cElement)
	        MapType = "GLOBSY";
//	        if (gmzoom < 17 && gmzoom > 10);
//	            cZoom = gmzoom - 10;
	        CreateBoard(cZoom);

            if (cZoom < 5)
	            $$('#btnStation').css(['display:none']);

	        this.SetCenterLL(this.GlobsyX, this.GlobsyY)
	        //cElement.style.left = this.GlobsyX +'px'
	        //cElement.style.top = this.GlobsyY +'px'
	        //pLoadImages()
	    }
	}
	this.GoogleClick = function () {

	    if (MapType == "GLOBSY") {
	        //alert(document.getElementById("toolfuel").style.display)
	        document.getElementById('gnNavigator').style.display = 'none';
	        var obj = document.getElementById('btnGoogle')
	        obj.style.backgroundPosition = '0px -18px'
	        var obj1 = document.getElementById('btnGlobsy')
	        obj1.style.backgroundPosition = '0px 0px'

	        var pX = (0 - cElement.offsetLeft) + (cWidth() / 2)
	        var pY = (0 - cElement.offsetTop) + (cHeight() / 2)
	        pY = cElement.offsetHeight - pY
	        var uu = new Array(2)
	        uu = ms.XY2LonLat(parseFloat(pX), parseFloat(pY), cZoom)
	        this.GlobsyX = uu[1]
	        this.GlobsyY = uu[0]


	        cElement.innerHTML = ""
	        cElement.style.top = '0px'
	        cElement.style.left = '0px'
	        cElement.style.width = '100%'
	        cElement.style.height = '100%'

	        var gDiv = document.createElement('div');
	        gDiv.setAttribute("id", "googlediv")
	        gDiv.style.width = '100%'
	        gDiv.style.height = '100%'
	        cElement.innerHTML = ""
	        cElement.appendChild(gDiv);

	        gmap = new google.maps.Map2(gDiv);

	        gmap.setCenter(new google.maps.LatLng(parseFloat(m.LatCent), parseFloat(m.LonCent)), parseInt(m.getCZoom() + 10, 10));
	        gmap.setMapType(G_NORMAL_MAP);
	        gmap.enableScrollWheelZoom()
	        gmap.setUIToDefault();
	        gmap.enableRotation();

	        MapType = "GOOGLE"
	        GoogleLevel = 8;
	        var counter = 1;
	        if (btnStation == 1)
	            m.StationClick();

	        for (var j = 0; j < MarkersCount; j++) {
	            var carIcon = new GIcon();
	            //alert(Markers[j].color);
	            //"../Images/Car/" + Markers[j].label + "/" + Markers[j].color + ".gif"; //
	            //alert(Markers[j].label);
	            carIcon.image = "getIcon.aspx?x=0&y=" + Markers[j].ImageY + "&label=" + Markers[j].label;
	            carIcon.iconSize = new GSize(45, 45);
	            carIcon.shadowSize = new GSize(34, 34);
	            carIcon.iconAnchor = new GPoint(9, 34);
	            carIcon.infoWindowAnchor = new GPoint(9, 2);
	            carIcon.infoShadowAnchor = new GPoint(18, 25);
	            //carIcon.iconSize = new GSize(48, 48);
	            //carIcon.iconAnchor = new GPoint(24, 24);
	            markerOptions = { icon: carIcon };
	            var point = new GLatLng(Markers[j].lat, Markers[j].lon);
	            var gm = new GMarker(point, markerOptions)
	            gmap.addOverlay(gm);
	            Markers[j].SetGoogleID("mtgt_unnamed_" + j)
	            Markers[j].SetgMarker(gm)
	            if (Markers[j].visible == false) { gm.hide() }
	            counter++;
	        }
	        if (parseInt(m.getCZoom() + 10) < 15)
	            $$('#btnStation').css(['display:none']);
	        if (document.getElementById("gnInfoFuel") != null) {
	            if (_pts.length != 0) {
	                gmap.setCenter(new google.maps.LatLng(parseFloat(_pts[0].substring(_pts[0].indexOf(";") + 1, _pts[0].length)), parseFloat(_pts[0].substring(0, _pts[0].indexOf(";")))), parseInt(m.getCZoom() + 10, 10));
	                pointsArray = new Array();
	                for (i = 0; i < _pts.length; i++) {
	                    pointsArray.push(new GLatLng(_pts[i].substring(_pts[i].indexOf(";") + 1, _pts[i].length), _pts[i].substring(0, _pts[i].indexOf(";"))));
	                }
	                pointsArray.push(new GLatLng(_pts[0].substring(_pts[0].indexOf(";") + 1, _pts[0].length), _pts[0].substring(0, _pts[0].indexOf(";"))));
	                var polyline = new GPolyline(pointsArray, "#00f", 2, 0.8);

	                gmap.addOverlay(polyline);

	                var baseIcon;
	                function createMarker(point, img) {
	                    baseIcon = new GIcon();
	                    if (img == 'Car') {
	                        baseIcon.image = "./Images/Pin" + img + "Red.png";
	                        baseIcon.iconSize = new GSize(20, 20);
	                        baseIcon.shadowSize = new GSize(10, 10);
	                        baseIcon.iconAnchor = new GPoint(3, 10);
	                    }
	                    else {
	                        baseIcon.image = "./Images/Pin" + img + ".png";
	                        baseIcon.iconSize = new GSize(48, 48);
	                        baseIcon.shadowSize = new GSize(30, 30);
	                        baseIcon.iconAnchor = new GPoint(9, 34);
	                    }

	                    // Create a lettered icon for this point using our icon class
	                    var icon = new GIcon(baseIcon);
	                    var marker = new GMarker(point, icon);
	                    if (img == 'Car')
	                        this.GpolylineA = marker;
	                    return marker;
	                }
	                var point = new GLatLng(parseFloat(_pts[0].substring(_pts[0].indexOf(";") + 1, _pts[0].length)), parseFloat(_pts[0].substring(0, _pts[0].indexOf(";"))));
	                gmap.addOverlay(createMarker(point, 'Start'));
	                gmap.addOverlay(createMarker(point, 'Car'));
	                var point = new GLatLng(parseFloat(_pts[_pts.length - 1].substring(_pts[_pts.length - 1].indexOf(";") + 1, _pts[_pts.length - 1].length)), parseFloat(_pts[_pts.length - 1].substring(0, _pts[_pts.length - 1].indexOf(";"))));
	                gmap.addOverlay(createMarker(point, 'End'));
	            }
	        }
	    }
	}
	
	this.AddStationClick = function(){
		//if (MapType == "GOOGLE")  return false
		/*if (btnStationAdd == 0) {
			var obj = document.getElementById('btnStationAdd')
			obj.style.backgroundPosition = '0px -32px'
			btnStationAdd = 1
			$$.msgbox("info","Click on the map to add Point of Interest !")
		} else {
			var obj = document.getElementById('btnStationAdd')
			obj.style.backgroundPosition = '0px 0px'
			btnStationAdd = 0			
		}*/
	}

	this.StationClick = function(){
		//if (MapType == "GOOGLE")  return false
		return false;
		if (btnStation==0){
			var obj = document.getElementById('btnStation')
			obj.style.backgroundPosition = '0px -18px'
			btnStation = 1;
			pLoadImages();
//			for (var j=0; j<MarkersCount; j++) {
//				if (Markers[j].title.substring(0,8)=='station_'){
//					Markers[j].visible = true
//					//$('gnMarker_'+Markers[j].title).SetVisible(true)
//					var mar = document.getElementById('gnMarker_'+Markers[j].title)
//					mar.style.display = ''
//				}			
//			}
			return false	
		} else {
			
            var obj = document.getElementById('btnStation')
			obj.style.backgroundPosition = '0px 0px'

//			for (var j=0; j<MarkersCount; j++) {
//				if (Markers[j].title.substring(0,8)=='station_'){
//					Markers[j].visible = false
//					var mar = document.getElementById('gnMarker_'+Markers[j].title)
//					mar.style.display = 'none'
//				}			
//			}
			//document.getElementById("mtgt_unnamed_50").parentNode.removeChild(document.getElementById("mtgt_unnamed_50"));
			//document.getElementById("mtgt_unnamed_51") == null;
			//m.getMarkersCount();
			
            btnStation = 0;

            if (MapType == "GOOGLE")
            {
                var cnt = m.getMarkersCount();
			    while (document.getElementById("mtgt_unnamed_"+cnt) != null)
                {
                    document.getElementById("mtgt_unnamed_" + cnt).parentNode.removeChild(document.getElementById("mtgt_unnamed_" + cnt));
                    cnt++;
                }
            }
            else
			    $$('-gn-pinpoint').remove();
			return false
		}
	}

	function CreateLogo(){
		var cLogo= document.createElement('div');
		cLogo.setAttribute("id","gnLogo")
		cLogo.style.width = '270px'
		cLogo.style.height = '30px'
		cLogo.style.backgroundImage = 'URL(Images/logo1.png)';
		cLogo.style.position = 'absolute';
		cLogo.style.left = '0px'
		cLogo.style.top = '94%'
		cLogo.style.zIndex = 2000
		cLogo.style.border = '0px solid #000000'
		Container.appendChild(cLogo);
	}
	
	// create Map Board
	function CreateBoard(iZoom){
	    //$.stopAnimations();
        //alert(Container.offsetHeigh+ "    " + Container.clientHeight);
		Container.style.backgroundColor = ms.Items[iZoom].backColor
		if (Container.clientHeight < 512) { Container.style.height = '512px' }
		if (Container.clientWidth < 512) { Container.style.Width = '512px' }
		
		cElement = document.createElement('div');
		cElement.setAttribute("id","el_"+iZoom)
		cElement.style.width = ms.Items[iZoom].widthPx;
		cElement.style.height = ms.Items[iZoom].heightPx;
		cElement.style.overflow = 'hidden';
		cElement.style.position = 'absolute';
		cElement.style.border = '0px solid #000000'
		Container.appendChild(cElement);
		
		cElement.style.cursor='URL(Images/openhand.ico), default';
		cElement.onmousedown=selectmouse;
		cElement.ondblclick=dblClick;
		Container.onmouseup=mouseup;
		cElement.onmousemove=movemouse;
		//alert(cElement.onmousemove)
		if (window.addEventListener) window.addEventListener('DOMMouseScroll', wheel, false);
		window.onmousewheel = document.onmousewheel = wheel;

		var i=0;
		var str = '<table width="'+ms.Items[iZoom].widthPx+'" height="'+ms.Items[iZoom].heightPx+'" style="position:absolute; z-index:'+iZoom+'" border="0" cellspacing="0" cellpadding="0">';
		for (var red=0; red<(ms.Items[iZoom].heightPx/512);red++){
			str = str + '<tr>'
			for (var col=0; col<(ms.Items[iZoom].widthPx/512);col++){
				var celID = iZoom+'_'+red+'_'+col;
				str = str + '<td id="'+celID+'" width="512" height="512" bgcolor="'+ms.Items[iZoom].backColor+'">'
				//str = str + 'red=' + red + '  col='+col
				str = str + '</td>'				
				arr[i] = celID
				i++
			}
			str = str + '</tr>'
		}
		str = str + '</table>'
		cElement.innerHTML = str
		cntCell = i
		pLoadImages();
		DrowMarkers(iZoom);
		//CreateRaphael()
		//m.drowZones()
	}
	
	this.LoadImages = function(){
		pLoadImages()
	}
	
	function rnd(){return Math.floor(Math.random()*3)}
	function prefill(str){str = str+''; if (str.length==2) {str = '0'+str}; return str;}
	function prefill2(str){str = str+''; if (str.length==1) {str = '0'+str}; return str;}
	function CryptString(str){
		var a = ['QWZ','ERX','TYC','UIV','OPB','ASN','DF1','GH9','JK6','LM3'];var newStr = '';var newStr1 = '';
		for (var i=0; i<str.length; i++){newStr = newStr + prefill(str.charCodeAt(i));};
		for (var i=0; i<newStr.length; i++){ var s = a[parseFloat(newStr.substring(i,i+1))]; var r = rnd(); var ss = s.substring(r,r+1); newStr1 = newStr1 + ss;};
		return newStr1;
	}
	
	function getHref(u){
		u=u.replace("www.","")
		// Define url
		//alert(encodeURI($.CryptMaps("localhost")))
		
		//Define key
		//alert(encodeURI($.CryptMaps("localhost")).replace(/%/g,"A"))

		var urls = new Array();
		//urls[0] = "%C3%8Fc%C3%92c%C3%86c%C3%84c%C3%8Fc%C3%8Bc%C3%92c%C3%96c%C3%97c"  //Localhost//key=AC3A8FcAC3A92cAC3A86cAC3A84cAC3A8FcAC3A8BcAC3A92cAC3A96cAC3A97c
		urls[0] = "AC3A8FcAC3A92cAC3A86cAC3A84cAC3A8FcAC3A8BcAC3A92cAC3A96cAC3A97c"
		urls[1] = "%C2%94c%C2%9Cc%C2%95c%C2%91c%C2%94c%C2%99c%C2%9Bc%C2%91c%C2%95c%C2%91c%C2%98c" //192.168.2.5
		urls[2] = "%C3%8Ac%C3%93c%C3%96c%C2%91c%C3%90c%C3%8Ec" //192.168.2.5
		
		
		return true;
		var uu = u.split("//")
		if (uu.length=2){
			var u1 =uu[1].split("/")
			if (u1.length>0) {
				for(var i=0;i<urls.length;i++){
					if (urls[i]==encodeURI($.CryptMaps(u1[0]))) {
						if(apikey==urls[i].replace(/%/g,"A")) {return true}
					} 
				}
				return false
		
			} else {
				for(var i=0;i<urls.length;i++){
					if (urls[i]==encodeURI($.CryptMaps(uu[1]))) {
						if(apikey==urls[i].replace(/%/g,"A")) {return true}
					} 
				}
				return false
			}
			return true
		} else {
			return false	
		}
	}
	
	function pLoadImages() {
		var CLI = getHref(location.href)
		var i =0;
		var cEleft = cElement.offsetLeft;
		var cTop = cElement.offsetTop;
		var lBorder = 0; var rBorder = cWidth(); var tBorder = 0; var bBorder=cHeight();
		var cc = 0
		if (MapType == "GOOGLE")
        {
		    if (gmap.getZoom() > 14)
		        GetVisiblePinPoints();
		} else {
		    if ((cZoom == 5) && (m.CurrentMapSet == 'KO')) { GetVisiblePinPoints() }
		    if ((cZoom == 6) && (m.CurrentMapSet == 'KO')) { GetVisiblePinPoints() }

		    if ((cZoom == 6) && (m.CurrentMapSet == 'MK')) { GetVisiblePinPoints() }
		    if ((cZoom == 5) && (m.CurrentMapSet == 'MK')) { GetVisiblePinPoints() }
		}
		
		for (var red=0; red<(ms.Items[cZoom].heightPx/512);red++){
			for (var col=0; col<(ms.Items[cZoom].widthPx/512);col++){
				
				//is in screen
				var eLeft = (col * 512) + cEleft;
				var eTop = (red * 512) + cTop;
				if (InScreen( eLeft, eTop, rBorder, bBorder )==true) {
					var tmpI = (ms.Items[cZoom].heightPx/512) - red
					tmpI = tmpI - 1
					var imgName = prefill2(col)+'E'+prefill2(tmpI)+'N'
					imgName = ms.Items[cZoom].ZoomLevel + imgName
					//document.getElementById(arr[i]).innerHTML  =  imgName
					//mapimg.aspx?QAVZD1QKPQPKWBMZF3ZB6QAUZGJ
					//document.getElementById(arr[i]).style.backgroundImage = 'URL(maps/'+imgName+'.gif)'
					//ova e kako so treba // document.getElementById(arr[i]).style.backgroundImage = 'URL(maps/'+imgName+'.gif)'
					if (CLI==false) imgName = imgName & "1234"
					var tmpElement = document.getElementById(arr[i])
					if (tmpElement != null) {
						//tmpElement.style.backgroundImage = 'URL(GetImage.aspx?'+encodeURI($.CryptMaps(imgName))+')'
						tmpElement.style.backgroundImage = 'URL(maps/'+imgName+'.gif)'
					}
//					if (document.getElementById(arr[i]).style.backgroundImage=='') {
//						if (cZoom==0) {
//							document.getElementById(arr[i]).style.backgroundImage = 'URL(maps/'+imgName+'.gif)'
//						} else {
//							document.getElementById(arr[i]).style.backgroundImage = 'URL(mapimg.aspx?'+CryptString(imgName)+')'
//						}
//					}
					cc ++
				}
				i++;
			}
		}
	}

	function InScreen(tdLeft, tdTop, _ScreenWidth, _ScreenHeight) {
	    //debugger;
		if ((tdLeft>=0) && (tdLeft<=_ScreenWidth) && (tdTop>=0) && (tdTop<=_ScreenHeight)) {return true}
		if ((tdLeft+512>=0) && (tdLeft+512<=_ScreenWidth) && (tdTop>=0) && (tdTop<=_ScreenHeight)) {return true}	
		if ((tdLeft>=0) && (tdLeft<=_ScreenWidth) && (tdTop+512>=0) && (tdTop+512<=_ScreenHeight)) {return true}	
		if ((tdLeft+512>=0) && (tdLeft+512<=_ScreenWidth) && (tdTop+512>=0) && (tdTop+512<=_ScreenHeight)) {return true}	
		return false
	} // end InScreen


	function CheckKvadrant(x, y ){
		var lenX = 50 // Dolzina na kvadrantot
		var lenY = 50 // Visina na kvadrantot
		var tmpX = parseInt(x/lenX)
		var tmpY = parseInt(y/lenY)
		
		Add2Kvadrant(tmpX*tmpY, x, y)
	}
	
	var qMarkers = [];
	var qMarkersL = [];
	var qMarkersX = [];
	var qMarkersY = [];
	
	
	function Add2Kvadrant(k, x, y){
		var cnt = qMarkers.length
		if (cnt==null) cnt=0
		
		for (var i=0; i<cnt; i++){
			if (qMarkers[i]==k)	{
				qMarkersL[i]=qMarkersL[i]+1
				
				return false
			}
		}
		qMarkersL[cnt] = 1
		qMarkers[cnt] = k
		qMarkersX[cnt] = x
		qMarkersY[cnt] = y
		return false
    }

    //darkooooooooooooooooooooo
    this.OnMouseOverMarker = function(_noMarker, iZoom) {

        var cH = cElement.offsetHeight;
        var npxo = Math.round(Markers[_noMarker].getX(iZoom) - (Markers[_noMarker].width / 2))
        var npyo = Math.round((cH - Markers[_noMarker].getY(iZoom) - (Markers[_noMarker].height / 2)))

        var brojac = 0
        var br = 0
        var str = Markers[_noMarker].label + '#gnMarker' + Markers[_noMarker].color

        var markersIn = []
        markersIn[0] = _noMarker
        for (var i = 0; i < MarkersCount; i++) {

            if (i != _noMarker) {
                if (Markers[i].title.substring(0, 8) != 'station_') {
                    var npx = Math.round(Markers[i].getX(iZoom) - (Markers[i].width / 2))
                    var npy = Math.round((cH - Markers[i].getY(iZoom) - (Markers[i].height / 2)))
                    if (Math.abs(npxo - npx) < 20 && Math.abs(npyo - npy) < 18) {

                        markersIn[markersIn.length] = i;
                        brojac++
                        str += "%" + Markers[i].label + '#gnMarker' + Markers[i].color

                    }
                }
            }
        }


        var markersOut = []
        var noMarkersOut = 0
        //var ps=''
        for (var j = 0; j < MarkersCount; j++) {
            var nema = true
            for (var i = 0; i < markersIn.length; i++) {

                if (markersIn[i] == j) {
                    nema = false;
                    break;
                }
            }
            if (nema) {
                //ps+=j+':'
                markersOut[noMarkersOut] = j;
                noMarkersOut++
            }
        }


        //alert(ps)

        for (var i = 0; i < markersIn.length; i++) {
            var pom = parseInt(markersIn[i])
            if (Markers[pom].title.substring(0, 8) != 'station_') {

                if (pom != _noMarker) {
                    npxo = Math.round(Markers[pom].getX(iZoom) - (Markers[pom].width / 2))
                    npyo = Math.round((cH - Markers[pom].getY(iZoom) - (Markers[pom].height / 2)))
                    for (var m = 0; m < noMarkersOut; m++) {
                        if (markersOut[m] != -1) {
                            j = markersOut[m]

                            if (Markers[j].title.substring(0, 8) != 'station_') {

                                var npx = Math.round(Markers[j].getX(iZoom) - (Markers[j].width / 2))
                                var npy = Math.round((cH - Markers[j].getY(iZoom) - (Markers[j].height / 2)))

                                if (Math.abs(npxo - npx) < 20 && Math.abs(npyo - npy) < 18) {

                                    markersOut[m] = -1
                                    markersIn[markersIn.length] = j;
                                    brojac++
                                    str += "%" + Markers[j].label + '#gnMarker' + Markers[j].color

                                }
                            }
                        }
                    }
                }
            }
        }

        if (brojac != 0) {
            return (str)
        }
        else
            return (-1)

    }
	



	function DrowMarkers(iZoom){
		//alert(MarkerIcons[0])
		qMarkers = [];
		qMarkersL = [];

		var cH = cElement.offsetHeight;
		
		for (var i=0; i<MarkersCount; i++) {
			
			if (Markers[i].title.substring(0,8)=='station_'){

			    
				var yfac = 0;
				if (Markers[i].title.substring(0,8)=='station_') yfac = 10
				
				var lon = Markers[i].lon
				var lat = Markers[i].lat
				
				var npx = Math.round(Markers[i].getX(iZoom)-(Markers[i].width/2))
				var npy = Math.round((cH - Markers[i].getY(iZoom)-(Markers[i].height/2)))

				
				CheckKvadrant(npx, npy)
	

				
			} else {
				// AKO SE VOZILA

				
				var cMarker = document.createElement('div');
				cMarker.setAttribute("id","gnMarker_" + Markers[i].title)
				
				cMarker.style.width = '48px'
				cMarker.style.height = '48px'


				//darkooooooooooooooooooooo
				cMarker.setAttribute("onMouseOver", 'OnMouseOverMarker(' + i + ',' + iZoom + ', event)')
				cMarker.setAttribute("onMouseOut", 'OnMouseOutMarker(event)')
				
				
				
				
				var yfac = 0;
				if (Markers[i].title.substring(0,8)=='station_') yfac = 10
				
				var lon = Markers[i].lon
				var lat = Markers[i].lat
//				if (i == 2) {
//				    alert("cH= "+ cH + "  getX= " + Markers[i].getX(iZoom) + "  getY= " + Markers[i].getY(iZoom));
//				    alert("alfa= " + alfa);
//                }
				var npx = Math.round(Markers[i].getX(iZoom)-(Markers[i].width/2))
				var npy = Math.round((cH - Markers[i].getY(iZoom)-(Markers[i].height/2)))
				var alfa = Math.round(Math.atan2((-1)*npy,npx)*(180/Math.PI))
				
				var colorY = "0px"
				var colorX = ((-1)*alfa*48)+'px'
				var textColor = 'FFFFFF';
				if (Markers[i].color=='22') {colorY='0px'}
				if (Markers[i].color=='16') {colorY='-48px'}
				if (Markers[i].color=='23') {colorY='-96px'}
				if (Markers[i].color=='08') {colorY='-144px'; textColor='0000000'}
				if (Markers[i].color=='18') {colorY='-192px'}	
				
				
				cMarker.style.left = npx+'px'
				cMarker.style.top = npy+'px'
				
				cMarker.style.zIndex = '300';
				cMarker.style.position = 'absolute';

				cMarker.style.backgroundImage=''
				cMarker.style.overflow='hidden'

				var radius = 14
				var pi = 3.14159
				var cosAlfa = Math.cos(alfa * (pi/180))
				var sinAlfa = Math.sin(alfa * (pi/180))
				
				var nPozX = ((cosAlfa*radius)-4)+24
				var nPozY = ((sinAlfa*radius)-4)+24
				
				var MarkerColor = Markers[i].color  // LightBlue, Red, DarkBlue, Green, Yellow, Gray, Black, Orange, RedBlue
				
				
				cMarker.innerHTML = '<div class="gnMarker'+MarkerColor+' fontMainMenu"><strong>'+Markers[i].label+'</strong></div><div class="gnMarkerPointer'+MarkerColor+'" style="left:'+nPozX+'px; top:'+nPozY+'px; height:6px; width:6px; position:absolute"></div>'
				
				cElement.appendChild(cMarker);	
				if (Markers[i].visible==false) cMarker.style.display='none'
	
				
			} // Vozila
			
			
			//
					
					
				
		
			
		}
		
		var cntNM = qMarkers.length
		if (cntNM==null) cnt=0
		
		for (var i=0; i<cntNM; i++){
				var cMarker = document.createElement('div');
				cMarker.setAttribute("id","gnMarker_station_" + i)
				cMarker.style.width = '48px'
				cMarker.style.height = '48px'
				
				var yfac = 10;
				
				var npx = qMarkersX[i]
				var npy = qMarkersY[i]
								
				
				cMarker.style.left = npx+'px'
				cMarker.style.top = npy+'px'
						
				cMarker.style.zIndex = '300';
				cMarker.style.position = 'absolute';
				
				
				cElement.appendChild(cMarker);	
			
				//cMarker.setAttribute("OnMouseOver","m.OnMarkerOver("+i+")")
				//cMarker.setAttribute("OnMouseOut","document.getElementById('popupStation').style.display='none'")
				cMarker.style.backgroundImage = 'URL(images/pin.png)'
				cMarker.innerHTML = ""
		}
		//if (cntNM>0) alert(cntNM)
		//pApplayFilter()
		//
	}
	this.OnMarkerOver = function(no){
		
		var lft = document.getElementById('gnMarker_'+Markers[no].title).offsetLeft
		var tp = document.getElementById('gnMarker_'+Markers[no].title).offsetTop
		///alert( cElement.offsetLeft+lft)
		document.getElementById('popupStation').style.display = ''
		document.getElementById('popupStation').style.left = (cElement.offsetLeft+lft-8) + 'px'
		document.getElementById('popupStation').style.top = (cElement.offsetTop+tp-60) + 'px'
		document.getElementById('popupStation').innerHTML = '&nbsp;<img src="Images/infoD.png" width="24" height="24" border="0" align="absmiddle">'+Markers[no].html
		document.getElementById('popupStation').style.paddingTop = '8px'
		document.getElementById('popupStation').style.paddingLeft = '4px'
		document.getElementById('popupStation').style.paddingRight = '4px'
		
		document.getElementById('popupStation').style.fontFamily = 'Arial'
		document.getElementById('popupStation').style.fontSize = '11'
		document.getElementById('popupStation').style.color = '#FFFFFF'
		
	}

	function pSetCenterLL(lon, lat){

	    if (MapType == "GLOBSY") {
	        var pX = 0 //ms.Lon2X(lon, cZoom)
	        var pY = 0 //ms.Lat2Y(lat, cZoom)

	        var uu2 = new Array(2)
	        uu2 = ms.LonLat2XY(parseFloat(lon), parseFloat(lat), cZoom)

	        pX = uu2[0];
	        pY = uu2[1]
	        var coo = new Coordinates();
	        var uu1 = new Array(2)
	        uu1 = coo.LLtoUTM(parseFloat(ms.Items[0].pointBX), parseFloat(ms.Items[0].pointBY))
	        //alert(uu1[0]+'  '+uu1[1])
	        //alert(cElement.offsetHeight+"   "+cElement.offsetHeight + "   " + cElement.offsetLeft + "   " + cElement.offsetTop + "   " + document.body.clientWidth + "   " + document.body.clientHeight + "   " + pX + "   " + pY);
	        pY = cElement.offsetHeight - pY
	        var _Move = false

	        if (pX + cElement.offsetLeft < 0 || pX + cElement.offsetLeft > document.body.clientWidth) { _Move = true }
	        if (pY + cElement.offsetTop < 0 || pY + cElement.offsetTop > document.body.clientHeight) { _Move = true }

			_Move = true;
	        var pointX = 0 - pX + (cWidth() / 2)
	        var pointY = 0 - pY + (cHeight() / 2)

	        if (_Move == true) {
	            cElement.style.left = pointX
	            cElement.style.top = pointY
	        }

	        pLoadImages();
	    } else {
	        gmap.setCenter(new google.maps.LatLng(parseFloat(lat), parseFloat(lon)), gmap.getZoom());
	    }
	}

	this.ZoomIn = function(){
		pZoomIn()
	}
	
	function pZoomIn(){
	
		inZoomProc = true
		var pX = (0 - cElement.offsetLeft) + (cWidth() / 2);
		var pY = (0 - cElement.offsetTop) + (cHeight() / 2);
		
		pY = cElement.offsetHeight - pY
		
		var uu = new Array(2)
		uu = ms.XY2LonLat(parseFloat(pX),parseFloat(pY), cZoom)
		lon = uu[1]
		lat = uu[0]
		
		//alert('lon='+lon+'   lat='+lat)		
		GoNextZoom(lon, lat)	
	}

	this.ZoomOut = function(){
		pZoomOut()
	}
	
	function pZoomOut(){
		var pX = (0-cElement.offsetLeft)+(cWidth()/2)
		var pY = (0-cElement.offsetTop)+(cHeight()/2)
		pY = cElement.offsetHeight - pY 
		var lon, lat
		//lon = ms.X2Lon(pX, cZoom)
		//lat = ms.Y2Lat(pY, cZoom)
		
		var uu = new Array(2)
		uu = ms.XY2LonLat(parseFloat(pX),parseFloat(pY), cZoom)
		lon = uu[1]
		lat = uu[0]
		
		GoPrevZoom(lon, lat)		
	}


	// Odi na nareden ZOOM
	// Ovaa funkcija se povikuva na: MouseScroll, DoubleClick, ikonkata Plus
	// I ne samo so zumira tuku i ja pozicionira mapata so centar Lon, Lat
	this.GetMapSet = function() {
	    return CurrentMapSet
	}
	function GoNextZoom(lon, lat){
	    ms.getNewarestCity(lon, lat);
	    var PrevMapSet = ms.Items[cZoom].ZoomLevel.substring(ms.Items[cZoom].ZoomLevel.length - 2, ms.Items[cZoom].ZoomLevel.length);
		//$('#btnStation').css("display",'none')
		if ((cZoom==0) || (cZoom==1) || (cZoom==2)) {
		    if (lat > 42.176228) {
				// Kosovo
				ms.Items[1] = ms.ItemsKS[1]
				ms.Items[2] = ms.ItemsKS[2]
				ms.Items[3] = ms.ItemsKS[3]
				ms.Items[4] = ms.ItemsKS[4]
				m.CurrentMapSet = 'KO'
				
			} else {
				//Makedonija
				ms.Items[1] = ms.ItemsMK[0]
				ms.Items[2] = ms.ItemsMK[1]				
				ms.Items[3] = ms.ItemsMK[2]
				ms.Items[4] = ms.ItemsMK[3]
				m.CurrentMapSet = 'MK'				
			}
        }
        /*if ((cZoom == 2) && (CurrentMapSet=='KO')) {
				ms.Items[3] = ms.Items[3]
				ms.Items[4] = ms.Items[4]
        }*/
        if ((cZoom == 2 || cZoom == 3) && m.CurrentMapSet == 'KO' && PrevMapSet == 'KO') {
            cZoom = 4;
        }
        if ((cZoom == 2 || cZoom == 3) && m.CurrentMapSet == 'KO' && PrevMapSet == 'MK') {
            cZoom = 1;
        }		
        
		if (cZoom<4){
			var tmpEl = cElement;
			cZoom = cZoom + 1;
			CreateBoard(cZoom);
			pSetCenterLL(lon, lat);
			//ms.getNewarestCity(lon, lat); ideja e deka pointAX, pointAY, pointBX, pointBY gi zima celo vreme od Skopje, a treba na zoom 5 i 6 da gi zima od gradovi...
			if (FromScrool==true) {
				var tmpX = (Container.offsetWidth / 2 ) - screenX
				var tmpY = (Container.offsetHeight / 2 ) - screenY
				cElement.style.left = cElement.offsetLeft + tmpX
				cElement.style.top = cElement.offsetTop + tmpY				
			}
			FromScrool = false
			pLoadImages()	
			tmpEl.style.zIndex = 20
			pRemoveElement(Container.id, tmpEl.id, 10)
			//Container.removeChild(tmpEl)
			//cZoomTrack.style.top = 170 - (15 * cZoom) 
			
			if ((cZoom == 5) && (m.CurrentMapSet == 'KO')) {$$('#btnStation').css(['display:'])}
			if ((cZoom == 6) && (m.CurrentMapSet == 'KO')) {$$('#btnStation').css(['display:'])}
			
			
			return false
		}
		if ((cZoom==4)){
			//alert(lon+' '+lat)
			if ((lon>=ms.Items[5].pointAX) && (lon<=ms.Items[5].pointBX) && (lat>=ms.Items[5].pointAY) && (lat<=ms.Items[5].pointBY)) {
                var tmpEl = cElement;
				cZoom = cZoom + 1;
                CreateBoard(cZoom);
				pSetCenterLL(lon, lat)

				if (FromScrool==true) {
					var tmpX = (Container.offsetWidth / 2 ) - screenX
					var tmpY = (Container.offsetHeight / 2 ) - screenY
					cElement.style.left = cElement.offsetLeft + tmpX
					cElement.style.top = cElement.offsetTop + tmpY
	            }
	            
				FromScrool = false
				pLoadImages()
				tmpEl.style.zIndex = 20;
				
				pRemoveElement(Container.id,tmpEl.id, 10)
				//Container.removeChild(tmpEl)
				//cZoomTrack.style.top = 170 - (15 * cZoom);
				if ((cZoom == 5)) {$$('#btnStation').css(['display:'])}
				return false
			}
		}
		if (cZoom==5){
			if ((lon>=ms.Items[6].pointAX) && (lon<=ms.Items[6].pointBX) && (lat>=ms.Items[6].pointAY) && (lat<=ms.Items[6].pointBY)) {
				var tmpEl = cElement;
				cZoom = cZoom + 1;
				CreateBoard(cZoom);
				pSetCenterLL(lon, lat)
				if (FromScrool==true) {
					var tmpX = (Container.offsetWidth / 2 ) - screenX
					var tmpY = (Container.offsetHeight / 2 ) - screenY
					cElement.style.left = cElement.offsetLeft + tmpX
					cElement.style.top = cElement.offsetTop + tmpY				
				}
				FromScrool = false
				pLoadImages()	
				tmpEl.style.zIndex = 20
				pRemoveElement(Container.id,tmpEl.id, 10)
				//Container.removeChild(tmpEl)
				//cZoomTrack.style.top = 170 - (15 * cZoom) 
				if ((cZoom == 6)) {$$('#btnStation').css(['display:'])}
				
				
				
			}	
		}
		
	}


	function GoPrevZoom(lon, lat){
		if (cZoom>0){

		    ms.getNewarestCity(lon, lat);
		    //$('#btnStation').css("display",'none')
		    if ((cZoom == 0) || (cZoom == 1) || (cZoom == 2)) {
		        if (lat > 42.176228) {
		            // Kosovo
		            ms.Items[1] = ms.ItemsKS[1]
		            ms.Items[2] = ms.ItemsKS[2]
		            ms.Items[3] = ms.ItemsKS[3]
		            ms.Items[4] = ms.ItemsKS[4]
		            m.CurrentMapSet = 'KO'

		        } else {
		            //Makedonija
		            ms.Items[1] = ms.ItemsMK[0]
		            ms.Items[2] = ms.ItemsMK[1]
		            ms.Items[3] = ms.ItemsMK[2]
		            ms.Items[4] = ms.ItemsMK[3]
		            m.CurrentMapSet = 'MK'
		        }
		    }

		    if ((cZoom == 5 || cZoom == 4) && (m.CurrentMapSet == 'KO')) {
		        cZoom = 3;
		    }

			var tmpEl = cElement;
			cZoom = cZoom - 1;
			CreateBoard(cZoom);
			pSetCenterLL(lon, lat)
			pLoadImages()
			tmpEl.style.zIndex = 20;
			
			pRemoveElement(Container.id,tmpEl.id, 10)
			//Container.removeChild(tmpEl)
			//cZoomTrack.style.top = 170 - (15 * cZoom) 
			$$('#btnStation').css(['display:none'])

			if ((cZoom == 6)) { $$('#btnStation').css(['display:none']); }
			if ((cZoom == 5)) { $$('#btnStation').css(['display:none']); }

			return false
		}		
	}

	this.RemoveElement= function(con, elid, tr){
		pRemoveElement(con, elid, tr)
	}
	
	function pRemoveElement(con, elid, tr){
	    
		//document.getElementById(elid).style.opacity = (tr/10);
		//document.getElementById(elid).style.filter = 'alpha(opacity=' + (tr*10) + ')';
		tr = tr -1
		if (tr>0) {
				$$('#'+elid).fadeOut('fast', function() {
					document.getElementById(con).removeChild(document.getElementById(elid))	
				})
				//setTimeout("m.RemoveElement('"+con+"', '"+elid+"',"+tr+")",50)
		} else {
			document.getElementById(con).removeChild(document.getElementById(elid))
		}
	}

	this.AnimeToCenter = function (stepX, stepY, count, lon, lat){
		Anime2Center(stepX, stepY, count, lon, lat)
	}
	
	this.AnimeToCenter2 = function (stepX, stepY, count){
		Anime2Center2(stepX, stepY, count)
	}
	
	
	function Anime2Center(stepX, stepY, count, lon, lat ){
			cElement.style.left = cElement.offsetLeft + stepX + 'px'
			cElement.style.top = cElement.offsetTop + stepY + 'px'
			count = count -1 
			if (count >=0) {
					setTimeout("m.AnimeToCenter("+stepX+","+stepY+","+count+", "+lon+", "+lat+")", 50)	
			} else {
				GoNextZoom(lon, lat)
				pLoadImages()	
			}
	}
	
	function Anime2Center2(stepX, stepY, count ){
			if (stepX !=0) {cElement.style.left = cElement.offsetLeft + stepX + 'px'}
			if (stepY!=0) {cElement.style.top = cElement.offsetTop + stepY + 'px'}
			count = count -1 
			if (count >=0) {
				setTimeout("m.AnimeToCenter2("+stepX+","+stepY+","+count+")", 50)	
			} else {
				pLoadImages()	
			}
	}

	// ***** Events ***** //

	function selectmouse(e){
		if (MapType == "GLOBSY") {
			if (btnStationAdd==1) {
				var xClick = nn6 ? e.clientX : event.clientX;
				var yClick = nn6 ? e.clientY : event.clientY;
				
				var pX =  0 - cElement.offsetLeft + xClick - Container.offsetLeft
				var pY =  0 - cElement.offsetTop + yClick - Container.offsetTop
				
				pY = cElement.offsetHeight - pY 
				
				var lon, lat
				var uu = new Array(2)
				uu = ms.XY2LonLat(parseFloat(pX+8),parseFloat(pY-8), cZoom)
				
				lon = uu[1]
				lat = uu[0]
				//$$.msgbox("info", lon + " " + lat)
				//$('#txt_lon').val(lon)
				//$('#txt_lat').val(lat)
				//$('#txt_poidesc').val('')
				//$('#txt_poidesc').setFocus()
				
				//ShowPOI()
				//var obj = document.getElementById('btnStationAdd')
				//obj.style.backgroundPosition = '0px 0px'
				//btnStationAdd = 0	
				AddToArea(lon, lat)
				return false
			}
		} else {
			return false	
		}
	  	isdrag = true;
		tx = parseInt(cElement.style.left+0);
		ty = parseInt(cElement.style.top+0);
		x = nn6 ? e.clientX : event.clientX;
		y = nn6 ? e.clientY : event.clientY;
		//document.onmousemove=movemouse;
		
		return false;		
	}
	
	function mouseup(e){
		isdrag=false;
		//window.setTimeout("m.LoadImages()",100);
		//var pixel1 = map.getPixelFromLonLat(map.getCenter());
		//var pixel = new OpenLayers.Pixel((pixel1.x + (e.clientX - pixel1.x)), pixel1.y);
		//var coord = map.getLonLatFromPixel(pixel);
		//debugger;
		var pX =  0 - cElement.offsetLeft + (document.body.clientWidth/2) - Container.offsetLeft;
		var pY =  0 - cElement.offsetTop + (document.body.clientHeight/2) - Container.offsetTop;
		pY = cElement.offsetHeight - pY;
		var uu = new Array(2);
		uu = ms.XY2LonLat(parseFloat(pX),parseFloat(pY), cZoom);
		lon = uu[1];
		lat = uu[0];
		//map.setCenter(new OpenLayers.LonLat(lon, lat).transform(new OpenLayers.Projection("EPSG:4326"), map.getProjectionObject()), 17);
		pLoadImages();
		if (cElement!=null) {
			if (btnStationAdd==1) {cElement.style.cursor='crosshair'} else {cElement.style.cursor='URL(Images/openhand.ico), default'}
		};	
		
	}

	//this.VehicleUnderMouse = ''
	
	function FindVehicleUnderMouse(xPos , yPos){
		if (MapType == "GOOGLE") {VehicleUnderMouse="";return false}
		var str = ''
		NoVehicleUnderMouse = 0
		var c = 0
		for (var i=0; i<MarkersCount; i++) {
			var mar = document.getElementById("gnMarker_" + Markers[i].title)
			if (mar!=null) {			
				if (Markers[i].title.substring(0,8)!='station_') {
				if (((xPos-30)<mar.offsetLeft+24) && ((xPos+30)>mar.offsetLeft+24) && ((yPos-30)<mar.offsetTop+24) && ((yPos+30)>mar.offsetTop+24)){
					//str = str + Markers[i].label+'  '
					str = str + '<div style="height:33px; width:48px; text-align:center; padding-top:15; background-image: url(images/statuses.png); background-position:'+mar.style.backgroundPosition+'; float:left; color:#FFF">'+Markers[i].label+'</div>'
					c = c + 1
					if (c==15){
						c=0;
						str = str + '<br>'
						
					}
					NoVehicleUnderMouse = NoVehicleUnderMouse + 1
				}
				}
			}
		}
		VehicleUnderMouse = str
		//document.getElementById("temp").innerHTML = str
	}
	
	function movemouse(e)
	{
	  screenX =nn6 ? e.clientX : event.clientX;
	  screenY =nn6 ? e.clientY : event.clientY; 
      var tmpX = screenX - cElement.offsetLeft
	  var tmpY = screenY - cElement.offsetTop
	  //FindVehicleUnderMouse(tmpX, tmpY)
	  //document.getElementById("temp").innerHTML 
	  //if (btnStationAdd==1) {cElement.style.cursor='crosshair'} else {cElement.style.cursor='URL(Images/openhand.ico), default'}
	
	  if (isdrag)
	  {
		var tmpLeft = nn6 ? tx + e.clientX - x : tx + event.clientX - x;
		var tmpTop = nn6 ? ty + e.clientY - y : ty + event.clientY - y;
		
		//if (tmpLeft>0) tmpLeft=0
		//if (tmpLeft<Container.offsetWidth-cElement.offsetWidth) tmpLeft=Container.offsetWidth-cElement.offsetWidth
		//if (tmpTop>0) tmpTop=0
		//if (tmpTop<Container.offsetHeight-cElement.offsetHeight) tmpLeft=Container.offsetHeight-cElement.offsetHeight
		
		/*if (btnStationAdd==0) {
			cElement.style.cursor='URL(images/closedhand.ico), default'
		} else {
			cElement.style.cursor='crosshair'
		}*/
		cElement.style.left = tmpLeft;
		cElement.style.top = tmpTop;

		if (cElement.offsetLeft > 0) { cElement.style.left = '0px' }
		if (cElement.offsetTop > 0) { cElement.style.top = '0px' }
		if (cElement.offsetLeft < Container.offsetWidth - cElement.offsetWidth) { cElement.style.left = (Container.offsetWidth - cElement.offsetWidth) + 'px' }
		if (cElement.offsetTop < Container.offsetHeight - cElement.offsetHeight) { cElement.style.top = (Container.offsetHeight - cElement.offsetHeight) + 'px' }
		

		return false;
	  } 
	}

	function dblClick(e){
		var xClick = nn6 ? e.clientX : event.clientX;
		var yClick = nn6 ? e.clientY : event.clientY;
		
		var pX =  0 - cElement.offsetLeft + xClick - Container.offsetLeft
		var pY =  0 - cElement.offsetTop + yClick - Container.offsetTop
		
		var cX = cWidth() /2
		var cY = cHeight() /2
		
		var stepX = (cX - (xClick - Container.offsetLeft)) / 10
		var stepY = (cY - (yClick - Container.offsetTop)) / 10
		
		pY = cElement.offsetHeight - pY 
		
		
		var lon, lat
		//lon = ms.X2Lon(pX, cZoom)
		//lat = ms.Y2Lat(pY, cZoom)
		
		var uu = new Array(2)
		uu = ms.XY2LonLat(parseFloat(pX),parseFloat(pY), cZoom)
		lon = uu[1]
		lat = uu[0]
		
		//alert(lon+' '+lat)
		
		if ((Math.abs(stepX)<3) && (Math.abs(stepY)<3)) {
			Anime2Center(stepX, stepY, 0, lon, lat)
		} else {
			Anime2Center(stepX, stepY, 10, lon, lat)
		}
		
		
	}

this.Delay = function(count){
	pDelay(count)
}
var IsDelayed = false

function pDelay(count){
	count = count - 1
	IsDelayed = true;
	if (count>0) {setTimeout('m.Delay('+count+')',200)}	
	if (count==0) {IsDelayed = false}	
	
}

function handle(delta, e) {
    inZoomProc = true
    var xClick = nn6 ? e.clientX : event.clientX;
    var yClick = nn6 ? e.clientY : event.clientY;

    var pX = 0 - cElement.offsetLeft + xClick - Container.offsetLeft
    var pY = 0 - cElement.offsetTop + yClick - Container.offsetTop
    pY = cElement.offsetHeight - pY

    var uu = new Array(2)
    uu = ms.XY2LonLat(parseFloat(pX), parseFloat(pY), cZoom);
    lon = uu[1];
    lat = uu[0];

    SetCenter(lon, lat);

    if (delta < 0) {
        if (IsDelayed == false) {
            if (MapType == "GLOBSY") {
                //pZoomOut();
                GoPrevZoom(lon, lat)
                var stepLeft = (document.body.clientWidth / 2) - xClick
                var stepTop = (document.body.clientHeight / 2) - yClick
                cElement.style.left = (cElement.offsetLeft - stepLeft) + 'px'
                cElement.style.top = (cElement.offsetTop - stepTop) + 'px'

                pDelay(6)
            } else {
                if (gmap.getZoom() < 16)
                    $$('#btnStation').css(['display:none']);
            }
        }

    } else {
        if (IsDelayed == false) {
            //FromScrool = true;
            if (MapType == "GLOBSY") {
                //pZoomIn();
                GoNextZoom(lon, lat)
                var stepLeft = (document.body.clientWidth / 2) - xClick
                var stepTop = (document.body.clientHeight / 2) - yClick
                cElement.style.left = (cElement.offsetLeft - stepLeft) + 'px'
                cElement.style.top = (cElement.offsetTop - stepTop) + 'px'

                pDelay(6)
            } else {
                if (gmap.getZoom() >= 14)
                    $$('#btnStation').css(['display:']);
            }
        }
    }
    //document.getElementById('txt').innerHTML = document.getElementById('txt').innerHTML + '|' + delta
}

function wheel(event) {
    var delta = 0;
    if (!event) event = window.event;
    if (event.wheelDelta) {
        delta = event.wheelDelta / 120;
        if (window.opera) delta = -delta;
    } else if (event.detail) {
        delta = -event.detail / 3;
    }
    if (delta)
        handle(delta, event);
    if (event.preventDefault)
        event.preventDefault();
    event.returnValue = false;


}


}




