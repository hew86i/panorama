﻿<?php
header("Cache-Control: no-store, no-cache, max-age: 0, must-revalidate");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
?><html>
 <head>
   <title>Panorama - Geonet GPS Fleet Management Solution</title>
   <meta http-equiv="x-ua-compatible" content="chrome=1" />
 </head>
<body style="margin: 0; padding: 0">
 <iframe  frameborder="0" src ="./" name="x" width="100%" height="100%" style="overflow: hidden"> </iframe>
</body>
</html>