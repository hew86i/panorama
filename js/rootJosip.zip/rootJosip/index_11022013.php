<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>
<?php include "./include/params.php" ?>
<?php include "./include/dictionary1.php" ?>
<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
	//Ispituvame dali ima najaven korisnik. Ako nema mora da se odi na Login
	if (!is_numeric(session('user_id'))) echo header( 'Location: ./login/?l='.$cLang);
	opendb();
	
	$err = getQUERY("err");
	
	$ds = query("select allowedrouting, allowedfm from clients where id=" . session("client_id"));
	$allowedR = pg_fetch_result($ds, 0, "allowedrouting");
	$allowedF = pg_fetch_result($ds, 0, "allowedfm");
	
	$filename = './images/upload/' . session("client_id") . '.png';
	$picload = 'profile.png';
	if (file_exists($filename)) {
	    $picload = session("client_id") . '.png';
	}
	$AllowViewLiveTracking = getPriv("livetracking", session("user_id"));
	$AllowViewFm = getPriv("fm", session("user_id"));
	$AllowViewRoutes = getPriv("routes", session("user_id"));
	$AllowViewReports = getPriv("reports", session("user_id"));
	$AllowViewSettings = getPriv("settings", session("user_id"));
	
	$lt = '';
	$lt1 = '';
	$fm = '';
	$fm1 = '';
	$reports = '';
	$reports1 = '';
	$settings = '';
	$settings1 = '';
	$routes = '';
	$routes1 = '';
	if(!$AllowViewLiveTracking)
	{
		$lt = 'return false;';
		$lt1 = 'opacity: 0.5;';
	}
	if(!$AllowViewReports)
	{
		$reports = 'return false;';
		$reports1 = 'opacity: 0.5;';
	}
	if(!$AllowViewSettings)
	{
		$settings = 'return false;';
		$settings1 = 'opacity: 0.5;';
	}
	if(!$AllowViewFm)
	{
		$fm = 'return false;';
		$fm1 = 'opacity: 0.5;';
	}
	if(!$AllowViewRoutes)
	{
		$routes = 'return false;';
		$routes1 = 'opacity: 0.5;';
	}
	closedb();
?>

<html>
<head>
	<script> 
		lang = '<?php echo $cLang?>';
	</script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Panorama - Geonet GPS Fleet Management Solution</title>
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.custom.css">
	<LINK REL="SHORTCUT ICON" HREF="./images/icon.ico">
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/roundIE.js"></script>
	<script type="text/javascript" src="./js/jquery-ui.js"></script>
</head>
<body onResize="setElementToCenter()">
	<div id="main-blue-track"></div>
	<div id="main-container">
		<img id="img-logo" src="./images/Logo.png" width="200" height="94" alt="" />
		<div id="div-advert" class="textTitle">
			<?php echo dic("Login.Title")?><br><br>
		    <span class="text1"><strong><?php echo dic("Login.Panorama")?></strong> - <?php echo dic("Login.Description")?></span>
		</div>
		<div id="div-lang">
			<a id="icon-mk" href="./?l=mk"><img src="./images/mk.png" width="30" height="30" border="0" align="absmiddle" style=""/></a>&nbsp;&nbsp;&nbsp;
			<a id="icon-en" href="./?l=en"><img src="./images/en.png" width="30" height="30" border="0" align="absmiddle"/></a>&nbsp;&nbsp;&nbsp;
			<a id="icon-fr" href="./?l=fr"><img src="./images/fr.png" width="30" height="30" border="0" align="absmiddle"/></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a id="icon-logout" href="./logout/?l=<?php echo $cLang?>"><img src="./images/exit1.png" width="30" height="30" border="0" align="absmiddle"/></a>&nbsp;<br>
		</div>
		<div id="div-profile" style=" height:180px;">
            <div id="divUploadProgress" style="padding-top:4px;display:block; height: 93px; width: 107px; background: transparent url('./images/upload/<?php echo $picload?>') no-repeat scroll 0 0;" class="text3">
            </div>
            <div id="loged-user" class="textTitle"><?php echo session("user_fullname")?></div>
			<div id="loged-company" class="text1"><strong><?php echo session("company")?></strong></div>
		</div>
		<a href="./tracking/?l=<?php echo $cLang?>" onclick="<?php echo $lt?>" class="menu corner15" style="left:10px; top:270px;<?php echo $lt1?>">
			<img class="imgMenu" src="./images/map.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.LiveTitle")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.Live")?></span>
		</a>
		<a href="./report/?l=<?php echo $cLang?>#rep/menu_1_1" onclick="<?php echo $reports?>" class="menu corner15" style="left:540px; top:270px;<?php echo $reports1?>">
			<img class="imgMenu" src="./images/document.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.ReportsTitle")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.Reports")?></span>
		</a>
		<a href="./settings/?l=<?php echo $cLang?>" onclick="<?php echo $settings?>" class="menu corner15" style="left:10px; top:370px;<?php echo $settings1?>">
			<img class="imgMenu" src="./images/settings.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.SettingsTitle")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.Settings")?></span>
		</a>
		<a href="<?php echo $RootPath?>texts/help.php?l=<?php echo $cLang?>" class="menu corner15" style="left:540px; top:370px;">
			<img class="imgMenu" src="./images/help.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.HelpTitle")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.Help")?></span>
		</a>
		<?php
		if($allowedF == '1')
		{
			?>
		<a href="./fm/?l=<?php echo $cLang?>" onclick="<?php echo $fm?>" class="menu corner15" style="left:540px; top:370px;<?php echo $fm1?>">
			<img class="imgMenu" src="./images/fm.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.fm")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.fm1")?></span>
		</a>
		<?php
		}
		if($allowedR == '1')
		{
			?>
		<a href="./routes/?l=<?php echo $cLang?>" onclick="<?php echo $routes?>" class="menu corner15" style="left:10px; top:470px;<?php echo $routes1?>">
			<img class="imgMenu" src="./images/Routing.png" width="64" height="64" border="0" align="absmiddle"/>
			<span class="lbl-menu-text textTitle"><?php echo dic("Main.routess")?></span>
			<span class="lbl-menu-desc text1"><?php echo dic("Main.routess1")?></span>
		</a>
		<?php
		}
		?>
	</div>
	
	<div id="footer-rights" class="textFooter"><a href="<?php echo $CopyrightLink?>" class="textFooter" target="_blank"><?php echo $CopyrightString?></a></div>
	<div id="footer-legacy" class="textFooter"> <a href="#" class="textFooter"><?php echo dic("Login.Legal")?></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#" class="textFooter"><?php echo dic("Login.Privacy")?></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#" class="textFooter"><?php echo dic("Login.Help")?></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#"  class="textFooter"><?php echo dic("Login.Support")?></a></div>


	<div id="dialog-message" title="<?php echo  dic("alerttGF")?>" style="display:none">
		<p>
			<span class="ui-icon ui-icon-circle-minus" style="float:left; margin:0 7px 20px 0;"></span>
			<div id="div-msgbox" style="font-size:14px"></div>
		</p>
	</div>

</body>
</html>
<script>
    if ('<?php echo $err?>' == 'permission') { mymsg('<?php echo dic("Login.PermMenu")?>'); }
</script>
