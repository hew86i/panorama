﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>
<?php session_start()?>
<?php

	opendb();
	$vehid = str_replace("'", "''", NNull($_GET['vehid'], ''));
	
	RunSQL("delete from phoenixclients where vehicleid=" . $vehid);
	
	closedb();
?>