﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php

	$dir1 = "/home/Logs/buffer/";
	$dir2 = "/home/Logs/bufferBackup/";
	$dirHandle1 = opendir($dir1); 
	$now = now();//'2014-04-03 09:46:10';//now();
	$lastMinute = addToDate($now, -1, "minute");
	$lastMinute = DateTimeFormat($lastMinute, 'd-m-Y H:i');
	
	while ($file1 = readdir($dirHandle1)) {		 
	    if(is_file($dir1 . $file1)) {
	    	$fn = explode("PhoenixBuffer_", $file1);
			$fn1 = explode(".log", $fn[1]);
			//if ($lastMinute == $fn1[0]) {
				$ret = file_get_contents($dir1 . $file1);
				opendb();
				$r = runsql($ret);

				chmod ($dir2 . $file1, 0777);
				if (copy($dir1 . $file1, $dir2 . $file1)) {
					unlink($dir1 . $file1);
				}
								
				closedb();
			//}
	    }
	}
	closedir($dirHandle1);
			
?>

