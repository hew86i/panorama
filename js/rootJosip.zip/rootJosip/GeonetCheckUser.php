﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");

    opendb();

	$fullname = getQUERY("fullname");
	$ifExist = dlookup("select count(*) from geonetcandidate where fullname='".$fullname."'");
	echo $ifExist;
	
    closedb();
	
?>



