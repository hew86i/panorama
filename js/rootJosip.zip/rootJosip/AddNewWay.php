﻿<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>

<?php include "./include/params.php" ?>
<?php session_start()?>
<?php
    
    header("Expires: Mon, 20 Jul 2000 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", FALSE);
    header("Pragma: no-cache");
	set_time_limit(0);
	opendb();

	$name = str_replace("'", "''", NNull($_GET['name'], ''));
	$line = str_replace("'", "''", NNull($_GET['line'], ''));
	//echo "insert into planet_osm_line (osm_id, cutting, embankment, highway, name, width, z_order, way, utm) value ('123456789', 'yes', 'no', 'residential', '" . $name . "', '2.5', '3', st_transform(ST_GeomFromText('" . $line . "', 4326), 900913), st_transform(ST_GeomFromText('" . $line . "', 4326), 26986))";
    $test1 = query("select min(osm_id)-1 osm_id from planet_osm_line");
	$minosmid = pg_fetch_result($test1, 0, "osm_id");
    $test = query("insert into planet_osm_line (osm_id, cutting, embankment, highway, name, width, z_order, way, utm) values ('" . $minosmid . "', 'yes', 'no', 'residential', '" . $name . "', '2.5', 3, st_transform(ST_GeomFromText('" . $line . "', 4326), 900913), st_transform(ST_GeomFromText('" . $line . "', 4326), 26986))");
	$testID = query("insert into tempinsertdelete (osm_id, name, ipaddress, type) values ('" . $minosmid . "', '" . $name . "', '" . getIP() . "', 'insert')");
	//$strName = pg_fetch_result($dsName, 0, "name");
	//$strLonLat = pg_fetch_result($dsName, 0, "way");
    print "Успешно внесен нов пат!<br />".$name;
  	closedb();  
?>