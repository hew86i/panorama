﻿<?php include "../include/db.php" ?>
<?php include "../include/functions.php" ?>
<?php include "../include/params.php" ?>
<?php include "../include/dictionary2.php" ?>

<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<script>
		lang = '<?php echo $cLang?>'
	</script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

   	<link rel="stylesheet" type="text/css" href="../style.css">
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/share.js"></script>
	<script type="text/javascript" src="../js/iScroll.js"></script>

	<script type="text/javascript" src="reports.js"></script>	
	<link href="../css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="../js/jquery-ui.js"></script>
	
	<script>
  		if (<?php echo nnull(is_numeric(nnull(getQUERY("uid"))), 0) ?> == 0){
  			if (<?php echo nnull(is_numeric(nnull(session("user_id"))), 0) ?> == 0)
  				top.window.location = "../sessionexpired/?l=" + '<?php echo $cLang ?>';
  		} 
  	</script>
  	
</head>
	
	<?php
	
		$meseci = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
	     
		if (nnull(is_numeric(nnull(getQUERY("uid"))), 0)>0){
			$uid = getQUERY("uid");
			$cid = getQUERY("cid");	
		} else {
			$uid = session("user_id");
			$cid = session("client_id");
		}
		 
		opendb();
		
		$Allow = getPriv("detailreport", $uid);
		if ($Allow == False) echo header ('Location: ../permission/?l=' . $cLang);
			    
		$user_id = $uid; //154;////nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
		$client_id = $cid;//154;// //nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
		 
		$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		 
		$vh = nnull(getQUERY("v"), "0"); //645;//
	 	
	 	/*format na datum*/
		$datetimeformat = dlookup("select datetimeformat from users where id=" . $uid);
		$datfor = explode(" ", $datetimeformat);
		$dateformat = $datfor[0];
		$timeformat =  $datfor[1];
		if ($timeformat == 'h:i:s') $timeformat = $timeformat . " a";
		
		if ($timeformat == "H:i:s") {
			$e_ = " 23:59";
			$e1_ = "_23:59";
			$s_ = " 00:00";
			$s1_ = "_00:00";
			$tf = " H:i";
		}	else {
			$e_ = " 11:59 PM";
			$e1_ = "_11:59_PM";
			$s_ = " 12:00 AM";
			$s1_ = "_12:00_AM";
			$tf = " h:i a";
		}		
		
		//$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		
	    $sdG = DateTimeFormat(getQUERY("sd"), 'd-m-Y H:i:s');
		$edG = DateTimeFormat(getQUERY("ed"), 'd-m-Y H:i:s');
		
	    $sd = DateTimeFormat(getQUERY("sd"), $dateformat) . $s_; //'01-09-2012 00:00';
	    $ed = DateTimeFormat(getQUERY("ed"), $dateformat) . $e_; //'01-09-2012 23:59';
		$startDate = ReturnDateInDateM($sd);
		$endDate = ReturnDateInDateM($ed);
		
		$endTime = DateTimeFormat($endDate, "1900-01-01 H:i:s"); 
	    $startTime = DateTimeFormat($startDate, "1900-01-01 H:i:s"); 
	    
		$CreationDate = strtoupper(DateTimeFormat(now(), $datetimeformat));   
		/*format na datum*/
	
		$_frst = "";
		$_frstID = 0;
		
		  
		$sqlV = "";
		if ($vh == "0") {
			if ($_SESSION['role_id'] == "2") { 
		        $sqlV = "select id from vehicles where clientID=" . $client_id;
			} else {
				$sqlV = "select vehicleID from UserVehicles where userID=" . $user_id . "";
			}
		} else {
			$sqlV = $vh;
		}	
		
		$_SESSION["user_fullname"] = dlookup("select fullname from users where id='" . $user_id . "'");
		$_SESSION["company"] = dlookup("select name from clients where id in (select clientid from users where id=" . $user_id . " limit 1) limit 1");
		
		$allCount = 0;
		$km = 0;
		$iskMotor = 0;
		$vozenje = 0;
		$stoenje = 0;
		    
		$langArr = explode("?", getQUERY("l"));
		$cLang = $langArr[0];
	    
		$ifFuel = dlookup("select allowfuel from vehicles where id=" . $vh);	
	?>
	
<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="SetHeightLite()">



<script>

function showHide(vh, div_id){
	var obj = document.getElementById('content-'+div_id+'-'+vh)
	if (obj.style.display=='none') {
		if (obj.innerHTML==''){
			obj.innerHTML = '<br>&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/ajax-loader.gif" align="absmiddle"> ' + '<?php dic("Reports.LoadingData") ?>' + '<br>&nbsp;'
            $(obj).load("LoadDetail.php?v="+vh+"&d="+div_id+"&uid=" + <?php echo $uid?> + "&l="+'<?php echo $cLang ?>')
		}
		obj.style.display=''
		return
	} else {
		obj.style.display='none'
		return
	}

}
	
</script>

<div id="report-content" style="width:100%; text-align:left; height:500px; background-color:#fff; overflow-y:auto; overflow-x:hidden" class="corner5">
	<br><br>
	<?php

		$dsVehicles = query("select * from vehicles where id in (" . $sqlV . ")");
	    
	    $langArr = explode("?", getQUERY("l"));
		$cLang = $langArr[0];
	    
		
		if ($ifFuel == '1') {
			$paddingTop = "30px";
			$heighDiv = "130px";
		} else {
			$paddingTop = "0px";
			$heighDiv = "58px";
		}	
		while ($drVehicle = pg_fetch_array($dsVehicles)) {
			
	?>
	<div class="corner5" style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%">
		<div style="padding-left:40px; padding-top:10px; width:500px;float:left;" class="textTitle">
			<?php echo mb_strtoupper(dic_("Reports.Detail"), 'UTF-8') ?>&nbsp;&nbsp;&nbsp;&nbsp;
			<div style="font-size:18px" class="textTitle"><?php echo $drVehicle["registration"] . " (" . $drVehicle['code'] . ")"?><br><span style="font-size: 14px;"><?php echo $drVehicle['alias']?></span><br><br></div>
			<span class="text5"> <?php dic("Reports.User")?>: <strong><?php echo session("user_fullname")?></strong></span><br>
			<span class="text5"> <?php dic("Reports.Company")?>: <strong><?php echo session("company")?></strong></span><br>
			<span class="text5"> <?php dic("Reports.CreationDate")?>: <strong><?php echo $CreationDate?></strong></span><br>
			<span class="text5"> <?php dic("Reports.DateTimeRange")?>: <strong><?php echo $sd?></strong> - <strong><?php echo $ed?></strong></span><br><br>
		</div>
		<br><br><br><br>
		
		<!--<div class="corner5 text2" style="position:relative; top:-70px; float:left; right:-50px; display:block; position:relative; width:315px; height:150px; padding-top:2px; padding-left:13px; border:1px solid #d7d4d4; background-color:#fff; margin-top:20px; font-size:12px;">
			<table width="280" align="center" class="text2" style="font-size:14px">
				<tr><td height="22" width="150px"><?php dic("Reports.TotalDist") ?>:</td><td id="td-sum-km-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"></td></tr>
				<tr><td width="150px"><?php dic("Reports.MaximumSpeed") ?>:</td><td width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"></td></tr>
				
				<tr><td width="150px"><?php dic("Reports.SpentFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"></td></tr>
				<tr><td width="150px"><?php dic("Reports.AvgConFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"></td></tr>
				<tr><td width="150px"><?php dic("Reports.AddedFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"></td></tr>			
						
							
			</table>
		</div>
	-->
		<div class="corner5 text2" style="position:relative; float:left; top:-70px; right:-60px; width:315px; height:<?php echo $heighDiv?>; padding-top:2px; padding-left:13px; border:1px solid #d7d4d4; background-color:#fff; margin-left:auto; margin-right:40px; margin-top:20px; font-size:12px;">
			<table width="280" align="center" class="text2" style="font-size:14px">
				<?php
				$all_rastojanie = nnull(dlookup("select SUM(distance) from rShortReport where Datetime>='" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' and  Datetime<='" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59' and vehicleID=" . $vh . " and ignition='0'"),0);
				$all_maxspeed = nnull(dlookup("select MAX(speed)from rMaxSpeed where  Datetime>='" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' and  Datetime<='" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59' and vehicleID=" . $vh . ""),0);
			
				?>
				<tr><td height="22" width="150px"><?php dic("Reports.TotalDist")?>:</td><td id="td-vklmotor-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo number_format($all_rastojanie/1000)?> Km</td></tr>
				<tr><td width="150px"><?php dic("Reports.MaximumSpeed")?>:</td><td id="td-iskmotor-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo intval($all_maxspeed)?> Km/h</td></tr>
				
				<?php
					
					if ($ifFuel == '1') {
						$dsGorivo = query("select * from rep_getFuel(" . $vh . ", '" . DateTimeFormat($sdG, "Y-m-d 00:00:00") . "', '" . DateTimeFormat($edG, "Y-m-d 23:59:59") . "')"); 
						
				        $spentFuel = round(pg_fetch_result($dsGorivo, 0, 1), 1);
				        $addedFuel = round(pg_fetch_result($dsGorivo, 0, 2), 1);
				        
						$pastKm = NNull(DlookUP("select SUM(distance) from rshortreport where vehicleid = " . $vh . " and Datetime > '" . DateTimeFormat($sdG, "Y-m-d") . " 00:00:00' and Datetime < '" . DateTimeFormat($edG, "Y-m-d") . " 23:59:59'"), 0);  
						$pastKm = $pastKm / 1000;

				        $averageFuel = 0;
				        If ($pastKm > 0) {
				            $averageFuel = 100 / $pastKm * $spentFuel;
						}

						?>
				<tr><td width="150px"><?php dic("Reports.SpentFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo $spentFuel ?> L</td></tr>
				<tr><td width="150px"><?php dic("Reports.AvgConFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo round($averageFuel, 1) ?> L/100 Km</td></tr>
				<tr><td width="150px"><?php dic("Reports.AddedFuel") ?>:</td><td " width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo $addedFuel ?> L</td></tr>			
						<?php
					}
				?>
				
			</table>
		</div>
		
		<div class="corner5 text2" style="position:relative; top:-70px; width:275px; height:110px; padding-top:2px; padding-left:13px; border:1px solid #d7d4d4; background-color:#fff; margin-left:auto; margin-right:40px; margin-top:20px; font-size:12px;">
			<table width="250" align="center" class="text2" style="font-size:14px">
				<?php
				
				$dateDiff = dlookup("select datediff('', '" . DateTimeFormat($startDate, "Y-m-d ") . " 00:00:00" . "', '" . DateTimeFormat($endDate, "Y-m-d") . " 23:59:59')");
				$idleover = dlookup("select idleover from users where id=" . $uid);	
				$motoronT = 0;
				$driveT = 0;
				$stayT = 0;
				$motoroffT = 0;
				$parkedT = 0;
				
				
					$_datumCnt  = $sdG;
					
					while (DateDiffDays($edG, $_datumCnt) < 0) {
						$sqlTemp = "select * from get_actduration('" . DateTimeFormat($_datumCnt, "Y-m-d ") . " 00:00:00" . "', '" . DateTimeFormat($_datumCnt, "Y-m-d ") . " 23:59:59" . "', " . $vh . ")";
						$cntData = dlookup("select count(*) from rShortReport WHERE datetime>='" . DateTimeFormat($_datumCnt,"Y-m-d") . " 00:00:00' 
						and datetime<='" . DateTimeFormat($_datumCnt,"Y-m-d") . " 23:59:59' and vehicleID = " . $vh . "");

						if ($cntData > 0) {
							$dsTemp = query($sqlTemp);
							$motoronT += pg_fetch_result($dsTemp, 0, "motoron");
							$driveT += pg_fetch_result($dsTemp, 0, "drive");
							$stayT += pg_fetch_result($dsTemp, 0, "stay");
							$motoroffT += pg_fetch_result($dsTemp, 0, "motoroff");
							$parkedT += pg_fetch_result($dsTemp, 0, "parked");
						}
						$_datumCnt = addToDate($_datumCnt, 1, "days");
					}
					$parkedT = $dateDiff - ($motoronT + $motoroffT);
				?>
				<tr><td height="22" width="150px"><?php dic("Reports.EngineOn")?>:</td><td id="td-vklmotor-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($motoronT)?></td></tr>
				<?php
				if ($idleover == 0) {
					?>
					<tr><td width="150px"><?php dic("Reports.ActivityOn")?>:</td><td id="td-vozenje-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($driveT + $stayT)?></td></tr>
				
					<?php
				} else {
					?>
					<tr><td width="150px"><?php dic("Reports.ActivityOn")?>:</td><td id="td-vozenje-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($driveT)?></td></tr>
					<tr><td width="150px"><?php dic("Reports.Standing")?>:</td><td id="td-stoenje-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($stayT)?></td></tr>
				
					<?php
				}
				?>
				<tr><td width="150px"><?php dic("Reports.EngineOff")?>:</td><td id="td-parked-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($motoroffT)?></td></tr>
				<tr><td width="150px"><?php dic("Reports.Parked")?>:</td><td id="td-parked-<?php echo $drVehicle["id"]?>" width="100px" align="right" style="color:#ff6633; font-size:14px; font-weight:bold"><?php echo sec2str($parkedT)?></td></tr>
			</table>
		</div>
		
		
		<div style="height: 14px">&nbsp;</div>
		<?php 
		
			$datumce = $sdG;
			
			$noPermExc = "";
			$cnt = 0;
			//while ($datumce <= $endDate) {
			 while (DateDiffDays($edG, $datumce) < 0) {
			 		//excel
					$prExcel = getPriv("exportexcel", $user_id);
					$noPermExc = "";	
					$prPdf = getPriv("exportpdf", $user_id);
					if ($prPdf == true) {
						if ($cnt == 0) $pdfStyle = "style='float:right; cursor:pointer'";
						else $pdfStyle = "style='float:right; cursor:pointer; visibility:hidden'";
						//$pdfClick = "createPDF('LoadDetail', DateTimeFormat($datumce, "Y-m-d"))";
						
					}else {
						//$pdfClick = "";
						$pdfStyle = "style='float:right; opacity:0.5; cursor:default'";
						$noPermPdf = dic_("Reports.NoPermiss") . " "; 
					}
					//excel
					$prExcel = getPriv("exportpdf", $user_id);
					if ($prExcel == true) {
						if ($cnt == 0) $excStyle = "style='float:right; cursor:pointer'";
						else $excStyle = "style='float:right; cursor:pointer; visibility:hidden'";
						
					}else {
						$excStyle = "style='float:right; opacity:0.5; cursor:default'";
						$noPermExc = dic_("Reports.NoPermiss") . " "; 
					}
						
		?>
       
		<div id="heder-<?php echo DateTimeFormat($datumce, "Y-m-d")?>"  class="textSubTitle" style="display:block; margin-left:40px;background-color:#f0f0f0; border:1px solid #d9d9d9; width:93%; height:25px; padding-top:5px; text-align:left;  ">
            <span onClick="showHide(<?php echo $drVehicle["id"]?>, '<?php echo DateTimeFormat($datumce, "Y-m-d")?>')" style="cursor:pointer">&nbsp;►&nbsp;<?php echo DateTimeFormat($datumce,"d") . " " . dic_("Reports." . $meseci[intval(DateTimeFormat($datumce, "m")) - 1] . "") . " " . DateTimeFormat($datumce,"Y")?></span>  
	      
	        <!--<div onclick="<?php echo $pdfClick?>" <?php echo $pdfStyle?>>
			    <span id="iconPDF" ><img src="../images/epdf.png" width="16" height="16" align="absmiddle" style="padding-right:13px; position: relative; bottom:2px" title="<?php echo $noPermPdf . "" . dic_("Reports.ExportPDF")?>">&nbsp;</span>
			</div>-->
<?php
if ($prPdf == true) {
?>
	        <div id="pdf-<?php echo DateTimeFormat($datumce, 'Y-m-d')?>" onclick="createPDF('LoadDetail', '<?php echo DateTimeFormat($datumce, 'Y-m-d')?>', <?php echo $drVehicle['id']?>, '<?php echo $cLang ?>', <?php echo $user_id ?>)" <?php echo $pdfStyle?>>
		<?php 
			} else {
		?>


		 <div onclick="" <?php echo $pdfStyle?>>
<?php
}
?>
			    <span id="iconPDF" ><img id="imgPdf" src="../images/epdf.png" width="16" height="16" align="absmiddle" style="padding-right:13px; position: relative; bottom:2px" title="<?php echo $noPermPdf . "" . dic_("Reports.ExportPDF")?>">&nbsp;</span>
			</div>
		<?php
			if ($prExcel == true) {
		?>
	        <div id="xls-<?php echo DateTimeFormat($datumce, 'Y-m-d')?>" onclick="createXls('LoadDetail', 'a', '<?php echo DateTimeFormat($datumce, 'Y-m-d')?>', <?php echo $drVehicle['id']?>, '<?php echo $cLang ?>', <?php echo $user_id ?>, <?php echo $client_id ?>, '<?php echo DateTimeFormat($sdG, "d-m-Y")?>', '<?php echo DateTimeFormat($edG, "d-m-Y")?>')" <?php echo $excStyle?>>
		<?php 
			} else {
		?>

		 <div  onclick="" <?php echo $excStyle?>>
			<?php
			}
			?>
			    <span id="excIcon<?php echo DateTimeFormat($datumce, "Y-m-d")?>" ><img id="imgXls" src="../images/eExcel.png" width="16" height="16" align="absmiddle" style="padding-right:5px; position: relative; bottom:2px" title="<?php echo $noPermExc . "" . dic_("Reports.ExportExcel")?>">&nbsp;</span>
		</div>
		
	<!--        <?php
	        if ($prExcel == true) {
	        ?>
            <a id="excIcon<?php echo $cnt?>" title="<?php dic("Reports.ExportExcel")?>" href="LoadDetail1.php?v=<?php echo $drVehicle["id"]?>&d=<?php echo DateTimeFormat($datumce, "Y-m-d")?>&uid=<?php echo $uid?>$l=<?php echo $cLang ?>&veh=<?php echo $drVehicle["registration"]?>&vehNum=<?php echo $drVehicle["code"]?>&sd=<?php echo DateTimeFormat($startDate, "d-m-Y 00:00") ?>&ed=<?php echo DateTimeFormat($endDate, "d-m-Y 23:59") ?>" style="text-decoration:none">
                <span id="iconCSV" style="cursor:pointer;" ><img src="../images/eExcel.png" width="16" height="16" align="absmiddle" style="border:0; float:right; padding-right:8px; position: relative; top:1px " >&nbsp;</span>
		    </a>
		    <?php
			} else {
				$noPermExc = dic_("Reports.NoPermiss") . " ";  
		    ?>
		    <a id="excIcon<?php echo $cnt?>" title="<?php echo $noPermExc . "" . dic_("Reports.ExportExcel")?>">
                <span id="iconCSV" style="cursor:default; opacity:0.5" ><img src="../images/eExcel.png" width="16" height="16" align="absmiddle" style="border:0; float:right; padding-right:8px; position: relative; top:1px " >&nbsp;</span>
		    </a>
		    <?php
			}
		    ?>-->
		    
		    <!--
		      <?php
			if ($prExcel == true) {
		?>
	        <div onclick="createExcel('LoadDetail', '<?php echo DateTimeFormat($datumce, 'Y-m-d')?>', <?php echo $drVehicle['id']?>, '<?php echo $cLang ?>', <?php echo $user_id ?>)" <?php echo $excStyle?>>
		<?php 
			} else {
		?>

		 <div onclick="" <?php echo $excStyle?>>
			<?php
			}
			?>
			    <span id="iconCSV" ><img src="../images/eExcel.png" width="16" height="16" align="absmiddle" style="padding-right:13px; position: relative; bottom:2px" title="<?php echo $noPermExc . "" . dic_("Reports.ExportExcel")?>">&nbsp;</span>
		</div>	
		    -->
		   
        </div>
   
		<div id="content-<?php echo DateTimeFormat($datumce, "Y-m-d")?>-<?php echo $drVehicle["id"]?>"  class="textSubTitle" style="display:none; margin-left:40px;background-color:#ffffff; border-left:1px solid #d9d9d9; border-right:1px solid #d9d9d9; border-bottom:1px solid #d9d9d9; width:93%; padding-top:5px; text-align:left; font-size:12px;  "></div><br>
		<?php
				if ($_frst == "") { 
					$_frst = DateTimeFormat($datumce, "Y-m-d");
					$_frstID = $drVehicle["id"];
				}
				$datumce = addToDate($datumce, 1, "days");
				$cnt += 1;
			} //end while
		?>
		<br>
		
	</div><br><br>
	<?php
		} // end while
		
		closedb();
	?>

	    
	<div id="footer-rights-new" class="textFooter" style="padding:10px 10px 10px 10px">
			<?php echo $CopyrightString ?>&nbsp;|&nbsp;<?php echo session("company")?>&nbsp;|&nbsp;<?php echo session("user_fullname")?>&nbsp;|&nbsp;<?php echo $CreationDate?>&nbsp;|&nbsp;<?php dic("Reports.From")?>: <?php echo $sd?>&nbsp;-&nbsp;<?php dic("Reports.To")?>: <?php echo $ed?>
		</div><br>
</div>

</body>
</html>

	<script type="text/javascript">
	//za hide na otvoren kalendar
	$(document).click(function(e) { 
		if (top.document.getElementById('doneBtn'))
			top.document.getElementById('doneBtn').click();
	});
	function changeTitle(dt){

		//for (var i=0; i < <?php echo $cnt?>; i++) {
			/*document.getElementById('xls' + dt).title = "";
			document.getElementById('xls' + dt).innerHTML = "<span id='iconCSV' style='cursor:default; opacity:0.5' ><img src='../images/eExcel.png' width='16' height='16' align='absmiddle' style='border:0; float:right; padding-right:5px' >&nbsp;</span>";
			document.getElementById('xls' + dt).href = "javascript:void(0)";

			document.getElementById('pdf' + dt).title = "";
			document.getElementById('pdf' + dt).innerHTML = "<span id='iconPDF' style='cursor:default; opacity:0.5' ><img src='../images/epdf.png' width='16' height='16' align='absmiddle' style='border:0; float:right; padding-right:13px' >&nbsp;</span>";
			document.getElementById('pdf' + dt).href = "javascript:void(0)";
*/
		//}
	}
	SetHeightLite()
	iPadSettingsLite()
	top.HideLoading()
	if (Browser()=='iPad') {top.iPad_Refresh()}
	
	//stoenje
	$(document).ready(function () {
	    top.HideWait();
		showHide(<?php echo $_frstID?>, '<?php echo $_frst?>')
	});
	
	</script>
	
