﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="./amcharts/amcharts.js" type="text/javascript"></script>
<link rel="stylesheet" href="./amcharts/style.css" type="text/css">

 <link rel="stylesheet" href="http:////code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
			lang = '<?php echo $cLang?>'
	</script>
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="/js/jquery.js"></script>
	
	<link href="/css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="/js/jquery-ui.js"></script>
    
<style>
	.hov123:hover{ opacity: 0.8; }
	#chartdiv {
		width	: 100%;
		height	: 300px;
	}
</style>
</head>
	
<?php
		opendb();
		$cntHavaData = 0;
		$Allow = getPriv("distance", $uid);
		if ($Allow == false) echo header ('Location: ../permission/?l=' . $cLang);
			   
		$user_id = $uid; //154;//$_SESSION['user_id'];//nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
		$client_id = $cid;//154;// $_SESSION['client_id'];//nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
				    
		$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		
		$pts = '';
		
		$vid = getQUERY("vid");
		$dt1 = getQUERY("dt1");
		$dt2 = getQUERY("dt2");
	    
?>

<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="">
<div id="chartdiv"></div>
<!--div id="raphaelIgn" style="display: block; z-index: 4; width: 92.6%; top: 6px; position: absolute; opacity: 0.65; height: 38px; left: 60px;"></div-->
<div id="scrolldiv" style="width:100%; height:100%; text-align:left; background-color:#fff; overflow-y:auto; overflow-x:hidden" class="corner5">
	
<?php
		
?>

<div style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%;" class="corner5">
	<table align="center" width=90% class="text5" style="margin-top:10px; font-size: 11px;">
		<tr>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Реден број</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Гориво</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Гориво со алгоритам</strong></td>
			<td width="150px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Датум</strong></td>
			<td width="300px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Брзина</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Сателити</strong></td>
			<td width="100px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Мотор</strong></td>
			<td width="100px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Време разлика</strong></td>
		</tr>
	<?php
	$cnt = 1;
	$dsph = query("select * from getreconstructionbeton1(" . $vid . ", '" . $dt1 . "','" . $dt2 . "')");
	while($row = pg_fetch_array($dsph)) {
		$pts .= $row["dt"] . '|' . $row["fuelalg"] . '|' . $row["_speed"] . '#';
		if($row["ignition"] == '1') {
			$motor = 'Вклучен';
			$bgcolor = 'ADD6AD';
			$color = '363636';
		} else {
			$motor = 'Исклучен';
			$bgcolor = 'EEA6A6';
			$color = 'fff';
		}
		?>
		<tr class="hov123" style="background-color: #<?=$bgcolor?>; color: #<?=$color?>;">
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$cnt?></td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=round($row["fuel"], 2)?> L</td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["fuelalg"]?> L</td>
			<td class="citiesin text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["dt"]?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=round($row["_speed"])?> Km/h</td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["_status"]?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$motor?></td>
			<td class="text2;" align="center" style="border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["dtdiff"]?> секунди</td>
		</tr>
		<?php
		$cnt++;
	}
	?>
	</table>
</div><br><br>
</div>
<?php


closedb();
?>
</body>
</html>
<script>
	var metricUnit = "Km/h";
	var chart;
	var chartData = [];
	var _pts = '<?=$pts?>';
	_pts = _pts.split('#');
	AmCharts.ready(function () {
		generateChartData1();
		createSerialChart();
	});
	function generateChartData1()
	{
	    var dt = [];
	    dt[0] = _pts[0].split("|")[0];
	    //var firstDate = new Date(dt[0].split(" ")[0].split("-")[0], parseInt(dt[0].split(" ")[0].split("-")[1], 10)-1, dt[0].split(" ")[0].split("-")[2], dt[0].split(" ")[1].split(":")[0], dt[0].split(" ")[1].split(":")[1], dt[0].split(" ")[1].split(":")[2].split(".")[0]);
	    for (var i = 0; i < _pts.length - 1; i++) {
	    	if(_pts[i].split('|')[1] != '') {
		    	dt[i] = _pts[i].split("|")[0];
		    	var newDate = new Date(dt[i].split(" ")[0].split("-")[0], parseInt(dt[i].split(" ")[0].split("-")[1], 10)-1, dt[i].split(" ")[0].split("-")[2], dt[i].split(" ")[1].split(":")[0], dt[i].split(" ")[1].split(":")[1], dt[i].split(" ")[1].split(":")[2].split(".")[0]);
				if(i > 0)
				{
					if(parseInt(_pts[i].split("|")[2], 10) > 7 && parseInt(_pts[i-1].split("|")[2], 10) <= 7)
					{
						var _speed = 0;
					}
					else
						var _speed = _pts[i].split("|")[2];
				}
				putInChartData1(i, newDate, "Speed", "Fuel", _speed, _pts[i].split("|")[1]);
			}
		}
	}
	function putInChartData1(_i, dt, vehid1, vehid2, value1, value2)
	{
		var obj = {};
		obj["date"] = dt;
		//obj[vehid1]= value1;
		
		// chartData[chartData.length-1].Fuel
		//if(parseInt(value2, 10) > 3)
		//{
			obj[vehid2]= value2;
		//}
		chartData.push(obj);
	}
	function createSerialChart()
	{
		// SERIAL CHART    
	    chart = new AmCharts.AmSerialChart();
	    chart.pathToImages = "./amcharts/images/";
	    chart.zoomOutButton = {
	        backgroundColor: '#ff0000',
	        backgroundAlpha: 0.15
	    };
	    chart.zoomOutText = 'Zoom Out';
	    chart.dataProvider = chartData;
	    chart.categoryField = "date";
	
	    // listen for "dataUpdated" event (fired when chart is inited) and call zoomChart method when it happens
	    //chart.addListener("dataUpdated", zoomChart);
	
	    // AXES
	    // category                
	    var categoryAxis = chart.categoryAxis;
	    categoryAxis.parseDates = true; // as our data is date-based, we set parseDates to true
	    categoryAxis.minPeriod = "ss"; // our data is daily, so we set minPeriod to DD
	    categoryAxis.dashLength = 2;
	    categoryAxis.gridAlpha = 0.15;
	    categoryAxis.axisColor = "#DADADA";
	
	    // first value axis (on the left)
	    var valueAxis1 = new AmCharts.ValueAxis();
	    valueAxis1.axisThickness = 2;
	    valueAxis1.gridAlpha = 0.1;
	    //valueAxis1.gridColor = "#FF6600";
	    chart.addValueAxis(valueAxis1);
		valueAxis1.addListener('axisChanged',
	        function (event) {
	        	//$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
	   			//$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
	   			
	   			//if(Browser() != "Chrome" && Browser() != "Safari")
					chart.chartCursor.set.node.children[0].attributes[3].value = "3";
				//else
					//chart.chartCursor.set.node.childNodes[0].attributes[3].value = "3";
	        });
		
		// second value axis (on the right) 
	    var valueAxis2 = new AmCharts.ValueAxis();
	    valueAxis2.position = "right"; // this line makes the axis to appear on the right
	    valueAxis2.axisColor = "#FCD202";
	    valueAxis2.gridAlpha = 0.1;
	    //valueAxis2.gridColor = "#FCD202";
	    valueAxis2.axisThickness = 2;
	    chart.addValueAxis(valueAxis2);
		valueAxis2.addListener('axisChanged',
	        function (event) {
	        	//$('#raphaelIgn').css({left: (chart.div.offsetLeft + chart.chartCursor.x) + 'px'});
	   			//$('#raphaelIgn').css({width: chart.graphs[0].width + 'px'});
	   			
	   			//if(Browser() != "Chrome" && Browser() != "Safari")
					chart.chartCursor.set.node.children[0].attributes[3].value = "3";
				//else
					//chart.chartCursor.set.node.childNodes[0].attributes[3].value = "3";
	        });
	
		// GUIDES are vertical (can also be horizontal) lines (or areas) marking some event.
	    
	    // GRAPHS
	    // first graph
	    var graph1 = new AmCharts.AmGraph();
	    graph1.valueAxis = valueAxis1; // we have to indicate which value axis should be used
	    graph1.type = "smoothedLine"; // this line makes the graph smoothed line.
	    graph1.lineColor = "#387CB0";
	    graph1.bullet = "round";
	    graph1.bulletSize = 7;
	    graph1.lineThickness = 2;
	    graph1.title = 'Брзина';
	    graph1.valueField = "Speed";
	    graph1.balloonText = "[[value]] " + metricUnit;
	    graph1.legendValueText = "[[value]] " + metricUnit;
	    graph1.hideBulletsCount = 130;
	    //chart.addGraph(graph1);
		
		// second graph                
	    var graph2 = new AmCharts.AmGraph();
	    //graph2.lineColor = "#000000";
	    graph2.valueAxis = valueAxis2; // we have to indicate which value axis should be used
	    graph2.type = "smoothedLine"; // this line makes the graph smoothed line.
	    graph2.bullet = "round";
    	graph2.bulletSize = 7;
    	graph2.connect = false;
    	graph2.lineThickness = 2;
	    graph2.title = 'Гориво';
	    graph2.valueField = "Fuel";
	    graph2.balloonText = "[[value]] L";
	    graph2.legendValueText = "[[value]] L";
	    graph2.hideBulletsCount = 100;
	    
	    chart.addGraph(graph2);
	
	    // CURSOR
	    var chartCursor = new AmCharts.ChartCursor();
	    chartCursor.cursorPosition = "start";
	    chartCursor.categoryBalloonDateFormat = "JJ:NN:SS";
	    chart.addChartCursor(chartCursor);
		
		
		
		/*chart.chartCursor.addListener("changed", function(event){
			if(event.index != undefined)
				goToPointIdxNew(event.index);
		});
		chart.chartCursor.addListener("onHideCursor", function(event){
			if(_PointCount != undefined && _PointCount != 0 && _PointCount != 1)
			{
				_i = _PointCount;
				moveChartFromHide(_i);			
	    		goToPointIdxNew(_i);
	    	}
		});*/
		
	    // SCROLLBAR
	    var chartScrollbar = new AmCharts.ChartScrollbar();
	    chartScrollbar.graph = graph2;
	    chartScrollbar.scrollbarHeight = 30;
	    chartScrollbar.autoGridCount = true;
	    chartScrollbar.color = "#000000";
	    //chartScrollbar.gridColor = "#00FFFF";
	    chart.addChartScrollbar(chartScrollbar);
	
	    // LEGEND
	    var legend = new AmCharts.AmLegend();
	    legend.marginLeft = 110;
	    legend.markerType = "circle";
	    chart.addLegend(legend);
		
	
		chart.write("chartdiv");

	}
	
</script>