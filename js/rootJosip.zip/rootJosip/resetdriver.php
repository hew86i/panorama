<?php include "include/functions.php" ?>
<?php include "include/db.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php

	opendb();

	$dsMain = runSQL("update drivervehicle set enddate='" . now() . "' where id in (
	select id from drivervehicle where vehicleid in (select id from vehicles where clientid in (select id from clients where resetdrivertypeid=2))
	and enddate is null)");	

	closedb();
	
?>

