﻿<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>

<?php include "./include/params.php" ?>
<?php session_start()?>
<?php
    
    header("Expires: Mon, 20 Jul 2000 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", FALSE);
    header("Pragma: no-cache");
	set_time_limit(0);
	opendb();
    if (!is_numeric(session('user_id'))) echo header( 'Location: ../sessionexpired/?l='.$cLang);
	if (!is_numeric(session('client_id'))) echo header( 'Location: ../sessionexpired/?l='.$cLang);

    $osmid = str_replace("'", "''", NNull($_GET['osmid'], ''));
    $dsName = query("select st_astext(st_transform(way, 4326)) way, name from planet_osm_line where osm_id=" . $osmid);
	
	$strName = pg_fetch_result($dsName, 0, "name");
	$strLonLat = pg_fetch_result($dsName, 0, "way");
    print $strLonLat . "%^" . $strName;
  	closedb();  
?>