﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
        <style>
			.textQ {
				font-family:Arial, Helvetica, sans-serif; 
				font-size:24px; 
				font-weight:normal; 
				color:#ffffff; 
				text-decoration: none
			}
  		
        </style>
</head>
	<script>
		lang = 'mk'
	</script>
	
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.customQ.css">	
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/iScroll.js"></script>
    <script src="./js/jquery-ui.js"></script>
    
    	
<?php
    opendb();
	$n = getQUERY("q");
	$lastgroupnum = getQUERY("lastgroupnum");
	$numQGroup = getQUERY("numGroupQ");
	$candidate = getQUERY("candidate");
	
	if ($candidate <> "old") {
		if (dlookup("select count(*) from geonetcandidate where fullname = '" . $candidate . "'") == 0) {
			$_SESSION['starttime'] = strtotime(now());
			$_SESSION['candidate'] = $candidate;
			$idC = dlookup("insert into geonetcandidate (start, fullname) values ('" . now() . "', '".$candidate."') returning id");
		}
	} else {
		$idC = getQUERY("idC");		
		$a = runSQL("update geonetcandidate set answer".($n-1)."=".getQUERY("answer").", tf".($n-1)."='".getQUERY("tf")."', answertime".($n-1)." = (select datediff('', '".DateTimeFormat(getQUERY("startA"), 'Y-m-d H:i:s')."', '".DateTimeFormat(getQUERY("endA"), 'Y-m-d H:i:s')."')) where id=".$idC);
	}
	$dsQ = query("select * from geonetquestions where num=".$n);
	$drQ = pg_fetch_array($dsQ);
	$startDate = DateTimeFormat(now(), "d-m-Y H:i:s");
	$colspan = 1 ;
	if ($drQ["image"] == '1') {
		$colspan = 5;
	}
?>

<body>
	
		<?php
		if ($n < 11) {
			$cntQGroup = dlookup("select count(*) from geonetquestions where qgroupnum=".$drQ["qgroupnum"]);
			if ($drQ["qgroupnum"] != $lastgroupnum) {
				$numQGroup = 1;
				?>
				<div id="groupName" style="font-weight:bold; padding-top: 25%; height:100%; background-color:#000000; width:100%; overflow-y:auto; color:#FF6600; text-align: center; font-size:72px" class="textQ">
				<?php
					echo $drQ["qgroup"];
				?>
				</div>
				<?php
			} else {
				$numQGroup = $numQGroup + 1;
			}
			$lastgroupnum = $drQ["qgroupnum"];
		}
		?>
	
	
	<div id="mainDiv" style="background-color:#000000; width:100%; overflow-y:auto;" class="textQ">
		<table width=90% style="margin:0 auto;" class="textQ">
		<?php
		if ($n < 11) {
			?>
			<tr>
				<td colspan=<?=$colspan?> style="font-size:18px; padding-top:5%" align="right">
					<div id="span-t" style="font-weight:bold"><?= DateTimeFormat(now(), "H:i:s")?></div>
					<div id="time-exp" style="font-size:12px; color:yellow; visibility:hidden">Имате уште<span id="span-timeexp"></span></div>
					
					<div style="font-weight:bold; color:#ff6600; margin-top:10px"><?= $n?> / 10<br><font style="font-size:12px; color:#ffffff;"><?=$drQ["qgroup"]?>: <?= $numQGroup?> / <?=$cntQGroup?></font></div></td				
					
				</td>
			</tr>
			<tr>
				<td colspan=<?=$colspan?> align="center" style="color:#FF6600; padding-top: 5%; border-bottom: 1px solid #ffffff; padding-bottom: 20px; font-weight: bold">
					<?= $drQ["question"]?>
				</td>
			</tr>
			
			<tr><td colspan=<?=$colspan?> height=20px>&nbsp;</td></tr>
			<?php
			if ($drQ["image"] == '1') {
				?>
				<tr>
					<td><input type="radio" name="q" value="1"> <?= $drQ["answer1"]?></td>
					<td><input type="radio" name="q" value="2"> <?= $drQ["answer2"]?></td>
					<td><input type="radio" name="q" value="3"> <?= $drQ["answer3"]?></td>
					<td><input type="radio" name="q" value="4"> <?= $drQ["answer4"]?></td>
					<td><input type="radio" name="q" value="5"> <?= $drQ["answernone"]?></td>
				</tr>
				<?php
			} else {

				if (nnull($drQ["answer1"], "/") != "/") {
				?>
				<tr><td><input type="radio" name="q" value="1"> <?= $drQ["answer1"]?></td></tr>
				<?php	
				}
				if (nnull($drQ["answer2"], "/") != "/") {
				?>
				<tr><td><input type="radio" name="q" value="2"> <?= $drQ["answer2"]?></td></tr>
				<?php	
				}
				if (nnull($drQ["answer3"], "/") != "/") {
				?>
				<tr><td><input type="radio" name="q" value="3"> <?= $drQ["answer3"]?></td></tr>
				<?php	
				}
				if (nnull($drQ["answer4"], "/") != "/") {
				?>
				<tr><td><input type="radio" name="q" value="4"> <?= $drQ["answer4"]?></td></tr>
				<?php	
				}
				if (nnull($drQ["answernone"], "/") != "/") {
				?>
				<tr><td><input type="radio" name="q" value="5"> <?= $drQ["answernone"]?></td></tr>
				<?php	
				}
			}
			?>
						
			<tr height="20px"><td colspan=<?=$colspan?> style="border-bottom: 1px solid #ffffff;">&nbsp;</td></tr>
			
			<tr>
				<td colspan=<?=$colspan?> style="text-align: center; padding-top:5%;">
					<button id="nextQ" onClick="nextQ(<?=$n?>)" style="font-size:14px; font-weight: bold">Следно</button>
				</td>
			</tr>
			<?php
		} else {
			?>
			<tr>
				<td colspan=<?=$colspan?> style="text-align: center; padding-top:10%">
					<img src="./images/GeonetLogo.png" border="0" align="absmiddle" />
				</td>
			</tr>
			<tr>
				<td colspan=<?=$colspan?> class="textQ" style="text-align: center; padding-top:10%">
					Почитуван/а<span style="font-weight:bold; color: #ff6600"> <?=$_SESSION['candidate']?></span>,
					<br>Ви благодариме на одвоеното време.
					<br><br>Со почит,<br>Геонет ГПС.
				</td>
			</tr>
			<?php
		}
		?>
		</table>
		
	</div>

    <?php
    closedb();
    ?>
    
</body>

<script type="text/javascript">
	$('#nextQ').button({ icons: { primary: ""} })
		
	function pad(n) {
	    return (n < 10) ? ("0" + n) : n;
	}

	 function nextQ(_n) {
	 	
	 	if (!$("input[name='q']:checked").val()) {
		   alert('Немате избрано ниту еден оговор !!!');
		} else {
			var tf = 0;
			if ('<?=$drQ["trueanswer"]?>' == $('input[name=q]:checked').val()) tf=1;
			//alert(tf);
			//$('iframe#ifrm-q').attr('src', _url);
			top.document.getElementById('ifrm-q').src = 'GeonetQ.php?q='+(_n+1)+'&candidate=old'+'&idC='+<?=$idC?>+'&startA=' + '<?= $startDate?>' + '&endA=' + $('#span-t').html()+'&answer='+$('input[name=q]:checked').val()+'&tf='+tf+'&lastgroupnum=<?=$lastgroupnum?>&numGroupQ=<?=$numQGroup?>';				                   
		}
	 }	
	 
	 $(document).ready(function () {
	 	
	 	setTimeout(function(){ $('#groupName').css({display: 'none'}); }, 2000);
	 	
	 	if ($(document).height() > $(window).height()) {
	 		//alert($(window).height())
	 		//$('#mainDiv').css({height: (calc($(window).height() - 10%)+"px"})
	 	}
	 	
	 	$(document).bind('keypress', function(e) {
    		var p = e.which;
		     if(p == 13){
		         nextQ(<?=$n?>);
		     }
	 	});	 
        
        if (<?=$n?> >= 11) {
        	clearInterval(myInt);
        }
    });
    
    var myInt = setInterval(function() {
    	var d =  new Date();
    	var d1 = pad(d.getHours()) + ":" + pad(d.getMinutes()) + ":" + pad(d.getSeconds());
    	$('#span-t').html(d1+"");
    	
    	var starttime = '<?=$_SESSION['starttime']?>';
    	var d2 = Math.round(d/1000);
    	var total = 2*60;
    	if (starttime != undefined) {
    		if(total - (d2-starttime) < 60) {
    			if(total - (d2-starttime) <= 15) {
    				$('#time-exp').css({color: 'red'});
    			}
    			$('#time-exp').css({visibility: 'visible'});
				$('#span-timeexp').html("&nbsp;" + (total - (d2-starttime)) + " секунди");
			}
			
    		if((d2-starttime) > (total-1)) {
    			window.location.href = "./Geonet.php?exp=1&nQ="+<?=$n?>;
    			clearInterval(myInt);
    		}
    	}
    },1000);
</script>

</html>


