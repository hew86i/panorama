<?php include "include/functions.php" ?>
<?php include "include/db.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<?php
	require_once '/usr/share/php/swift_required.php';
	opendb();

	$email = $_POST[n]; //'kiki@gps.mk;kiki@gps.mk';//getQUERY("email");

	$subject = 'Вашата пријава е примена';//getQUERY("subject");
		
	$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
  	->setUsername('jobs@gps.mk')
 	->setPassword('1234554321*#')
 	;

	
	$mailer = Swift_Mailer::newInstance($transport);


	$message = Swift_Message::newInstance(dic_($subject))
	  ->setFrom(array('jobs@gps.mk' => 'Geonet GPS Solutions'))
	  ->setBody('Geonet GPS')
	  ->addPart('


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<span style="font-family:Arial; font-size:13px; display:block; margin-left:20px">Почитувани,
<br>
<br>
Ви благодариме за Вашиот интерес за вработување во нашата компанија и за понатамошно заедничко усовршување.<br>
Вашата пријава е примена и ќе биде земена во предвид при првичната оцена за објавените работни позиции.<br>
Само апликациите кои ќе влезат во потесен круг, ќе бидат контактирани за понатамошниот тек на процесот.<br>
<br>
<br>
Со почит,<br>
Тимот на ГеоНет
</span>
<br><br>
<span style="font-family:Arial; font-size:11px; color:#2F5185; display:block; margin-left:20px">
<b>GeoNet GPS Solutions</b><br>
ul. Pirinska br.23,<br>
Business Center GRAWE,<br>
1000 Skopje, MACEDONIA<br>
<br>
Phone:  	02-329 0020<br>
Fax:      	02-329 0021<br>
email:	<a href="emailto:info@gps.mk">info@gps.mk<a> <br>
Web:		<a href="http://www.gps.mk" target="blanc">www.gps.mk</a><br>
</span>
<br>
<img alt="" src="http://panorama.gps.mk/potpis.png" />
<br><br>
<span style="font-family:Arial; font-size:10px; color:#999; display:block; margin-left:20px">
<b>EMAIL DISCLAIMER</b><br>
The information in this message and any attachment is confidential and may be legally privileged.  It is intended for the above named recipient(s) only and should not be disclosed, copied nor distributed.  If this message is received in error, the sender should be notified and the message and any attachments deleted.<br>

E-mail transmission cannot be guaranteed to be secure or error free as information could be intercepted, corrupted, lost, destroyed, arrive late or incomplete, or contain viruses.  The sender therefore does not accept liability.<br>
</span>', 'text/html')
	  
	  ;


	$failedRecipients = array();
	$numSent = 0;
	//$to = array($email);
	$to = explode(";", $email);

	/*$str = explode(";", $email);
	for ($i=0; $i < count($str); $i++) {
		echo $str[$i];
	}*/


	foreach ($to as $address => $name)
	{
	  if (is_int($address)) {
	    $message->setTo($name);
	  } else {
	    $message->setTo(array($address => $name));
	  }
	  $numSent += $mailer->send($message, $failedRecipients);
	  echo $name . "<br>";
	}
	
echo "<br><br>Успешно пратено.";
 ?>
