﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" href="http:////code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
			lang = '<?php echo $cLang?>'
	</script>
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="/js/jquery.js"></script>
	<script type="text/javascript" src="/report/js/highcharts.src.js"></script>
	
	<link href="/css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="/js/jquery-ui.js"></script>
    <script src="/js/jquery.tooltip.js"></script>
	
     <script src="/js/jquery-ui-timepicker-addon.js" type="text/javascript"></script>
	
  <script>
  
  $(function() {
    $( "#datepicker" ).datepicker({
    	dateFormat: 'dd-mm-yy',
    	onSelect: function () {
    		var val = $('#datepicker').val();
            window.location = "http://panorama.gps.mk/BufferChart.php?dt=" + val;
        }
    });
    
  });
  </script>
</head>
	
<?php
function DateDiffMinutes($date1, $date2) {
	$diff = round(abs(strtotime($date1)-strtotime($date2))/60);	
	if (strtotime($date1) > strtotime($date2)) $diff = $diff * -1;
	return $diff;
}

		if (nnull(is_numeric(nnull(getQUERY("uid"))), 0)>0){
			$uid = getQUERY("uid");
			$cid = getQUERY("cid");	
		} else {
			$uid = session("user_id");
			$cid = session("client_id");
		}
		
		opendb();
		$cntHavaData = 0;
		$Allow = getPriv("distance", $uid);
		if ($Allow == false) echo header ('Location: ../permission/?l=' . $cLang);
			   
		$user_id = $uid; //154;//$_SESSION['user_id'];//nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
		$client_id = $cid;//154;// $_SESSION['client_id'];//nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
				    
		$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		 
	    $vh = getQUERY("v");
	 	
		/*format na datum*/
		$datetimeformat = dlookup("select datetimeformat from users where id=" . $uid);
		$datfor = explode(" ", $datetimeformat);
		$dateformat = $datfor[0];
		
		$dt = nnull(getQUERY('dt'), DatetimeFormat(now(), 'd-m-Y'));
				
	    $sdG = DateTimeFormat($dt, 'd-m-Y 00:00:00');
		$edG = DateTimeFormat($dt, 'd-m-Y 23:59:59');
		
	    
?>

<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="SetHeightLite()">
	
 
 
<div id="div-add-schedule" style="display:none" title="<?php dic("Reports.AddSchedule")?>"></div>
<div id="div-add-email" style="display:none" title="<?php dic("Reports.SendReport")?>"></div>
<div id="dialog-message" title="<?php dic("Reports.Message")?>" style="display:none">
	<p>
		<span class="ui-icon ui-icon-circle-check" style="float:left; margin:0 7px 50px 0;"></span>
		<div id="div-msgbox" style="font-size:14px"></div>
	</p>
</div>

<div id="scrolldiv" style="width:100%; height:100%; text-align:left; background-color:#fff; overflow-y:auto; overflow-x:hidden" class="corner5">
	
	<br><br>
<?php
		
?>
<div align="center" class="text2" style="padding-left: 15px"><strong>Избери ден:</strong> 
	<input type="text" class="text2" width="50px" height="25px" id="datepicker" value="<?php echo $dt?>"></div><br><br>

<div style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%;" class="corner5">

	<br><br><br>
 
	<div  id="containerChartAll" style="width: 95%; background-color:#fafafa; height:240px; margin: 0 auto; position:relative; top:50px"></div>
		<table align="center" width=350px class="text2" style="margin-top:100px">
	<tr>
	<td width=130px align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Време</strong></td>
	<td width=110px align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Бр. на возила</strong></td>
	<td width=110px align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Бр. на податоци</strong></td>
	</tr>
	<?php
	$_datum  = DateTimeFormat($sdG, 'Y-m-d H:i:s');
	while (DateDiffMinutes(DateTimeFormat($edG, 'Y-m-d H:i:s'), $_datum) < 0) {
		$dsTemp = query("select count(distinct vehid) cntveh, count(*) cntdata from tempinsertbuffer where insertdatetime between '" . DateTimeFormat($_datum, 'Y-m-d H:i:00'). "' and '" . DateTimeFormat($_datum, 'Y-m-d H:i:59'). "'");
		
		$Cities = dlookup("select array_to_string(array_agg(distinct _cities), ',') from (select (select name from cities where id = (select cityid from clients where id=(select clientid from vehicles where id=vehid))) _cities from tempinsertbuffer where insertdatetime between '" . DateTimeFormat($_datum, 'Y-m-d H:i:00'). "' and '" . DateTimeFormat($_datum, 'Y-m-d H:i:59'). "') a");
		//echo "select array_to_string(array_agg(distinct _cities), ',') from (select (select name from cities where id = (select cityid from clients where id=(select clientid from vehicles where id=vehid))) _cities from tempinsertbuffer insertdatetime between '" . DateTimeFormat($_datum, 'Y-m-d H:i:00'). "' and '" . DateTimeFormat($_datum, 'Y-m-d H:i:59'). "') a";
		//exit;
		//select count(distinct vehid) cntveh, count(*) cntdata from tempinsertbuffer where insertdatetime between '" . DateTimeFormat($_datum, 'Y-m-d H:i:00'). "' and '" . DateTimeFormat($_datum, 'Y-m-d H:i:59'). "'");
		
		$cntVeh = pg_fetch_result($dsTemp, 0, 'cntveh');
		$cntData = pg_fetch_result($dsTemp, 0, 'cntdata');
		
		$dat = explode("-", $_datum);
		$dat[1] = (intval($dat[1]) - 1) . "";
        $arr = explode(" ", $dat[2]);
		$timearr = explode(":", $arr[1]);
		$backcolor = '';
		if ($cntVeh > 0 or $cntData > 0) {
			if ($cntData > 100) $backcolor = "red";
		?>
		<tr>
		<td class="citiesin text2;" title="<?=$Cities?>" align="center" style="color:<?php echo $backcolor?>;background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?php echo DateTimeFormat($_datum, 'H:i:00')?> - <?php echo DateTimeFormat($_datum, 'H:i:59')?></td>
		<td class="text2;" align="center" style="color:<?php echo $backcolor?>;background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?php echo $cntVeh?></td>
		<td class="text2;" align="center" style="color:<?php echo $backcolor?>;background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?php echo $cntData?></td>
		</tr>
		<?php
		}
		$strNoData .= ", [Date.UTC(" . $dat[0] . ",  " . $dat[1] . ", " . $arr[0] . ",  " . $timearr[0] . ",  " . $timearr[1] . "), " . $cntData . "] ";
		$strNoVehicles .= ", [Date.UTC(" . $dat[0] . ",  " . $dat[1] . ", " . $arr[0] . ",  " . $timearr[0] . ",  " . $timearr[1] . "), " . $cntVeh . "] ";
		
		$_datum = DateTimeFormat(addToDate($_datum, 1, "minute"), 'Y-m-d H:i:s');
	}
	?>
	</table><br><br>
	<?php
	                       
    
	if ($strNoData <> "") $strNoData = substr($strNoData, 2);
	if ($strNoVehicles <> "") $strNoVehicles = substr($strNoVehicles, 2);
         ?>
	
	    <?php
	  		//} // end if

        echo "<script type='text/javascript'>var chart;" . "\r\n";
        echo "function createChart() {" . "\r\n";
	
		echo "var chart = new Highcharts.Chart({" . "\r\n";
	    echo "chart: {" . "\r\n";
	    echo "    renderTo: 'containerChartAll'" . "\r\n";
	    echo "}," . "\r\n";
		echo "	title: {" . "\r\n";
        echo "		text: 'BUFFER CHART'" . "\r\n";
        echo "	}," . "\r\n";
	    echo "xAxis: {" . "\r\n";
	    echo "    tickInterval: 1000*3600, type: 'datetime' " . "\r\n";
	    echo "}," . "\r\n";
		echo "	yAxis: [" . "\r\n";
        echo "	{" . "\r\n";
        echo "		title: {" . "\r\n";
        echo "			text: 'Број на возила'" . "\r\n";
        echo "		}, " . "\r\n";
        echo "		min: 0, labels: {formatter: function(){return this.value;}} " . "\r\n";
        echo "	},{" . "\r\n";
        echo "		title: {" . "\r\n";
        echo "			text: 'Број на податоци'" . "\r\n";
        echo "		}, " . "\r\n";
        echo "		min: 0, opposite: true, labels: {formatter: function(){return this.value;}} " . "\r\n";
        echo "	}],";
        echo "	tooltip: {" . "\r\n";
        echo "		formatter: function() {" . "\r\n";
        echo "				return '<b>'+ this.series.name +'</b><br/>'+" . "\r\n";
        echo "				Highcharts.dateFormat('%H:%M', this.x) +': '+ this.y;" . "\r\n";

        echo "		}" . "\r\n";
        echo "	}," . "\r\n";
	    echo "series: [{" . "\r\n";
	    echo "		yAxis:0, name: 'Број на возила', color: 'green',  " . "\r\n";
	    echo "    data: [" . "\r\n";
	    echo "        " . $strNoVehicles . "" . "\r\n";
	    echo "    ]" . "\r\n";
	    echo "},{" . "\r\n";
	    echo "		yAxis:1, name: 'Број на податоци', color: 'red',  " . "\r\n";
	    echo "    data: [" . "\r\n";
	    echo "        " . $strNoData . "" . "\r\n";
	    echo "    ]" . "\r\n";
	    echo "}]" . "\r\n";
		echo "});" . "\r\n";
      
		echo "}" . "\r\n";
        echo "createChart()</script>" . "\r\n";
    
	?>
	
  
</div><br><br>
<?php


closedb();
?>

	<br>

</div>

</body>
</html>

<script type="text/javascript">
	$('.citiesin').tooltip();
	setInterval('autoreload()', 60000);
	function autoreload(){
		<?php 
			closedb(); 
		?>
		
		location.reload();
	}
	$("#scrolldiv").scrollTop($("#scrolldiv")[0].scrollHeight);
	/*top.HideLoading()
	$(document).ready(function () {
	    top.HideWait();
	  
	});*/
	
</script>
