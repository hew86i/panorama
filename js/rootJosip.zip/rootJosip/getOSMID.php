﻿<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>

<?php include "./include/params.php" ?>
<?php session_start()?>
<?php
    
    header("Expires: Mon, 20 Jul 2000 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", FALSE);
    header("Pragma: no-cache");
	set_time_limit(0);
	opendb();
    if (!is_numeric(session('user_id'))) echo header( 'Location: ../sessionexpired/?l='.$cLang);
	if (!is_numeric(session('client_id'))) echo header( 'Location: ../sessionexpired/?l='.$cLang);

    $lonlat = str_replace("'", "''", NNull($_GET['lonlat'], ''));
    
	$strSQL = "select osm_id, way, coalesce(name, 'No name') ime, st_distance(utm, ST_Transform(ST_GeomFromText('POINT(" . $lonlat . ")',4326),26986)) dist";
	$strSQL .= " from planet_osm_line ";
	$strSQL .= " where ST_DWithin(utm, ST_Transform(ST_GeomFromText('POINT(" . $lonlat . ")',4326),26986) , 50) =true "; 
	$strSQL .= " order by dist limit 1";

    $dsName = query($strSQL);
	$strOSMID = pg_fetch_result($dsName, 0, "osm_id");

    print $strOSMID;
  	closedb();  
?>