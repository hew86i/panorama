<?php include "/var/www/panorama/include/db.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
	
	opendb();
	
	$check = query("select alarmdaily()");
	echo 'Ok';
	closedb();
?>
