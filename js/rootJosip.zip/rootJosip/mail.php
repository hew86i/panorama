<?php include "../include/functions.php" ?>
<?php include "../include/db.php" ?>
<?php include "../include/params.php" ?>
<?php include "../include/dictionary2.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>
<?php
	require_once '/usr/share/php/swift_required.php';
	opendb();
	//getQUERY
	//$user = getQUERY("_user");
	$email = 'kiki@gps.mk';//getQUERY("email");
	$subject = 'subject';//getQUERY("subject");
	echo 4;
	
	$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
  	->setUsername('sysinfo@gps.mk')
 	->setPassword('geo!net123*$')
 	;

	
	$mailer = Swift_Mailer::newInstance($transport);


	$message = Swift_Message::newInstance(dic_($subject))
	  ->setFrom(array('sysinfo@gps.mk' => 'Geonet GPS Solutions'))
	  ->setBody('Geonet GPS')
	  ->addPart('


<html>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<body>
		kiki
		</body>
		</html>
', 'text/html')
	  
	  ;


	$failedRecipients = array();
	$numSent = 0;
	$to = array($email);

	foreach ($to as $address => $name)
	{
	  if (is_int($address)) {
	    $message->setTo($name);
	  } else {
	    $message->setTo(array($address => $name));
	  }
	  $numSent += $mailer->send($message, $failedRecipients);
	}
	

	echo 1;

 ?>
