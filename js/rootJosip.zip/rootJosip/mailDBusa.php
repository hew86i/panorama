
<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary1.php" ?>
<?php header("Content-type: text/html; charset=utf-8")?>
<?php
	require_once '/usr/share/php/swift_required.php';
	opendb();
	
	//zakomentirano na 29.08.2014 - poradi zabelska od polyesterday
	//RunSQL("select alarmnewign()");
	
	$dsSendMail = query("select * from send_mail_usa where flag='0'");
		
	while($row = pg_fetch_array($dsSendMail))
	{
		if (!filter_var($row["tomail"], FILTER_VALIDATE_EMAIL)) {
			SendEmailDB('gps.link.sms@gmail.com', 'Invalid email address', 'Invalid email address - ' . $row["tomail"]);
		} else {
			SendEmailDB($row["tomail"], $row["subject"], $row["body"]);
		}
		RunSQL("update send_mail_usa set flag='1' where id=".$row["id"]);
	}
	
	//SendEmailDB('marjan@gps.mk', 'Mail od gmail', 'Body na mailot<br>');
	
	function SendEmailDB($toemail, $subject, $body){
		$transport = Swift_SmtpTransport::newInstance('smtp.gmail.com', 465, 'ssl')
	  	->setUsername('gps.link.sms@gmail.com')
	 	->setPassword('sms.gps.8800');
		$mailer = Swift_Mailer::newInstance($transport);

		$message = Swift_Message::newInstance('GPS Link')
		  ->setFrom(array('gps.link.sms@gmail.com' => 'gps-link@gps-link.com'))
		  ->setBody($body);
		  //->addPart($body, 'text/html');
		
		$failedRecipients = array();
		$message->setTo($toemail);
		$mailer->send($message, $failedRecipients);
	}
	

	echo 1;
	closedb();
 ?>
