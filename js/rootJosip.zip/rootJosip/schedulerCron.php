﻿
<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php
	require_once '/usr/share/php/swift_required.php';

	opendb();
		
	$path1 = "/home/Logs/schedulerNew/";
	if(file_exists($path1) != 1)
	{
		mkdir($path1, 0777, true);
	}
	file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", "S T A R T - " . date("d-m-Y H:i:s") . "\r\n", FILE_APPEND);
					
	$cLang = "mk";
	$sd = now(); //'2014-03-20 17:30:00';//now();
	$now = now(); //'2014-03-20 17:30:00';//now();

	$lang = "en";
    $sDate = "";
	$eDate = "";
    $url = "";
    $path = "";//"/var/www/panorama/savePDF1/";
    $Fname = "";
  	
	$transArr = array();
	$transArr[0] = "Кокпит#Dashboard#Tableau de bord#Kabinë";
	$transArr[1] = "Преглед#Overview#Vue d'ensemble#Rishikimi";
	$transArr[2] = "Краток извештај#Short report#Bref rapport#Raport i shkurtër";
	$transArr[3] = "Детален извештај#Detail report#Rapport détaillé#Raporti i detajuar";
	$transArr[4] = "Стоење во место#Idle#Ralenti#Qëndrimi";
	$transArr[5] = "Такси извештај 1#Taxi report 1#Rapport taxi 1#Raporti Taxi 1";
	$transArr[6] = "Такси извештај 2#Taxi report 2#Rapport taxi 2#Raporti Taxi 2";
	$transArr[7] = "Такси активност#Taxi activity#Taxi activité#Aktiviteti taxi";
	$transArr[8] = "Посетени точки од интерес#Visited points of interest#POI visité#Pikat e interesit të vizituara";
	$transArr[9] = "Поминато растојание#Distance travelled#Distance parcourue#Largësia udhëtuar";
	$transArr[10] = "Активност#Activity#Activité#Aktivitet";
	$transArr[11] = "Максимални брзини#Max speed#Vitesse maxi#Shpejtësi maksimale";
	$transArr[12] = "Надминување на дозволена брзина#Speed limit excess#Le dépassement de la limite de vitesse#Tejkaluar kufiri i shpejtësisë";
	$transArr[13] = "Сите возила#All vehicles#Tous les véhicules#Të gjitha automjetet";
	$transArr[14] = "Планер - ГПС извештај#Scheduler - GPS report#L'annexe du rapport - Rapport de GPS#Projektues - Raporti GPS";
			
	/*$dsScheduler = query("select id,clientid, userid, report, vehicle, period, day, \"time\", email, subusers, range,vehid, path, creationdate,doctype,repid from scheduler order by id asc");*/
	$dsScheduler = query("select id, clientid, userid, report, vehicle, period, day, \"time\", email, subusers, range, vehid, path, 
	creationdate, doctype, repid from scheduler where ((select active from vehicles where id=cast(vehid as integer)) = '1' and vehid <> '0') or vehid = '0'
	order by id asc");

	$cnt = 1;
	while ($rS = pg_fetch_array($dsScheduler)) {								
		try {
			//Za period Weekly
			if(mb_strtolower($rS["period"], 'UTF-8') == "weekly" && mb_strtolower($rS["day"], 'UTF-8') == mb_strtolower(DateTimeFormat($now, "l"), 'UTF-8')) {
				$path = "/var/www/panorama/savePDF1/";	
				if(DateTimeFormat($rS["time"], "H") == DateTimeFormat($now, "H")) {
					$url = "";
					$mail = SortMail($rS["email"]); //'kiki@gps.mk;';//SortMail('kiki@gps.mk;'.$rS["email"]);//SortMail($rS["email"]);
					if($mail != "False" && !strpos($mail, "@") === false) {
						$dsUser = query("select id, deflanguage, clientid, fullname, datetimeformat, (select name from clients where id = clientid) company from users where id = " . $rS["userid"]);
												
						$sDate = DetectRange($rS["range"], 'sd');
						$eDate = DetectRange($rS["range"], 'ed');
						
						/*$datetimeformat = pg_fetch_result($dsUser, 0, "datetimeformat");
						$datfor = explode(" ", $datetimeformat);
						$dateformat = $datfor[0];
						
						$lang = mb_strtolower(pg_fetch_result($dsUser, 0, "deflanguage"));
						if ($lang == "mk") $i = 0;
						if ($lang == "en") $i = 1;
						if ($lang == "fr") $i = 2;
						if ($lang == "al") $i = 3;
						
						if ($rS["report"] == "overview") $transStr = explode("#", $transArr[0]);
						if ($rS["report"] == "OverviewV") $transStr = explode("#", $transArr[1]);
						if ($rS["report"] == "ShortReport") $transStr = explode("#", $transArr[2]);
						if ($rS["report"] == "Detail") 	$transStr = explode("#", $transArr[3]);
						if ($rS["report"] == "IdlingReport") $transStr = explode("#", $transArr[4]);
						if ($rS["report"] == "Taxi1Report") $transStr = explode("#", $transArr[5]);
						if ($rS["report"] == "Taxi2Report") $transStr = explode("#", $transArr[6]);
						if ($rS["report"] == "AnalTaxiActivity") $transStr = explode("#", $transArr[7]);
						if ($rS["report"] == "VehiclePOI") 	$transStr = explode("#", $transArr[8]);
						if ($rS["report"] == "AnalDistance") $transStr = explode("#", $transArr[9]);
						if ($rS["report"] == "AnalActivity") $transStr = explode("#", $transArr[10]);
						if ($rS["report"] == "AnalSpeed") $transStr = explode("#", $transArr[11]);
						if ($rS["report"] == "AnalSpeedEx") $transStr = explode("#", $transArr[12]);
						$report = $transStr[$i];
						if ($rS["report"] == "CustomizedReport") $report = dlookup("select name from reportgenerator where id = " . $rS["repid"]);
					
						if ($rS["vehid"] == "0") {
							$transStr = explode("#", $transArr[13]);
							$vehicle = $transStr[$i];
						} else {
							$vehicle = dlookup("select registration || ' (' || code || ')' from vehicles where id = " . $rS["vehid"]);
						}
		
						/*$bodyMK = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; max-width: 280px; width: 100%" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Почитувани,<br>Оваа порака ја добивате автоматски од системот за следење на вашите возила.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Корисник:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Компанија:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Датум на креирање:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Временски опсег:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Во прилог Ви го испраќаме извештајот.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Со почит,<br> Геонет ГПС тим</td><td><img width="100px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Не правете "Reply" на овој е-маил.<br>За подетални информации контактирајте нè на <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyEN = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; max-width: 280px; width: 100%" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Dear,<br>This message is sent automatically by the system for monitoring your vehicles.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">User:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Company:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Creation date:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date range:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">In attachement we send you the report.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Best regards,<br> Geonet GPS team</td><td><img width="100px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Do not "Reply" to this e-mail.<br>For more information contact us at <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyFR = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; max-width: 280px; width: 100%" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Cher,<br>Ce message sera automatiquement le système pour le suivi de vos véhicules.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Utilisateur:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Entreprise:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Date de création:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date de gamme:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">En outre, nous vous envoyons le rapport.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Cordialement,<br> Geonet GPS équipe</td><td><img width="100px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Ne pas "Répondre" à ce mail.<br>Pour plus d informations contactez-nous au <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyAL = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; max-width: 280px; width: 100%" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Të dashur,<br>Ky mesazh automatikisht do të merrni sistemin për monitorimin e automjeteve tuaja.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Përdorues:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Kompani:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Data e krijimit:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Fushë:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Përveç kësaj ne të ju dërgojnë raportin.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Të fala,<br> Geonet GPS ekipi</td><td><img width="100px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Mos "Përgjigju" për këtë e-mail.<br>Për më shumë informacion na kontaktoni në <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						*/
						
						/*$bodyMK = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="70px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Почитувани,<br>Оваа порака ја добивате автоматски од системот за следење на вашите возила.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Корисник:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Компанија:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Датум на креирање:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Временски опсег:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Овој извештај е додаден во вашиот планер за автоматско периодично испраќање.<br>Во прилог Ви го испраќаме истиот.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Со почит,<br> Геонет ГПС тим</td><td><img width="80px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Не правете "Reply" на овој е-маил.<br>За подетални информации контактирајте нè на <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyEN = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="70px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Dear,<br>This message is sent automatically by the system for monitoring your vehicles.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">User:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Company:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Creation date:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date range:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">This report has been added in your scheduler to be automatic periodically sent.<br>In attachement we send you the report.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Best regards,<br> Geonet GPS team</td><td><img width="80px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Do not "Reply" to this e-mail.<br>For more information contact us at <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyFR = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="70px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Cher,<br>Ce message sera automatiquement le système pour le suivi de vos véhicules.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Utilisateur:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Entreprise:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Date de création:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date de gamme:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Ce rapport a été ajouté à votre planificateur envoyer périodiquement automatique.<br>En plus je l envoie.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Cordialement,<br> Geonet GPS équipe</td><td><img width="80px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Ne pas "Répondre" à ce mail.<br>Pour plus d informations contactez-nous au <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyAL = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="70px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Të dashur,<br>Ky mesazh automatikisht do të merrni sistemin për monitorimin e automjeteve tuaja.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Përdorues:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Kompani:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Data e krijimit:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Fushë:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Ky raport është shtuar në projektues tuaj periodikisht dërgoni automatike.<br>Gjithashtu unë jam i dërguar atë.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Të fala,<br> Geonet GPS ekipi</td><td><img width="80px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Mos "Përgjigju" për këtë e-mail.<br>Për më shumë informacion na kontaktoni në <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						*/						
						if(mb_strtolower($rS["doctype"]) == "pdf") {
							if(strpos(mb_strtolower($rS["report"]), "customized") == 0) {
								//PDF (customized report)
                                $url = "http://panorama.gps.mk/pdf/indexK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**repid=" . $rS["repid"] . "**schid=" . $rS["id"];
							} else {
								//PDF (obicen report)
                                $url = "http://panorama.gps.mk/pdf/indexK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**schid=" . $rS["id"];
							}
						} else {
							if(strpos(mb_strtolower($rS["report"]), "customized") == 0) {
								//excel (customized report)
                                $url = "http://panorama.gps.mk/report/createXlsK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**repid=" . $rS["repid"] . "**schid=" . $rS["id"] . "&from=s";
							} else {
								//excel(obicen report)
                                $url = "http://panorama.gps.mk/report/createXlsK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**schid=" . $rS["id"] . "&from=s";
							}
						}
					
						$Fname = "";
                        $Fname = file_get_contents($url);
                        $Fname = str_replace("\r", "", $Fname);
                        $Fname = str_replace("\n", "", $Fname);
                        $Fname = str_replace(" ", "", $Fname);
						
						/*$bodyStr = $bodyEN;
						if ($lang == "en") $bodyStr = $bodyEN;
                        if ($lang == "mk") $bodyStr = $bodyMK;
                        if ($lang == "fr") $bodyStr = $bodyFR;
                        if ($lang == "al") $bodyStr = $bodyAL;
                       	
						$transStr = explode("#", $transArr[14]);
						$subject = $transStr[$i];*/
								
						try {
							$size = round(filesize($path . $Fname)/1000, 1);
							$filsize = $size . " kB";
							if ($size > 1000) {
								$size = round(filesize($path . $Fname)/1000000, 1);
								$filsize = $size . " MB";
							}
							//////////////						
							/*$currtime = time();	
							$inctime = $currtime;
							if (strlen($Fname) == 0) {
								while(($inctime - $currtime) < 300) {
									if (strlen($Fname) != 0) {
										
										SendMailAtach($mail, $path, $Fname, $bodyStr, $subject);	
										file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Sent to: " . $mail . " | File name: " . $Fname . " | Size: " . $filsize . "\r\n", FILE_APPEND);				
							
										$inctime = time();
										break;
									} else {
										$inctime = $inctime + 10;
								   		sleep(10);
									}
								}
								if (strlen($Fname) == 0) {
								//	sendScheduler();
								SendMailException1('kiki@gps.mk', $e1, $url);
								}
							} else {
								SendMailAtach($mail, $path, $Fname, $bodyStr, $subject);	
								file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Sent to: " . $mail . " | File name: " . $Fname . " | Size: " . $filsize . "\r\n", FILE_APPEND);			
							}*/
							////////////////
						} catch (Exception $e1) {
							SendMailException('kiki@gps.mk', $e1, $url);
							file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Exception: " . $e1 . "; Url: " . $url . "\r\n", FILE_APPEND);			
						}
						$cnt++;
					}
				}
			}
			
			//Za period Daily
			if(mb_strtolower($rS["period"], 'UTF-8') == "daily") {
				$path = "/var/www/panorama/savePDF1/";
				if(DateTimeFormat($rS["time"], "H") == DateTimeFormat($now, "H")) {
					$url = "";
					$mail = SortMail($rS["email"]); //'kiki@gps.mk;';//SortMail('kiki@gps.mk;'.$rS["email"]);//SortMail($rS["email"]);
															
					if($mail != "False" && !strpos($mail, "@") === false) {
						$dsUser = query("select id, deflanguage, clientid, fullname, datetimeformat, (select name from clients where id = clientid) company from users where id = " . $rS["userid"]);
												
						//Delot za datum na reportot
						$sDate = DetectRange($rS["range"], 'sd');
						$eDate = DetectRange($rS["range"], 'ed');
						
						/*$datetimeformat = pg_fetch_result($dsUser, 0, "datetimeformat");
						$datfor = explode(" ", $datetimeformat);
						$dateformat = $datfor[0];
						
						$lang = mb_strtolower(pg_fetch_result($dsUser, 0, "deflanguage"));
						if ($lang == "mk") $i = 0;
						if ($lang == "en") $i = 1;
						if ($lang == "fr") $i = 2;
						if ($lang == "al") $i = 3;
						
						if ($rS["report"] == "overview") $transStr = explode("#", $transArr[0]);
						if ($rS["report"] == "OverviewV") $transStr = explode("#", $transArr[1]);
						if ($rS["report"] == "ShortReport") $transStr = explode("#", $transArr[2]);
						if ($rS["report"] == "Detail") 	$transStr = explode("#", $transArr[3]);
						if ($rS["report"] == "IdlingReport") $transStr = explode("#", $transArr[4]);
						if ($rS["report"] == "Taxi1Report") $transStr = explode("#", $transArr[5]);
						if ($rS["report"] == "Taxi2Report") $transStr = explode("#", $transArr[6]);
						if ($rS["report"] == "AnalTaxiActivity") $transStr = explode("#", $transArr[7]);
						if ($rS["report"] == "VehiclePOI") 	$transStr = explode("#", $transArr[8]);
						if ($rS["report"] == "AnalDistance") $transStr = explode("#", $transArr[9]);
						if ($rS["report"] == "AnalActivity") $transStr = explode("#", $transArr[10]);
						if ($rS["report"] == "AnalSpeed") $transStr = explode("#", $transArr[11]);
						if ($rS["report"] == "AnalSpeedEx") $transStr = explode("#", $transArr[12]);
						$report = $transStr[$i];
						if ($rS["report"] == "CustomizedReport") $report = dlookup("select name from reportgenerator where id = " . $rS["repid"]);
		
						if ($rS["vehid"] == "0") {
							$transStr = explode("#", $transArr[13]);
							$vehicle = $transStr[$i];
						} else {
							$vehicle = dlookup("select registration || ' (' || code || ')' from vehicles where id = " . $rS["vehid"]);
						}
													
						$bodyMK = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Почитувани,<br>Оваа порака ја добивате автоматски од системот за следење на вашите возила.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Корисник:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Компанија:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Датум на креирање:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Временски опсег:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Овој извештај е додаден во вашиот планер за автоматско периодично испраќање.<br>Во прилог Ви го испраќаме истиот.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Со почит,<br> Геонет ГПС тим</td><td><img width="70px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Не правете "Reply" на овој е-маил.<br>За подетални информации контактирајте нè на <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyEN = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Dear,<br>This message is sent automatically by the system for monitoring your vehicles.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">User:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Company:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Creation date:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date range:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">This report has been added in your scheduler to be automatic periodically sent.<br>In attachement we send you the report.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Best regards,<br> Geonet GPS team</td><td><img width="70px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Do not "Reply" to this e-mail.<br>For more information contact us at <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyFR = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Cher,<br>Ce message sera automatiquement le système pour le suivi de vos véhicules.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Utilisateur:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Entreprise:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Date de création:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Date de gamme:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Ce rapport a été ajouté à votre planificateur envoyer périodiquement automatique.<br>En plus je l envoie.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Cordialement,<br> Geonet GPS équipe</td><td><img width="70px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Ne pas "Répondre" à ce mail.<br>Pour plus d informations contactez-nous au <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						$bodyAL = '<html><meta http-equiv="Content-Type" content="text/html; charset=utf-8" /><body><table cellpadding="0" cellspacing="0" style="padding-top:20px; padding-left:20px; font-family: Arial, Helvetica, sans-serif; color:#2f5185; width: 280px;" border="0" style="position: absolute"><tr><td style="height: 50px;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td><img width="80px" align="right" src="http://panorama.gps.mk/images/PanoramaLogo.png" />Të dashur,<br>Ky mesazh automatikisht do të merrni sistemin për monitorimin e automjeteve tuaja.</td></tr></table></td></tr><tr><td style="background-color: transparent;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #E3EFFF; border-bottom: 1px solid #D2E4FC; border-top: 1px solid #D2E4FC; font-weight:bold; font-family: Arial, Helvetica, sans-serif; font-size:14px; color:#2f5185;"><tr><td width="16%" style="padding: 5px; opacity: 0.5; text-align: center; vertical-align: middle;"><img src="http://panorama.gps.mk/images/scheduler-24.png" /></td><td width="84%" style="text-transform: uppercase; text-align: left; vertical-align: middle;">' . $report . '<br><span style="font-size:12px; text-transform: none">' . $vehicle . '</span></td></tr><tr><td colspan="2" style="text-align: left; vertical-align: middle;"><table width="100%" cellpadding="0" cellspacing="0" border="0" style="border-top: 1px solid #D2E4FC; background-color: #F2F8FF; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Përdorues:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "fullname") . '</b></td></tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Kompani:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . pg_fetch_result($dsUser, 0, "company") . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; text-align: left; vertical-align: top;">Data e krijimit:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat(now(), pg_fetch_result($dsUser, 0, "datetimeformat")) . '</b></td></tr><tr><tr><td width="35%" style="padding-left: 10px; padding-top: 5px; padding-bottom: 5px; text-align: left; vertical-align: top;">Fushë:</td><td width="65%" style="text-align: left; padding-top: 5px; vertical-align: top;"><b>' . DateTimeFormat($sDate, $dateformat . " H:i") . ' -<br>' . DateTimeFormat($eDate, $dateformat . " 23:59") . '</b></td></tr></table></td></tr></table></td></tr><tr><td style="background-color: transparent; vertical-align: top;"><table width="100%" height="50px" cellpadding="0" cellspacing="0" border="0" style="padding-bottom: 10px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;"><tr><td style="padding-left: 10px; padding-top: 10px; text-align: left;">Ky raport është shtuar në projektues tuaj periodikisht dërgoni automatike.<br>Gjithashtu unë jam i dërguar atë.</td></tr></table><td></tr><tr><td><table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-left: 10px; padding-top: 8px; font-family: Arial, Helvetica, sans-serif; font-size:12px; color:#2f5185;border-top: 1px dotted #D2E4FC;"><tr><td>Të fala,<br> Geonet GPS ekipi</td><td><img width="70px" style="float: right;" src="http://panorama.gps.mk/images/GeonetLogo.png" /></td></tr><tr><td colspan="2" style="padding-top: 5px"><span style="font-size: 10px; color: #a3a3a3">* Mos "Përgjigju" për këtë e-mail.<br>Për më shumë informacion na kontaktoni në <a href="mailto:support@gps.mk" style="color: #FF6633">support@gps.mk</a></span>.</td></tr></table></td></tr></table></body></html>';
						*/	
																		
						if(mb_strtolower($rS["doctype"]) == "pdf") {
							if(strpos(mb_strtolower($rS["report"]), "customized") == 0) {
								//PDF (customized report)
                                $url = "http://panorama.gps.mk/pdf/indexK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**repid=" . $rS["repid"] . "**schid=" . $rS["id"];
							} else {
								//PDF (obicen report)
                                $url = "http://panorama.gps.mk/pdf/indexK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**schid=" . $rS["id"];
							}
						} else {
							if(strpos(mb_strtolower($rS["report"]), "customized") == 0) {
								//excel (customized report)
                                $url = "http://panorama.gps.mk/report/createXlsK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**repid=" . $rS["repid"] . "**schid=" . $rS["id"] . "&from=s";
							} else {
								//excel(obicen report)
                                $url = "http://panorama.gps.mk/report/createXlsK.php?page=" . $rS["report"] . "&req=l=" . pg_fetch_result($dsUser,0,"deflanguage") . "**uid=" . pg_fetch_result($dsUser,0,"id") . "**cid=" . pg_fetch_result($dsUser,0,"clientid") . "**sd=" . str_replace(" ", "_", $sDate) . "**ed=" . str_replace(" ", "_", $eDate) . "**v=" . $rS["vehid"] . "**vehNum=" . $rS["vehicle"] . "**schid=" . $rS["id"] . "&from=s";
							}
						}

						$Fname = "";
                        $Fname = file_get_contents($url);
                        $Fname = str_replace("\r", "", $Fname);
                        $Fname = str_replace("\n", "", $Fname);
                        $Fname = str_replace(" ", "", $Fname);
                       										
                       /* $bodyStr = $bodyEN;
						if ($lang == "en") $bodyStr = $bodyEN;
                        if ($lang == "mk") $bodyStr = $bodyMK;
                        if ($lang == "fr") $bodyStr = $bodyFR;
                        if ($lang == "al") $bodyStr = $bodyAL;
                       	
						//$dailybodyStr .= $bodyStr . "^^^";
						
						$transStr = explode("#", $transArr[14]);
						$subject = $transStr[$i];*/
						
						//$dailySubjects .= $subject . "***";
						//$dailyLang .= $lang . "%%%";
														
						try {
							$size = round(filesize($path . $Fname)/1000, 1);
							$filsize = $size . " kB";
							if ($size > 1000) {
								$size = round(filesize($path . $Fname)/1000000, 1);
								$filsize = $size . " MB";
							}
							
							
							
							//////////////						
							/*$currtime = time();	
							$inctime = $currtime;
							if (strlen($Fname) == 0) {
								while(($inctime - $currtime) < 360) {
									if (strlen($Fname) != 0) {
										
										SendMailAtach($mail, $path, $Fname, $bodyStr, $subject);	
										file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Sent to: " . $mail . " | File name: " . $Fname . " | Size: " . $filsize . "\r\n", FILE_APPEND);				
							
										$inctime = time();
										break;
									} else {
										$inctime = $inctime + 20;
								   		sleep(20);
									}
								}
								if (strlen($Fname) == 0) {
								//	sendScheduler();
								SendMailException1('kiki@gps.mk', $e1, $url);
								}
							} else {
								SendMailAtach($mail, $path, $Fname, $bodyStr, $subject);	
								file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Sent to: " . $mail . " | File name: " . $Fname . " | Size: " . $filsize . "\r\n", FILE_APPEND);				
							}*/
							////////////////
						} catch (Exception $e1) {
							SendMailException('kiki@gps.mk', $e1, $url);
							file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", $cnt . ". Exception: " . $e1 . "; Url: " . $url . "\r\n", FILE_APPEND);
						}
						$cnt++;
					}
				}
			}
		} catch (Exception $e) { }
		
	}
	//sending
	$dsSendSch = query("select * from sendscheduler where flag='0'");
	while($drSendSch = pg_fetch_array($dsSendSch)) {
		if ($drSendSch["size"] > 0)
			SendMailAtach($drSendSch["mail"], $drSendSch["path"], $drSendSch["fname"], $drSendSch["body"], $drSendSch["subject"]);
	}
	$r = runSQL("delete from sendscheduler where size > 0");
	
	while ($file1 = readdir($dirHandle1)) {		 
	    if(is_file($dir1 . $file1)) {
			$ret = file_get_contents($dir1 . $file1);
			chmod ($dir2 . $file1, 0777);
			
			$size = round(filesize($dir1 . $file1)/1000, 1);
			
			if ($size > 0) {
				if (copy($dir1 . $file1, $dir2 . $file1)) {
					unlink($dir1 . $file1);
					echo $dir1 . $file1;	
				}	
			}
	    }
	}
		
	$dsSendSch = query("select * from sendscheduler where size = 0 and flag = '0'");
	while($drSendSch = pg_fetch_array($dsSendSch)) {
		$urlTemp = $drSendSch["url"];	
		$Fname = "";
	    $Fname = file_get_contents($urlTemp);
	    $Fname = str_replace("\r", "", $Fname);
	    $Fname = str_replace("\n", "", $Fname);
	    $Fname = str_replace(" ", "", $Fname);
	}
	$dsSendSch = query("select * from sendscheduler where flag='0'");
	while($drSendSch = pg_fetch_array($dsSendSch)) {
		if ($drSendSch["size"] > 0)
			SendMailAtach($drSendSch["mail"], $drSendSch["path"], $drSendSch["fname"], $drSendSch["body"], $drSendSch["subject"]);
	}
	$r = runSQL("delete from sendscheduler where size > 0");
	$r = runSQL("update sendscheduler set flag='1' where size = 0");	
		
	$dir1 = "/var/www/panorama/savePDF1/";
	$dir2 = "/var/www/panorama/savePDF/";
	$dirHandle1 = opendir($dir1); 

	while ($file1 = readdir($dirHandle1)) {		 
	    if(is_file($dir1 . $file1)) {
			$ret = file_get_contents($dir1 . $file1);
			chmod ($dir2 . $file1, 0777);
			
			$size = round(filesize($dir1 . $file1)/1000, 1);
			
			if ($size > 0) {
				if (copy($dir1 . $file1, $dir2 . $file1)) {
					unlink($dir1 . $file1);
					echo $dir1 . $file1;	
				}	
			}
	    }
	}
	closedir($dirHandle1);
	//end sending
	
	file_put_contents($path1 . "scheduler_" .date("d-m-Y"). ".log", "E N D - " . date("d-m-Y H:i:s") . "\r\n". "\r\n", FILE_APPEND);
	closedb();
	
function SortMail($Mails) {
	$test = "";
	try {
		$Mail = array();
		$iscisteno = array();
		if($Mails != null && $Mails != "") {
			$Mails = str_replace(",", ";", $Mails);
			$Mails = str_replace(" ", ";", $Mails);
			$Mails = str_replace(":", ";", $Mails);
			
			$Mail = explode(";", $Mails);
			if(count($Mail) > 0) {
				$iscisteno = array_unique($Mail);
			}
			
			$Mails = implode(";",$iscisteno);

			if(strlen($Mails) < 5) {
				$Mails = "False";
			}
			return $Mails;
		}
	} catch (Exception $e) {
		return "False";
	}
}

function DetectRange($range, $str) {
	try {
		$eDate = DatetimeFormat(addDay(-1), 'Y-m-d 23:59:59');
		switch (mb_strtolower($range)) {
            case "last1":
				$sDate = DatetimeFormat(addDay(-1), 'Y-m-d 00:00:00');
                break;
            case "last2":
                $sDate = DatetimeFormat(addDay(-2), 'Y-m-d 00:00:00');
                break;
            case "last3":
                $sDate = DatetimeFormat(addDay(-3), 'Y-m-d 00:00:00');
                break;
            case "last4":
                $sDate = DatetimeFormat(addDay(-4), 'Y-m-d 00:00:00');
                break;
            case "last5":
                $sDate = DatetimeFormat(addDay(-5), 'Y-m-d 00:00:00');
                break;
            case "last6":
                $sDate = DatetimeFormat(addDay(-6), 'Y-m-d 00:00:00');
                break;
            case "last7":
                $sDate = DatetimeFormat(addDay(-7), 'Y-m-d 00:00:00');
                break;
            default:
                $sDate = DatetimeFormat(addDay(-1), 'Y-m-d 00:00:00');
                break;
        }
		if ($str == "sd") return $sDate;
		if ($str == "ed") return $eDate;
	}
	catch (Exception $e) {}
}

function SendMailAtach($mail, $path, $Fname, $body, $subject) {
	//exit;	
	echo $subject . " " . $mail . "<br>" . $body;
		
	$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
  	->setUsername('sysinfo@gps.mk')
 	->setPassword('geo!net123*$');
	$mailer = Swift_Mailer::newInstance($transport);

	$message = Swift_Message::newInstance(dic_($subject))
	  ->setFrom(array('sysinfo@gps.mk' => 'Geonet GPS Solutions'))
	  ->setBody('Geonet GPS')
	  ->addPart($body, 'text/html')
	  ->attach(Swift_Attachment::fromPath($path . $Fname));
	
	$failedRecipients = array();
	$numSent = 0;
	$to = explode(";", $mail);

	foreach ($to as $address => $name)
	{
	  if (is_int($address) and $name <> "") {
	    $message->setTo($name);
		$numSent += $mailer->send($message, $failedRecipients);
	  } else {
	    //$message->setTo(array($address => $name));
	  }
	 // $numSent += $mailer->send($message, $failedRecipients);
	}
}

function SendMailException($mail, $exc, $url) {
	
	$body = '<div style="padding: 15px; font-family: Arial, Helvetica, sans-serif; color:#2f5185;; font-size:14px"><strong>Url:</strong> ' . $url . "<br><strong>Error:</strong> " . $exc . "</div>";
		
	$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
  	->setUsername('sysinfo@gps.mk')
 	->setPassword('geo!net123*$');
	$mailer = Swift_Mailer::newInstance($transport);

	$message = Swift_Message::newInstance('Scheduler error')
	  ->setFrom(array('sysinfo@gps.mk' => 'Geonet GPS Solutions'))
	  ->setBody('Geonet GPS')
	  ->addPart($body, 'text/html');
	
	$failedRecipients = array();
	$numSent = 0;
	$to = explode(";", $mail);

	foreach ($to as $address => $name) {
	  if (is_int($address) and $name <> "") {
	    $message->setTo($name);
		$numSent += $mailer->send($message, $failedRecipients);
	  } else {
	    //$message->setTo(array($address => $name));
	  }
	 // $numSent += $mailer->send($message, $failedRecipients);
	}
}

/*function SendMailException1($mail, $exc, $url) {
	
	$body = '<div style="padding: 15px; font-family: Arial, Helvetica, sans-serif; color:#2f5185;; font-size:14px"><strong>Url:</strong> ' . $url . "<br><strong>Error:</strong> " . $exc . "</div>";
	
	$transport = Swift_SmtpTransport::newInstance('mail.gps.mk', 25)
  	->setUsername('sysinfo@gps.mk')
 	->setPassword('geo!net123*$');
	$mailer = Swift_Mailer::newInstance($transport);

	$message = Swift_Message::newInstance('Scheduler not sent')
	  ->setFrom(array('sysinfo@gps.mk' => 'Geonet GPS Solutions'))
	  ->setBody('Geonet GPS')
	  ->addPart($body, 'text/html');
	
	$failedRecipients = array();
	$numSent = 0;
	$to = explode(";", $mail);

	foreach ($to as $address => $name) {
	  if (is_int($address) and $name <> "") {
	    $message->setTo($name);
		$numSent += $mailer->send($message, $failedRecipients);
	  } else {
	    //$message->setTo(array($address => $name));
	  }
	 // $numSent += $mailer->send($message, $failedRecipients);
	}
}*/

?>

