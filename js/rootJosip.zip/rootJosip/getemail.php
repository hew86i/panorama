 <?php
 
ini_set('display_errors', 1);
error_reporting(E_ALL);

//$host="{gmail.com:143/notls}";
$email = "marjanmivanovski@gmail.com";
$pass = "geonetgps*#^";
$host = "{imap.gmail.com:993/imap/ssl/novalidate-cert}";





function email_folder_count($folder, $host1, $inb)
	{
		$status = imap_status($inb, $folder, SA_ALL);
		if ($status)
		{
			echo "Messages: " . $status->messages . "<br />\n";
			echo "Unseen: " . $status->unseen . "<br />\n";
		}
		else
		{
			echo "imap_status failed: " . imap_last_error() . "\n";
		}
	}
	
if ($mbox=imap_open($host, $email, $pass))
{
	
	$imap_obj = imap_check($mbox);
	echo "<h1>CONNECTED TO IMAP HOST</h1><h2>$host (".  $imap_obj->Nmsgs  .")<h2>";
	
	echo "<h3>IMAP LIST OF FOLDERS</h3>";
	$folders = imap_list($mbox, $host, "*");
	echo "<ul>";
	foreach ($folders as $folder) {
		$cnt = 0;
		/*$status = imap_status($mbox, $folder, SA_ALL);
		if ($status) {
			$cnt = $status->messages;
		  echo "Messages:   " . $status->messages    . "<br />\n";
		  echo "Recent:     " . $status->recent      . "<br />\n";
		  echo "Unseen:     " . $status->unseen      . "<br />\n";
		  echo "UIDnext:    " . $status->uidnext     . "<br />\n";
		  echo "UIDvalidity:" . $status->uidvalidity . "<br />\n";
		}*/
		//$fold = str_replace($host, "", $folder);
		//$fold = str_replace("[Gmail]/", "", $fold);
		$check = imap_mailboxmsginfo($mbox);
		email_folder_count($folder,1,$mbox);
		
		//echo '<li><a href="mail.php?folder=' . imap_utf7_decode($folder) . '&func=view">' . imap_utf7_decode($folder) . '  -  ' . $check->Unread . '</a></li>';
		echo "<br>";
	}
	echo "</ul>";
	imap_close($mbox);
} else
{
	echo "<h1>FAILED TO CONNECT TO IMAP HOST!</h1>\n";
	exit;
	$err = imap_errors();
	$pos = strrpos($err[2], "Invalid username or password");
	if ($pos === false) { // note: three equal signs
	    // not found...
	    echo "Invalid username or password";
	} else
		{
			echo "Ok";
		}
	
	//echo $err[0];
}
?> 