﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>

	<html xmlns="http://www.w3.org/1999/xhtml">
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<script type="text/javascript" src="../js/jquery.js"></script>
		</head>
	
		<body>


		<form name=emails action="mail1.php" method="post">
			<textarea id="emails" name="n" rows="4" cols="50"></textarea><br>
			<input style="font-size: 17px" type=button onClick="submitform()" value="Прати"/>
		</form>
	
		</body>
	</html>

	<script>
		function submitform()
		{
		   document.forms["emails"].submit();
		}
	</script>
