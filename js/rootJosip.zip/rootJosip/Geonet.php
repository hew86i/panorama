﻿<?php include "./include/db.php" ?>
<?php include "./include/functions.php" ?>
<?php include "./include/params.php" ?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
        <style>
			.textQ {
				font-family:Arial, Helvetica, sans-serif; 
				font-size:24px; 
				font-weight:normal; 
				color:#ffffff; 
				text-decoration: none
			}
  		
        </style>
</head>
	<script>
		lang = 'mk'
	</script>
	
	<link rel="stylesheet" type="text/css" href="./style.css">
	<link rel="stylesheet" type="text/css" href="./css/ui-lightness/jquery-ui-1.8.14.customQ.css">	
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
	<script type="text/javascript" src="./js/iScroll.js"></script>
    <script src="./js/jquery-ui.js"></script>
    
    	
<?php
    opendb();
	$ipa = getIP();
	$ipa = getIP();
	if ($ipa <> "80.77.159.246") {
		 echo header( 'Location: Geonet_ForbiddenIP.php');
	}

$exp = nnull(getQUERY("exp"), '0');	
	if ($exp == '1') {
		$r = runSQL("update geonetcandidate set timeexpired='1' where fullname='" . $_SESSION['candidate'] . "'");
	}
	session_destroy();
	
?>

<body>
	
	<div style="background-color:#000000; width:100%; height:100%">
		<table id="tblStart" width=60% style="margin:0 auto;">
			<tr>
				<td style="text-align: center; padding-top:5%">
					<img src="./images/GeonetLogo.png" border="0" align="absmiddle" />
				</td>
			</tr>
			<?php
			if ($exp == 0) {
				?>
				<tr>
					<td class="textQ" style="text-align: center; padding-top:6%">
						Добредојде на тестирањето за<br>
						<label><input type="radio" name="T" value="PHP">PHP developer</label><br>
						<label><input type="radio" name="T" value=".Net">.Net developer&nbsp;</label><br><br>
						
						Тестот содржи прашања на кои треба да се одговори<br>одбирајќи еден од понудените одговори.<br>
						Времетраењето на тестирањето е 20 минути.<br><br>
						Со среќа!
					</td>
				</tr>
				
				<tr>
					<td class="textQ" style="text-align: center; padding-top:8%">
						<table align="center" width=80%>
							<tr>
								<td width=100% class="textQ" style="text-align: center">Внесете го вашето име и презиме:</td>
							</tr>
							<tr>
								<td width=70% align="center"><input type="text" id="fullname" style="padding-left:5px; height:40px; width:65%; font-weight: bold; font-size:18px; color: #000000"/></td>
							</tr>
							<tr>
								<td width=100%>
									<div id="exist" style="visibility:hidden; text-align: center; font-style: italic; font-size:12px; color:red">* Веќе постои корисник со ова име и презиме.</div>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				
				<tr>
					<td style="text-align: center; padding-top:4%">
						<button id="startQ" onClick="loadQ(1)" style="font-size:14px; font-weight: bold">Старт</button>
					</td>
				</tr>
				<?php
			} else {
				?>
				<tr>
					<td class="textQ" style="text-align: center; padding-top:10%">
						Почитуван/а<span style="font-weight:bold; color: #ff6600"> <?=$_SESSION['candidate']?></span>,
						<br><br>Вашето време за решавање на тестот истече.
						<br>Успеавте да одговорите на <?=(getQUERY("nQ")-1)?> прашања.
						<br>Вашите одговори се зачувани и истите
						<br>ќе бидат обработени од страна на нашиот систем.
						<br>Ви благодариме на одвоеното време.
						<br><br>Со почит,<br>Геонет ГПС.
					</td>
				</tr>
				<?php
			}
			?>
			
		</table>
		
		<iframe id="ifrm-q" src="./report/temp.php" width="100%" height="100%" frameborder="0" scrolling="no" ></iframe>		
	</div>
	


    <?php
    closedb();
    ?>
    
</body>
<script type="text/javascript">
/*window.onbeforeunload = function() {
   return(888)
}*/

	 $('#startQ').button({ icons: { primary: ""} })
	 var lastGroupNum = 0;
	 
	 function loadQ(_n) {
	 	if (!$("input[name='T']:checked").val()) {
	 		alert("Немате избрано работно место за кое конкурирате !")
	 	} else {
	 	if ($('#fullname').val() == "") {
	 		alert("Внесете ваше име и презиме !")
	 	} else {
	 		$.ajax({
		        url: "GeonetCheckUser.php?fullname="+$('#fullname').val(),
		        context: document.body,
		        success: function (data) {
					var _dat = data;
		        	_dat = _dat.replace(/\r/g,'').replace(/\n/g,'');
		        	if (_dat == 0) {
		        		$('#tblStart').css({display: 'none'});
		 					document.getElementById('ifrm-q').src = 'GeonetQ.php?q='+_n+'&candidate=' + $('#fullname').val()+'&lastgroupnum='+lastGroupNum+'&typeTest='+$("input[name='T']:checked").val();
		        	} else {
		        		$('#fullname').focus();
		        		$('#fullname').css({border: '2px solid red'});
		        		$('#exist').css({visibility: 'visible'});
		        	}		        	
		        }
		    });
		 	}
	 		
	 	}
	 }	
		 
	 $(document).ready(function () {
        $('#fullname').focus();
        $(document).bind('keypress', function(e) {
    		var p = e.which;
		     if(p == 13){
		         loadQ(1);
		     }
	 	});	 
    });
</script>
</html>


