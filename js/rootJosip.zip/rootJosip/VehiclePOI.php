﻿<?php include "../include/db.php" ?>
<?php include "../include/functions.php" ?>
<?php include "../include/params.php" ?>
<?php include "../include/dictionary2.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>
	<script>
			lang = '<?php echo $cLang?>'
	</script>
	<link rel="stylesheet" type="text/css" href="../style.css">
	
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/share.js"></script>
	<script type="text/javascript" src="../js/iScroll.js"></script>
	<script type="text/javascript" src="reports.js"></script>
	<script type="text/javascript" src="../js/highcharts.src.js"></script>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js" type="text/javascript"></script>
    <script src="js/chosen.jquery.js" type="text/javascript"></script>
    <link rel="stylesheet" href="chosen.css">
    <style type="text/css" media="all">
	    /* fix rtl for demo */
	    .chzn-rtl .chzn-search { left: -9000px; }
	    .chzn-rtl .chzn-drop { left: -9000px; }
    </style>
	<!--<script type="text/javascript" src="./js/jquery-1.7.2.js"></script>-->
	

	<link href="../css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="../js/jquery-ui.js"></script>
	 <style type="text/css">
		
		td.headerSortUp {
		    background-image: url("../images/up2.png");
		    background-repeat: no-repeat;
		    background-position: right center;
		}
		td.headerSortDown {
		    background-image: url("../images/down2.png");
		    background-repeat: no-repeat;
		    background-position: right center;
		}
		td.backupdown {
			background-image: url('../images/updown.png'); 
			background-repeat: no-repeat; 
			background-position: right center;
		}
		
	</style>   
	
	<script>
  		if (<?php echo nnull(is_numeric(nnull(getQUERY("uid"))), 0) ?> == 0){
  			if (<?php echo nnull(is_numeric(nnull(session("user_id"))), 0) ?> == 0)
  				top.window.location = "../sessionexpired/?l=" + '<?php echo $cLang ?>';
  		} 
  	</script>
  	
	<?php

	$meseci = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
		if (nnull(is_numeric(nnull(getQUERY("uid"))), 0)>0){
			$uid = getQUERY("uid");
			$cid = getQUERY("cid");	
		} else {
			$uid = session("user_id");
			$cid = session("client_id");
		}

		/*$poi = nnull(getQUERY("poi"), 0);
		$min = nnull(getQUERY("min"), 2);*/
		
		//If (Session("client_id") == 325) { $poi = 3; $min = 5;}
			
		opendb();
		
		$Allow = getPriv("visitedpoi", $uid);
		if ($Allow == False) echo header ('Location: ../permission/?l=' . $cLang);
		   
		$user_id = $uid; //154;//$_SESSION['user_id'];//nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
		$client_id = $cid; //154;// $_SESSION['client_id'];//nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
				    
		//$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		 
	    $vh = nnull(getQUERY("v"), "0"); //645;//
	 	
	 	/*format na datum*/
		$datetimeformat = dlookup("select datetimeformat from users where id=" . $uid);
		$datfor = explode(" ", $datetimeformat);
		$dateformat = $datfor[0];
		$timeformat =  $datfor[1];
		if ($timeformat == 'h:i:s') $timeformat = $timeformat . " a";
		
		if ($timeformat == "H:i:s") {
			$e_ = " 23:59";
			$e1_ = "_23:59";
			$s_ = " 00:00";
			$s1_ = "_00:00";
			$tf = " H:i";
		}	else {
			$e_ = " 11:59 PM";
			$e1_ = "_11:59_PM";
			$s_ = " 12:00 AM";
			$s1_ = "_12:00_AM";
			$tf = " h:i a";
		}		
		
		$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		
	    $vh = nnull(getQUERY("v"), "0"); //645;//
	    $sdG = DateTimeFormat(getQUERY("sd"), 'd-m-Y H:i:s');
		$edG = DateTimeFormat(getQUERY("ed"), 'd-m-Y H:i:s');
		
	    $sd = DateTimeFormat(getQUERY("sd"), $dateformat) . $s_; //'01-09-2012 00:00';
	    $ed = DateTimeFormat(getQUERY("ed"), $dateformat) . $e_; //'01-09-2012 23:59';
		
	    
	$tzone = dlookup("select tzone from users where id=" . $user_id);  
	$CreationDate = strtoupper(DateTimeFormat(addToDateU(now(), $tzone, "hour", "Y-m-d H:i"), $datetimeformat));  

		/*format na datum*/
		          
		$sqlV = "";
		if ($vh == "0") {
			$vozila = ' за сите возила';
			if ($_SESSION['role_id'] == "2") { 
		        $sqlV = "select id from vehicles where clientID=" . $client_id;
			} else {
				$sqlV = "select vehicleID from UserVehicles where userID=" . $user_id . "";
			}
		} else {
			$sqlV = $vh;
			$tmpvoz = dlookup("select cast(array_agg(registration || ' (' || code || ')') as text) from vehicles where id in (" . $vh . ")");
			$tmpvoz = str_replace("{", "", $tmpvoz);
			$tmpvoz = str_replace("}", "", $tmpvoz);
			$vozila = ' за возилата: ' . $tmpvoz;
		}
		
		addlog(20, 'Период од: ' . $sdG . ' до: ' . $edG . $vozila);	
	
		$_SESSION["user_fullname"] = dlookup("select fullname from users where id='" . $user_id . "'");
		$_SESSION["company"] = dlookup("select name from clients where id in (select clientid from users where id=" . $user_id . " limit 1) limit 1");
			    
	    //Dim timezone1 As Integer = DlookUP("select timezone from draft.dbo.Clients c where ID = '" & client_id & "'") - 1
	
  		//$dateFormat1 = "d-m-Y H:i:s";//nnull(dlookup("select datetimeformat from users where id = '" . $user_id . "'"), "d-m-Y");
	
    //Dim timeFormat1 As String = NNull(DlookUP("select TimeFormat from UserSettings where UserId = '" & user_id & "'"), "24 Hour Time")
	/*Dim timeFormat0 As String
    
	Dim timeFor As String = ""
    If timeFormat1 = "24 Hour Time" Then
	        timeFormat0 = "HH:mm:ss"
	        timeFor = "HH:mm"
    End If
    If timeFormat1 = "12 Hour Time" Then
	        timeFormat0 = " hh:mm:ss tt"
	        timeFor = "hh:mm"
    End If*/
    
   
    /*Dim sd1 As DateTime
    sd1 = New System.DateTime(CInt(sd.Split("-")(2).Split(" ")(0)), CInt(sd.Split("-")(1)), CInt(sd.Split("-")(0)), 0, 0, 0, 0)*/
    //$sd2 = DateTimeFormat($sd, $dateFormat1);
  
    /*Dim ed1 As DateTime
    ed1 = New System.DateTime(CInt(ed.Split("-")(2).Split(" ")(0)), CInt(ed.Split("-")(1)), CInt(ed.Split("-")(0)), 0, 0, 0, 0)*/
   // $ed2 = DateTimeFormat($ed, $dateFormat1);
    
    $vh = getQUERY("v");
	
    $vn = getQUERY("vehNum");
    $vn1 = "";
    
    If ($vn == "0") {
        $vn1 = "All vehicles";
    } Else {
        $vn1 = $vn;
    }
   
    //dlookup("delete from report");
    //dlookup("INSERT INTO Report (uid, cid, sd, ed, vn, vh) VALUES ('" . $uid . "', '" . $cid . "', '" . $sd . "', '" . $ed . "', '" . $vn1 . "', '" . $vh . "')");
    	
	//$cntUser = dlookup("select count(*) from clients where id='" . $client_id . "'"); //1;//
    //If ($cntUser == 0) echo header('Location: ../sessionexpired/?l=' . $cLang);
   
   /* $creationTime = "";
    If timeFormat1 = "24 Hour Time" Then
        creationTime = (Now.AddHours(timezone1)).ToString(dateFormat1 + " HH:mm:ss")
    End If
    If timeFormat1 = "12 Hour Time" Then
        creationTime = Format((Now.AddHours(timezone1)), dateFormat1 + " hh:mm:ss tt").ToString()
    End If
    
	*/
	
	
	$Allow = true;//getPriv("VisitedPOI", user_id)
	if ($Allow == false) {
	        echo "<br><br>&nbsp;&nbsp;&nbsp;<span class='textTitle'>" . dic_("Reports.Permission") . "</span>";
		?><script>top.HideWait()</script>
		<?php
		exit();
	}
	
    If (strrpos(strtoupper(Session("user_fullname")), "DEMO") > 0)  $_SESSION["company"] = dic_("Reports.DemoCompany");
    If (strrpos(strtoupper(Session("user_fullname")), "ДЕМО") > 0)  $_SESSION["company"] = dic_("Reports.DemoCompany");

	$sqlV = "";
	$sqlV = $vh;	                                
		  	                     
	 	 
    $where = "";
		
    //If (Session("client_id") == 325) {	                                         
     //   $where = "WHERE starttime>='" . DateTimeFormat($startdate, "Y-m-d") . " " . DateTimeFormat($startTime1, "H:i") . "' and endtime<='" . DateTimeFormat($enddate, "Y-m-d") . " " . DateTimeFormat($endTime1, "H:i:s") . "' and vehicleID = " . $vh . " and duration >= 300";
	//} Else {
			
		
   /* $where = "WHERE starttime>='" . DateTimeFormat($startdate, "Y-m-d") . " " . DateTimeFormat($startTime1, "H:i") . "' 
    and endtime<='" . DateTimeFormat($enddate, "Y-m-d") . " " . DateTimeFormat($endTime1, "H:i:s") . "' 
    and vehicleID = " . $vh . " and duration >= " . (intval($min * 60)) . "";*/
	
	 $where = "WHERE starttime>='" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' 
    and endtime<='" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59' 
    and vehicleID = " . $vh;
    //}
   
	$langArr = explode("?", getQUERY("l"));
	$cLang = $langArr[0];
	
	//permissions
	$noPermSch = "";
	$noPermEmail = "";
	$noPermPdf = "";
	$noPermExc = "";
	
	//scheduler
	$prSch = getPriv("exportexcel", $user_id);
	if ($prSch == true) {
		$schStyle = "style='float:right; cursor:pointer'";
		$schClick = "AddScheduler(5, $user_id)";
	} else {
		$schStyle = "style='float:right; opacity:0.5; cursor:default'";
		$schClick = "";
		$noPermSch = dic_("Reports.NoPermiss") . " "; 
	}
	//email
	$prEmail = getPriv("sendmail", $user_id);
	if ($prEmail == true) {
		$emailClick = "AddEmail(5, '$user_id', 'Visited points of interest', '$cLang')";
		$emailStyle = "style='float:right; cursor:pointer'";
	}else {
		$emailClick = "";
		$emailStyle = "style='float:right; opacity:0.5; cursor:default'";
		$noPermEmail = dic_("Reports.NoPermiss") . " "; 
	}
	
	//pdf
	$prPdf = getPriv("exportpdf", $user_id);
	if ($prPdf == true) {
		$pdfClick = "createPDF1('VehiclePOI')";
		$pdfStyle = "style='float:right; cursor:pointer'";
	}else {
		$pdfClick = "";
		$pdfStyle = "style='float:right; opacity:0.5; cursor:default'";
		$noPermPdf = dic_("Reports.NoPermiss") . " "; 
	}
	//excel
	$prExcel = getPriv("exportpdf", $user_id);
	if ($prExcel == true) {
		$excHref = "href='./VehiclePOI1.php?l=$cLang&u=$user_id&c=$client_id&vn=$vn&vh=$vh ?>&sd=$sd&ed=$ed' ";
		$excStyle = "style='float:right; cursor:pointer'";
	}else {
		$excHref = "";
		$excStyle = "style='float:right; opacity:0.5; cursor:default'";
		$noPermExc = dic_("Reports.NoPermiss") . " "; 
	}
	$idleover = dlookup("select idleover from users where id=" . $uid);
	 
	?>
	
<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="SetHeightLite()">

	<div id="dialog-map" style="display:none" title="<div onclick='closedialog()' style='font-size: 11px; position: relative; left: 5px;' id='closeAlarm' class='ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only' role='button'><span class='ui-button-text'>Затвори</span></div> &nbsp;&nbsp;&nbsp;&nbsp;  <?php echo dic_("Reports.ViewOnMap")?>"></div>
	<div id="div-add-schedule" style="display:none" title="<?php dic("Reports.AddSchedule")?>"></div>
	<div id="div-add-email" style="display:none" title="<?php dic("Reports.SendReport")?>"></div>
	<div id="dialog-message" title="<?php dic("Reports.Message")?>" style="display:none">
		<p>
			<span class="ui-icon ui-icon-circle-check" style="float:left; margin:0 7px 50px 0;"></span>
			<div id="div-msgbox" style="font-size:14px"></div>
		</p>
	</div>

<div id="report-content" style="width:100%; height:100%; text-align:left; height:500px; background-color:#fafafa; overflow-y:auto; overflow-x:hidden" class="corner5">
	<div id="icons" style="position: relative; right:8px">
        <div onclick="<?php echo $schClick?>" <?php echo $schStyle?> >
	            <span id="iconSCH"><img id="imgSch" src="../images/sch.png" width="16" height="16" align="absmiddle" title="<?php echo $noPermSch . "" . dic_("Reports.AddScheduler")?>">&nbsp;</span> 
	        </div>

	        <div onclick="<?php echo $emailClick?>" <?php echo $emailStyle?>>
	            <span id="iconEMAIL" ><img id="imgEmail" src="../images/eEmail.png" width="16" height="16" align="absmiddle" title="<?php echo $noPermEmail . "" . dic_("Reports.SendToMail")?>">&nbsp;</span>
	        </div>
	        	        	       
	        <div onclick="<?php echo $pdfClick?>" <?php echo $pdfStyle?>>
			    <span id="iconPDF" ><img id="imgPdf" src="../images/epdf.png" width="16" height="16" align="absmiddle" title="<?php echo $noPermPdf . "" . dic_("Reports.ExportPDF")?>">&nbsp;</span>
			</div>
		
<div onclick="createXls1('VehiclePOI', 'a', 0)" <?php echo $excStyle?>>
			    <span id="iconCSV" ><img id="imgXls" src="../images/eExcel.png" width="16" height="16" align="absmiddle" title="<?php echo $noPermExc . "" . dic_("Reports.ExportExcel")?>">&nbsp;</span>
		   </div>
					
	        
	</div>
	<br>
	
<?php
			$where1 = "WHERE starttime>='" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' and endtime<='" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59'
		     and vehicleID in (" . $vh . ") and duration >= " . (intval($idleover * 60)) . "";
			$sqln_ = "";
	        $sqln_ .= "select pinpoint, pinpointID, count(*) cnt, sec2time(cast(sum(duration) as integer)) duration, cast(sum(duration) as integer) durval ";
	        $sqln_ .= "from rpointsofinterest ";
	 		$sqln_ .= " " . $where1 . " and pinpointID in (select id from pointsofinterest where clientid=" . $cid . ")";
	        $sqln_ .= "group by pinpoint, pinpointID order by 1 asc";
			$dsn = query($sqln_);
			//echo $sqln_;
		?>
<?php
if (pg_num_rows($dsn) > 0) {
?>	
	<div style="position: relative; right:8px; float: right; margin-top:9px">
		



	<table width="100%" border="0" cellspacing="2" cellpadding="2" align="center" >
    		<tr>
    			<td style="float: right">
    				
    				<div class="side-by-side clearfix" style="float:right; ">
			        
			           <select id = "poi_" class="chzn-select-no-results" tabindex="10" data-placeholder="<?php echo dic_("Reports.ChoosePOI")?>" style="font-size: 11px; position: relative; top: 0px; visibility: visible; float: right; font-family:Arial, Helvetica, sans-serif" onchange="OptionsChangeAll()" class="combobox text2">	
				            <option id="0" value="0" selected ><?php echo dic_("all")?></option>
				            <option style="height: 1px; position: relative; top:-9px" disabled="disabled">------------------------------------------------</option>
				            <?php
		      				$dsn = query($sqln_);
		      				$cnt = 0;
		      				while ($dr = pg_fetch_array($dsn)) {
		      					?>
		      					<option id="<?php echo $dr["pinpointid"]?>" value="<?php echo $cnt?>"><?php echo $dr["pinpoint"]?></option>
		      					<?php
		      					$cnt ++;
		      				}
		      				?>
				       </select>
				         <!-- <span class="text5" style="float: right; position: relative; top: 7px; visibility: visible; right: 11px;">
			     			<strong>Точка од интерес:</strong>
			     		  </span>-->
			      </div>
			      <span class="text5" style="float: right; position: relative; top: 7px; visibility: visible; right: 11px;">
			     			<strong><?php echo dic_("Reports.POI")?>:</strong>
			     		  </span>
      
    			</td>
    		</tr>
    	</table>

    </div>	
    	<br>
<br>
<?php
}
?>	
    <?php
   
        If ($vh == "0") {
            If ($_SESSION['role_id'] == "2") {
                $sqlV = "select id from vehicles where clientID=" . $client_id;
            } Else {
                $sqlV = "select vehicleID from UserVehicles where userID=" . $user_id . "";
            }
        } Else {
            $sqlV = $vh;
        }
        
        $dsVh = query("select * from vehicles where id in (" . $sqlV. ") order by organisationid desc, code asc");
        $ifNot = 0;
      	
		$dsVehicles = query("select * from vehicles where id in (" . $sqlV . ") limit 1");
		
		$vehicle = "";
		
		if (getQUERY("v") <> 0) {
			$vehicle = pg_fetch_result($dsVehicles, 0, "registration") . " (" . pg_fetch_result($dsVehicles, 0, "code") . ")";	
		} else {
			$vehicle = dic_("Reports.AllVehicles");
		}
		
		$sqlG_ = "";
		$idVeh = "";
		$idPoi = "";
		$idPoiNames = "";
	    while ($rV = pg_fetch_array($dsVh)) {
	    		$ifDriver = dlookup("select count(driver) from rshortreport where vehicleid=" . $rV["id"] . " and datetime > '" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' and datetime < '" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59' and driver <> ''");
				$vh = $rV["id"];		
				$idVeh .= $vh . ";";	
      			//$reg = nnull(dlookup("select registration || ' ' || coalesce(alias, '') ||' ('||code || ')' from vehicles where id=" . $vh), "");
            		$reg = nnull(dlookup("select registration || ' ' || '(' || code || ')' || '<br><span style=''font-size:14px''>' || coalesce(alias, '') || '</span>' from vehicles where id=" . $vh), "");

	            //If (Session("client_id") == 325) {
	            //    $where = "WHERE starttime>='" . DateTimeFormat($startdate, "Y-m-d") . " " . DateTimeFormat($startTime1, "H:i") . "' and endtime<='" . DateTimeFormat($enddate, "Y-m-d") . " " . DateTimeFormat($endTime1, "H:i:s") . "' and vehicleID = " . $vh . " and duration >= 300";
				//} Else {
	            $where = "WHERE starttime>='" . DateTimeFormat($sdG,"Y-m-d") . " 00:00:00' and endtime<='" . DateTimeFormat($edG,"Y-m-d") . " 23:59:59'
	             and vehicleID = " . $vh . " and duration >= " . (intval($idleover * 60)) . "";
	            //}
	            
	            /*$where = "WHERE endtime<='" . DateTimeFormat($enddate, "Y-m-d") . " " . 
	            DateTimeFormat($endTime1, "H:i:s") . "' and vehicleID = " . $vh;*/
				$sql1_ = "";
                //$sql1_ &= "select pinpoint, pinpointID, count(*) cnt, geonet.dbo.fn_time_goran(sum(duration)) duration ";
                $sql1_ .= "select pinpoint, pinpointID, count(*) cnt, sec2time(cast(sum(duration) as integer)) duration, cast(sum(duration) as integer) durval, type ";
                $sql1_ .= "from rpointsofinterest ";
               // $sql1_ .= " " . $where . " ";
 $sql1_ .= " " . $where . " and pinpointID in (select id from pointsofinterest where clientid=" . $cid . ")";
	            $sql1_ .= "group by pinpoint, pinpointID, type order by 3 desc, 4 desc";

	            $sqlG_ .= "select pinpoint, pinpointID, count(*) cnt, cast(sum(duration) as integer) duration ";
                $sqlG_ .= "from rpointsofinterest ";
                $sqlG_ .= " " . $where . " ";
	            $sqlG_ .= "group by pinpoint, pinpointID order by 3 desc, 4 desc";
	            $sql1 = "";
	            //$sql1 .= "select pinpoint, pinpointID, geonet.dbo.fn_time_goran(sum(duration)) duration ";
	            $sql1 .= "select pinpoint, pinpointID, sec2time(cast(sum(duration) as integer)) duration ";
	            $sql1 .= "from rpointsofinterest ";
	            $sql1 .= " " . $where . " ";
	            $sql1 .= "group by pinpoint, pinpointID order by 3 desc";
	      

	            $ds = query($sql1_);
				
				$cntDs = pg_num_rows($ds);
				
	            $langArr = explode("?", getQUERY("l"));
				$cLang = $langArr[0];
		        
				if (empty($ds)) {
			   		ob_clean();
			        echo "<br><br>&nbsp;&nbsp;&nbsp;<span style='position:absolute; left:30%; top:40%; font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; color:#2f5185;'>" . dic_("Reports.ReportNotLoaded") . "</span>";
					?><script>top.HideWait()</script><?php
			        exit();
				}	
			
	            $ds1 = query($sql1);
				
	            $langArr = explode("?", getQUERY("l"));
				$cLang = $langArr[0];
		        
		        if (empty($ds1)) {
			   		ob_clean();
			        echo "<br><br>&nbsp;&nbsp;&nbsp;<span style='position:absolute; left:30%; top:40%; font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; color:#2f5185;'>" . dic_("Reports.ReportNotLoaded") . "</span>";
					?><script>top.HideWait()</script><?php
			        exit();
				}	
			
			    $langArr = explode("?", getQUERY("l"));
				$cLang = $langArr[0];
				 
				if ($rV["organisationid"] == 0) $orgName = dic_("Reports.UngroupedVehicles");
				else $orgName = dlookup("select name from organisation where id=" . $rV["organisationid"] . " and clientid=" . $cid); 
            ?>
            <br />
    <div id="div-<?php echo $rV["id"]?>" style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%; margin-bottom:20px" class="corner5"> 
	<div class="textTitle" style="padding-left:40px; padding-top:10px">
		<?php echo mb_strtoupper(dic_("Reports.VisitedPOI"), 'UTF-8') ?><br />
        <div class="textTitle" style="font-size:18px"><?php echo $reg?><br /><br /></div>
		<span class="text5"> <?php dic("Reports.User")?>: <strong><?php echo session("user_fullname")?></strong></span><br />
		<span class="text5"> <?php dic("Reports.Company")?>: <strong><?php echo session("company")?></strong></span><br />
		<span class="text5"> <?php dic("Reports.OrgUnit") ?>: <strong><?php echo $orgName?></strong></span><br>
		<span class="text5"> <?php dic("Reports.CreationDate")?>: <strong><?php echo $CreationDate?></strong></span><br />
		<span class="text5"> <?php dic("Reports.DateTimeRange")?>: <strong><?php echo $sd ?></strong> - <strong><?php echo $ed?></strong></span><br /><br>
	</div>
	
	<!--<table width="94%" border="0" cellspacing="2" cellpadding="2" align="center" style="margin-top:-30px; margin-left:35px">
    		<tr>
    			<td style="float: right">
    				<select id = "poi-<?php echo $rV["id"]?>" style="font-size: 11px; position: relative; top: 0px ;visibility: visible; float: right;" onchange="OptionsChangeVeh(<?php echo $rV["id"]?>)" class="combobox text2">
    					<option value="0" selected>Сите</option>
	      				<option disabled="disabled">--------------------------------------------</option>
	      				<?php
	      				$cnt = 0;
	      				while ($dr = pg_fetch_array($ds)) {
	      					?>
	      					<option id="<?php echo $dr["pinpointid"]?>" value="<?php echo $cnt?>"><?php echo $dr["pinpoint"]?></option>
	      					<?php
	      					$cnt ++;
	      				}
	      				?>
		     		</select>
		     		<span class="text5" style="float: right; position: relative; top: 7px; visibility: visible; right: 11px;">
		     			<strong>Точка од интерес:</strong>
		     		</span>
    			</td>
    		</tr>
 </table>-->
				<?php
				$ds = query($sql1_);
				?>
	<div style="margin-top:10px">&nbsp;&nbsp;</div>
				
<table id="tab-<?php echo $rV["id"]?>" width="100%" border="0" cellspacing="0" cellpadding="0">
	
    <?php
        $cntTest = 0;
		
		if ($cntDs > 0) {
			while ($dr_ = pg_fetch_array($ds)) {  
	            $_sql = "";
	            //$_sql .= "select pinpoint, pinpointID, startTime, EndTime, geonet.dbo.fn_time_goran(duration) duration  ";
	            $_sql .= "select pinpoint, pinpointID, startTime, EndTime, sec2time(cast(duration as integer)) duration  ";
	            $_sql .= "from rpointsofinterest ";
	            $_sql .= " " . $where . " AND pinpointID=" . $dr_["pinpointid"];
			   	
				
	            $ds3 = query($_sql);
	            
	            $cntTest = pg_num_rows($ds3);
	        } // end while
		}//end if
		     
       If ($cntTest > 0) {
        	$langArr = explode("?", getQUERY("l"));
			$cLang = $langArr[0];
     ?>

    <tr>
		<td width="50%" valign="top">
			<div style="display:block; margin-left:30px;background-color:#f0f0f0; width:90%; height:25px; padding-top:5px; text-align:left " class="textSubTitle corner15">&nbsp;&nbsp;&nbsp;<?php dic("Reports.VisitedPOIByNumber")?></div><br>
			<div  id="containerChart1-<?php echo $rV["id"]?>" style="width: 100%; background-color:#fafafa; height:300px; margin: 0 auto"></div><br /><br /><br />
		</td>
		<td width="50%" valign="top">
			<div style="display:block; margin-left:30px;background-color:#f0f0f0; width:90%; height:25px; padding-top:5px; text-align:left " class="textSubTitle corner15">&nbsp;&nbsp;&nbsp;<?php dic("Reports.VisitedPOIByDuration")?></div><br>
			<div  id="containerChart2-<?php echo $rV["id"]?>" style="width: 100%; background-color:#fafafa; height:300px; margin: 0 auto"></div><br />		
		</td>
	</tr>
    <?php
	   } Else {
        $ifNot += 1;
     ?>
          <div id="noData" style="padding-left:40px; font-size:30px; font-style:italic; padding-bottom:40px" class="text4">
                  <?php dic("Reports.NoData")?>
          </div>
          
          <script>
          		//document.getElementById('poiAll').style.visibility = "hidden";
          </script>
</table>
    <?php
    	}//end if
    	 If ($cntTest > 0) {
     ?>
    
     <div id="noData-<?php echo $rV["id"]?>" style="font-size:30px; padding-bottom:25px; font-style:italic; padding-left:40px; display: none" class="text4">
          <?php echo dic_("Reports.ThePOI")?> <strong><span id="spanpoi-<?php echo $rV["id"]?>"></span></strong> <?php echo dic_("Reports.POInotvisit")?> !!!
    </div>
     		<table width=62%  id="poi-<?php echo $rV["id"]?>"  style=" margin: 0 auto 50px;">
     			
     	
			<tr class="columns-<?php echo $rV["id"]?>">
				<td width=60%  height="35px" align="left" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left: 10px; font-size:13px;"><strong><?php echo dic_("Reports.NamePoi")?></strong></th>
				<td width=20% id="duration-<?php echo $rV["id"]?>" onclick="changeBack('duration', '<?php echo $rV["id"]?>'); SortTable('poi-<?php echo $rV["id"]?>',1, 'DESC')" width=17% height="22px" align="center" class="text2 backupdown" style="font-size:13px;background-color:#E5E3E3; border:1px dotted #2f5185; cursor:pointer;"><strong><?php echo dic_("Reports.PominatoVreme")?></strong></th>
				<td width=20% id="visits-<?php echo $rV["id"]?>" onclick="changeBack('visits', '<?php echo $rV["id"]?>'); SortTable('poi-<?php echo $rV["id"]?>',2, 'DESC')" width=17% height="22px" align="center" class="text2 backupdown" style="font-size:13px;background-color:#E5E3E3; border:1px dotted #2f5185; cursor:pointer;  "><strong><?php echo dic_("Reports.NoVisit")?></strong></th>
				<td id="" height="22px" align="center" class="text2" style="" ></td>
     			<td id="" height="22px" align="center" class="text2" style="" ></td>	
				
			</tr>
		
		

			<?php
     			$ds = query($sql1_);	
				$cnt = 0;
				while ($dr = pg_fetch_array($ds)) {
					  $tmpIDA = explode(",", $idPoi);
					  $ifNE = true;
					  for($ch=0; $ch < sizeof($tmpIDA); $ch++)
					  	if($dr["pinpointid"] == $tmpIDA[$ch])
						{
							$ifNE = false;
							break;
						}
					  if($ifNE) {
						$idPoi .= $dr["pinpointid"] . ",";
						$idPoiNames .= $dr["pinpoint"] . ",";
					  }
					  if ($dr["type"] == 1) {
							$img = "../images/poi-b.png";
					  } else {
							$img = "../images/poi-a.png";
					  } 
				?>
				<tr class="<?php echo $rV["id"]?>-<?php echo $dr["pinpointid"]?>" value="<?php echo $cnt?>">
					
     				<td colspan=3 height="22px" align="left" class="text2"  style=" background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px; color:#2f5185; font-weight:bold; cursor:pointer; padding-top:7px; padding-bottom:7px " >
     						<table id="pomtab" width=100% class="text2">
     							<tr onclick="showHide('<?php echo $rV["id"]?>','<?php echo $cnt?>')">
     								<td width=60%>
     									<strong><div  id="div-<?php echo $rV["id"]?>-<?php echo $cnt?>" style="float: left; position: relative;">▶</div>
			     						<div id="div_-<?php echo $rV["id"]?>-<?php echo $cnt?>" style="font-size:12px">&nbsp;&nbsp;&nbsp;<img width="19px" height="19px" src="<?php echo $img?>">&nbsp;<span style="position: relative; top:-4px"><?php echo nnull($dr["pinpoint"])?></span></div>
			     						<div id ="pan-<?php echo $rV["id"]?>-<?php echo $cnt?>" style="display:none"></div></strong>
			     					</td>
			     					<td width=20% id="td1-<?php echo $rV["id"]?>-<?php echo $cnt?>" height="22px" align="center" class="text2" style="background-color:#fff; vertical-align: top; padding-top: 7px" value="<?php echo $dr["durval"] ?>"><?php echo Time2Str($dr["duration"]) ?></td>
			     					<td width=20% id="td2-<?php echo $rV["id"]?>-<?php echo $cnt?>" height="22px" align="center" class="text2" style="background-color:#fff; vertical-align: top; padding-top: 7px" value="<?php echo $dr["cnt"]?>"><?php echo $dr["cnt"]?> <?php dic("Reports.Visits")?></td>	
			     					
     							</tr>
     							<tr id="tr-<?php echo $rV["id"]?>-<?php echo $cnt?>" style="display:none" >
						     		<td colspan=3 >
						     			<table width="91%" id="tab-<?php echo $rV["id"]?>-<?php echo $cnt?>" style="margin-top:7px; margin-left:25px; margin-bottom:7px; color:#2F5185; font-weight: normal; " class="text2">
				     						
				     						<tr>
				     							<td align=center height=22px width="23%" style=" background-color: #EDEBEB; border:1px dotted #CCCCCC; color:#2F5185; font-weight: bold"><?php echo dic_("Reports.From")?></td>
				     							<td align=center height=22px width="23%" style=" background-color: #EDEBEB; border:1px dotted #CCCCCC; color:#2F5185; font-weight: bold"><?php echo dic_("Reports.To")?></td>
				     							<td align=center height=22px width="19%" style=" background-color: #EDEBEB; border:1px dotted #CCCCCC; color:#2F5185; font-weight: bold">&nbsp;&nbsp;&nbsp;&nbsp;<?php echo dic_("Reports.PominatoVreme")?>&nbsp;&nbsp;&nbsp;&nbsp;</td>
				     							<?php
												if ($ifDriver > 0) {
												?>
												<td align=center height=22px width="23%" style=" background-color: #EDEBEB; border:1px dotted #CCCCCC; color:#2F5185; font-weight: bold"><?php echo dic_("Reports.Driver")?></td>
												<?php
												}
												//$type = dlookup("select type from pointsofinterest where id=" . $dr["pinpointid"]);
												//if ($type == 1) {
												?>
				     							<td align=center height=22px width="12%" style=" background-color: #EDEBEB; border:1px dotted #CCCCCC; color:#2F5185; font-weight: bold">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				     						<?php
												///}
				     						?>
				     						</tr>
				     						
				     					<?php	
								
										$_sqlN = "";
										$_sqlN .= "select pinpoint, pinpointID, startTime, EndTime, sec2time(cast(duration as integer)) duration, type  ";
										$_sqlN .= "from rpointsofinterest ";
										$_sqlN .= " " . $where . " AND pinpointID=" . $dr["pinpointid"] . " and pinpoint = '" . $dr["pinpoint"] . "'";
								       	
								        $dsN = query($_sqlN);
										while ($drN = pg_fetch_array($dsN)) {
											if ($drN["type"] == 1) {
												$lat = dlookup("select st_y(st_transform(poi.geom, 4326)) lat from rpointsofinterest rpoi
												left join pointsofinterest poi on rpoi.pinpointid=poi.id  where rpoi.pinpointid=" . $drN["pinpointid"] . " limit 1");
												$lon = dlookup("select st_x(st_transform(poi.geom, 4326)) lon from rpointsofinterest rpoi
												left join pointsofinterest poi on rpoi.pinpointid=poi.id  where rpoi.pinpointid=" . $drN["pinpointid"] . " limit 1");
											}
											?>
											<tr>
						     					<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo DateTimeFormat($drN["starttime"],"d") . " " . dic_("Reports." . $meseci[intval(DateTimeFormat($drN["starttime"], "m")) - 1] . "")?>, <?php echo strtoupper(DateTimeFormat($drN["starttime"], $timeformat))?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						     					<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo DateTimeFormat($drN["endtime"],"d") . " " . dic_("Reports." . $meseci[intval(DateTimeFormat($drN["endtime"], "m")) - 1] . "")?>, <?php echo strtoupper(DateTimeFormat($drN["endtime"], $timeformat))?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
						     					<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">&nbsp;&nbsp;&nbsp;<?php echo Time2Str($drN["duration"])?>&nbsp;&nbsp;&nbsp;</td>
						     					<?php
												if ($ifDriver > 0) {
													$driver = str_replace("<br>", " ", dlookup("select getdrivernew1('" . $drN["starttime"] . "', '" . $drN["endtime"] . "', " . $rV["id"] . ")"));
												?>
												<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">&nbsp;&nbsp;&nbsp;<?php echo nnull($driver, "/")?>&nbsp;&nbsp;&nbsp;</td>
												<?php
												}
												if ($drN["type"] == 1) {
												?>
						     					<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">
						     						<img width="24" height="24" border="0" src="../images/zoom.png" style="cursor:pointer" title="<?php echo dic_("Reports.ViewOnMap")?>" onclick="OpenMap(<?php echo $lat ?>, <?php echo $lon ?>, '<?php echo $rV["registration"]?>', '<?php echo DateTimeFormat($drN["starttime"],"d-m-Y")?>', '<?php echo DateTimeFormat($drN["starttime"],"H:i:s")?>', 0)">
						     					</td>
						     					<?php
												} else {
													?>
												<td height=22px align=center style="background-color: #FCFCFC; border:1px dotted #DEDEDE; color:#2F5185">
						     						<img width="24" height="24" border="0" src="../images/zoom.png" style="cursor:pointer" title="<?php echo dic_("Reports.ViewOnMap")?>" onclick="OpenMapZone(<?php echo $drN["pinpointid"] ?>)">
						     					</td>	
													<?php
												}
													?>
						     	</tr>	
						     	
						     					<?php
										}?>
										</table>
						     		</td>
						     </tr>
     						</table>
     					</td>
     					
     					
     					<td id="" height="22px" align="center" class="text2" style="" value="<?php echo $dr["durval"] ?>"></td>
     					<td id="" height="22px" align="center" class="text2" style="" value="<?php echo $dr["cnt"]?>"></td>	
     				
     				
     			</tr>
     		     	
		     		
				<?php	
				
				$_sqlN = "";
				$_sqlN .= "select pinpoint, pinpointID, startTime, EndTime, sec2time(cast(duration as integer)) duration  ";
				$_sqlN .= "from rpointsofinterest ";
				$_sqlN .= " " . $where . " AND pinpointID=" . $dr["pinpointid"] . " and pinpoint = '" . $dr["pinpoint"] . "'";
		       	
		        $dsN = query($_sqlN);
				while ($drN = pg_fetch_array($dsN)) {
					?>
					
					<?php
				}
				$cnt = $cnt + 1;
				}     			
     			?> 
			
		
		
     		</table>

  <?php
				}
  ?>
	

</div>
<br />
<script type="text/javascript">
	//za hide na otvoren kalendar i hide na div za izbor na vozilo
		$(document).click(function(e) { 
			top.document.getElementById('vehdiv').style.display='none';
			if (top.document.getElementById('doneBtn'))
				top.document.getElementById('doneBtn').click();
		});

function Sec2Str(sec){
	var h = parseInt(sec/3600)
	sec = sec % 3600
	var m = parseInt(sec/60)
	sec = sec % 60
	var r = ''
	if (h>0){
		r = h + " h " + m + " min "
	} else {
		if (m>0) {
			 r = m + " min "
		} else {
			r = sec + "sec"
		}
	}
	return r
}
</script>
<?php
//**** Naj posetuvani markeri po broj na poseti
	
	$_sql1 = "";
	$_sql1 .= "select pinpoint, pinpointID, count(*) cnt, sum(duration) duration ";
	$_sql1 .= "from rpointsofinterest ";
	$_sql1 .= " " . $where . " ";
	$_sql1 .= "group by pinpoint, pinpointID ";
	$_sql1 .= "order by 3 desc limit 5";
	
	$ds2 = query($_sql1);
		
    $langArr = explode("?", getQUERY("l"));
	$cLang = $langArr[0];
    
	if (empty($ds2)) {
   		ob_clean();
        echo "<br><br>&nbsp;&nbsp;&nbsp;<span style='position:absolute; left:30%; top:40%; font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; color:#2f5185;'>" . dic_("Reports.ReportNotLoaded") . "</span>";
		?><script>top.HideWait()</script><?php
        exit();
	}	
			                               		                                 
	$sum = 0;
	while ($dr = pg_fetch_array($ds2)) {
		$sum = $sum + $dr["cnt"];
	}
		
             echo "<script type='text/javascript'>";
             echo "var chartPie1;";
             echo "function createChart1(){";
             echo "	chart = new Highcharts.Chart({";
             echo "		chart: {";
             echo "			renderTo: 'containerChart1-" . $rV["id"] . "',";
             echo "			plotBackgroundColor: null,";
             echo "			backgroundColor: '#fafafa',";
             echo "			plotBorderWidth: null,";
             echo "			plotShadow: false";
             echo "		},";
             echo "		title: {";
             echo "			text: ' '";
             echo "		},";
             echo "		subtitle: {";
             echo "			text: ' '";
             echo "		},";

             echo "		tooltip: {";
             echo "			formatter: function() {";
             echo "				return '<b>'+ this.point.name +'</b>: '+ Math.round((this.y*" . (float)$sum . ")/100) +' " . dic_("Reports.Visits") . "';";
             echo "			}";
             echo "		},";
             echo "		plotOptions: {";
             echo "			pie: {";
             echo "				allowPointSelect: true,";
             echo "				cursor: 'pointer',";
             echo "				dataLabels: {";
             echo "					enabled: true,";
             echo "					color: '#000000',";
             echo "					connectorColor: '#000000',";
             echo "					formatter: function() {";
             echo "						return '<b>'+ this.point.name +'</b>: '+ Math.round((this.y*" . (float)$sum . ")/100) +' " . dic_("Reports.Visits") . "';";
             echo "					}";
             echo "				}";
             echo "			}";
             echo "		},";
             echo "		series: [{";
             echo "			type: 'pie',";
             echo "			name: 'Browser share',";
             echo "			data: [";
			 
             $j = 0;
             For ($j = 0; $j <= pg_num_rows($ds2) - 1; $j++) {
                 $prec = ((float)pg_fetch_result($ds2, $j, "cnt") / (float)$sum) * 100;
                 $tekst = trim(pg_fetch_result($ds2, $j, "pinpoint"));
                		                                     
                 //if len(tekst)>20 then tekst = mid(tekst,1,20) & "..."
                 If ($j == 0) {
                     echo "				{name:'" . $tekst . "',  y: " . number_format($prec) . ", sliced: true, selected: true}";
                 } Else {
                     echo "				['" . $tekst . "',   " . number_format($prec) . "]";
                 }
                 
                 If ($j < pg_num_rows($ds2) - 1) echo ",";

             } //end for
             echo "			]";
             echo "		}]";
             echo "	});";
             echo "};";
             echo "</script>";
	
		            
     //**** Naj posetuvani markeri po vreme

     $_sql1 = "";
     $_sql1 .= "select pinpoint, pinpointid, count(*) cnt, sum(duration) duration ";
     $_sql1 .= "from rpointsofinterest ";
     $_sql1 .= " " . $where . " ";
     $_sql1 .= "group by pinpoint, pinpointid ";
     $_sql1 .= "order by 4 desc limit 5";
 
     $ds2 = query($_sql1);
	 
     $langArr = explode("?", getQUERY("l"));
	 $cLang = $langArr[0];
		
	 if (empty($ds2)) {
   		ob_clean();
        echo "<br><br>&nbsp;&nbsp;&nbsp;<span style='position:absolute; left:30%; top:40%; font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; color:#2f5185;'>" . dic_("Reports.ReportNotLoaded") . "</span>";
		?><script>top.HideWait()</script><?php
        exit();
	 }	
			                                 
	$sum = 0;
	
	while ($dr = pg_fetch_array($ds2)) {
		$sum = $sum + $dr["duration"];
	}
	   
	 
    If ($cntTest > 0) {
  
             echo "<script type='text/javascript'>";
             echo "var chartPie1;";
             echo " function createChart(){";
             echo "	chart = new Highcharts.Chart({";
             echo "		chart: {";
             echo "			renderTo: 'containerChart2-" . $rV["id"] . "',";
             echo "			plotBackgroundColor: null,";
             echo "			backgroundColor: '#fafafa',";
             echo "			plotBorderWidth: null,";
             echo "			plotShadow: false";
             echo "		},";
             echo "		title: {";
             echo "			text: ' '";
             echo "		},";
             echo "		subtitle: {" ;
             echo "			text: ' '";
             echo "		},";

             echo "		tooltip: {";
             echo "			formatter: function() {";
             echo "				return '<b>'+ this.point.name +'</b>: '+ Sec2Str((this.y*" . (float)$sum . ")/100);";
             echo "			}";
             echo "		},";
             echo "		plotOptions: {";
             echo "			pie: {";
             echo "				allowPointSelect: true,";
             echo "				cursor: 'pointer',";
             echo "				dataLabels: {";
             echo "					enabled: true,";
             echo "					color: '#000000',";
             echo "					connectorColor: '#000000',";
             echo "					formatter: function() {";
             echo "						return '<b>'+ this.point.name +'</b>: '+ Sec2Str((this.y*" . (float)$sum . ")/100);";
             echo "					}";
             echo "				}";
             echo "			}";
             echo "		},";
             echo "		series: [{";
             echo "			type: 'pie',";
             echo "			name: 'Browser share',";
             echo "			data: [";
			 
             $j = 0;
             For ($j = 0; $j <= pg_num_rows($ds2) - 1; $j++) {
                 
				 $prec = round((intval(pg_fetch_result($ds2, $j, "duration")) / intval($sum)) * 100);
				
                 $tekst = trim(pg_fetch_result($ds2, $j, "pinpoint"));
                 //if len(tekst)>20 then tekst = mid(tekst,1,20) & "..."
                 
                 If ($j == 0) {
                     echo "				{name:'" . $tekst . "',  y: " . number_format($prec) . ", sliced: true, selected: true}";
                 } Else {
                     echo "				['" . $tekst . "',   " . number_format($prec) . "]";
                 }
				 
                 If ($j < pg_num_rows($ds2) - 1) echo ",";

             } //end for
             
             echo "			]";
             echo "		}]";
             echo "	});";
             echo "};";
             echo "</script>";
      
      $langArr = explode("?", getQUERY("l"));
	  $cLang = $langArr[0];
	                                 
?>

<script>
    createChart1();
    createChart();
     $(document).ready(function() { 
    	      	
    }); 
</script>
<?php
     } //end if
    } //end while 
closedb();
?>
        <div id="footer-rights-new" class="textFooter" style="padding:10px 10px 10px 10px">
		<?php echo $CopyrightString?>&nbsp;|&nbsp;<?php echo session("company")?>&nbsp;|&nbsp;<?php echo session("user_fullname")?>&nbsp;|&nbsp;<?php echo $CreationDate ?>&nbsp;|&nbsp;From: <?php echo $sd?>&nbsp;-&nbsp;To: <?php echo $ed?>
	</div>
    </div>
</body>
</html>
<script type="text/javascript">

	 /*var config = {
      '.chzn-select'           : {},
      '.chzn-select-deselect'  : {allow_single_deselect:true},
      '.chzn-select-no-single' : {disable_search_threshold:10},
      '.chzn-select-no-results': {no_results_text:'Oops, nothing found!'},
      '.chzn-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }*/
   
   var config = {
      '.chzn-select'           : {},
      '.chzn-select-deselect'  : {allow_single_deselect:true},
      '.chzn-select-no-single' : {disable_search_threshold:10},
      '.chzn-select-no-results': {no_results_text:'<?php echo dic_("Reports.POINotFound")?>'},
      '.chzn-select-width'     : {width:"95%"}
    }
    for (var selector in config) {
      $(selector).chosen(config[selector]);
    }
    
    
	var allone = 0;
		    
	//za hide na otvoren kalendar i div za izbor na vehicle
	$(document).click(function(e) { 
		top.document.getElementById('vehdiv').style.display='none';
		if (top.document.getElementById('doneBtn'))
			top.document.getElementById('doneBtn').click();
	});

	if (<?php echo $ifNot ?> == <?php echo pg_num_rows($dsVehicles) ?>) {
	    document.getElementById('icons').innerHTML = "<div style='float:right'><span id='iconSCH'><img src='../images/sch.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span> </div><div style='float:right'><span id='iconEMAIL' ><img src='../images/eEmail.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span></div><div style='float:right;'><span id='iconPDF' ><img src='../images/epdf.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span></div><div style='float:right;'><a style='text-decoration:none'><span id='iconCSV' ><img src='../images/eExcel.png' width='16' height='16' align='absmiddle' style='border:0; opacity:0.6'>&nbsp;</span></a></div>"
	}
var tip = "desc"	
function SortTable(_tableName, _col, _tip){
		if (allone == 1) {
			return false;
		}
		
			if (tip == "desc") {
				tip = "asc";
			} else {
				tip = "desc";
			}
		
		var rows = $('#'+_tableName).find("> tbody > tr")
		for (var j=1; j<rows.length;j++){
			for (var i=1; i<rows.length-1;i++){	
				
				var td1 = $(rows[i])[0].cells
				var td2 = $(rows[i+1])[0].cells
				var cntCol = $(rows[i+1])[0].cells.length;
				
				if (_col == 1) {
					var val1 =$(td1[_col]).attr("value")
					var val2 =$(td2[_col]).attr("value")
					var val11 =$(td1[_col+1]).attr("value")
					var val22 =$(td2[_col+1]).attr("value")
				} else {
					var val1 =$(td1[_col]).attr("value")
					var val2 =$(td2[_col]).attr("value")
					var val11 =$(td1[_col-1]).attr("value")
					var val22 =$(td2[_col-1]).attr("value")
				}

				if (tip=='asc') {
					if (parseInt(val1)>parseInt(val2)) {
						var tmp
						for (var k=0; k<td1.length; k++){					
							tmp = td1[k].innerHTML
							td1[k].innerHTML = td2[k].innerHTML
							td2[k].innerHTML = tmp
							
							if (_col == 1) {
								td1[_col].setAttribute("value", val2)	 
								td2[_col].setAttribute("value", val1)
								td1[_col+1].setAttribute("value", val22)	 
								td2[_col+1].setAttribute("value", val11)
							} else{
								td1[_col].setAttribute("value", val2)	 
								td2[_col].setAttribute("value", val1)
								td1[_col-1].setAttribute("value", val22)	 
								td2[_col-1].setAttribute("value", val11)
							}	
						}	
					}	
				} else {
					if (parseInt(val1)<parseInt(val2)) {
						var tmp
						for (var k=0; k<td1.length; k++){					
							tmp = td1[k].innerHTML
							td1[k].innerHTML = td2[k].innerHTML
							td2[k].innerHTML = tmp
								 
								if (_col == 1) {
									td1[_col].setAttribute("value", val2)	 
									td2[_col].setAttribute("value", val1)
									td1[_col+1].setAttribute("value", val22)	 
									td2[_col+1].setAttribute("value", val11)
								} else{
									td1[_col].setAttribute("value", val2)	 
									td2[_col].setAttribute("value", val1)
									td1[_col-1].setAttribute("value", val22)	 
									td2[_col-1].setAttribute("value", val11)
								}
						}	
					}
				}				
			}
		}
	}
//document.getElementById('poi').selectedIndex = <php echo $poi?>;
function changeBack(str, vehid) {
	//alert(tip)
	if (allone == 1) {
		return false;
	}
	$('#duration-' + vehid).addClass('backupdown');
	$('#visits-' + vehid).addClass('backupdown');
	
	if (str == "duration") {
		if (tip == "asc") {
			$('#duration-' + vehid).removeClass('headerSortUp');
			$('#duration-' + vehid).addClass('headerSortDown');
		} else {
			$('#duration-' + vehid).removeClass('headerSortDown');
			$('#duration-' + vehid).addClass('headerSortUp');
		}
		$('#duration-' + vehid).removeClass('backupdown');
	} else {
		if (tip == "asc") {
			$('#visits-' + vehid).removeClass('headerSortUp');
			$('#visits-' + vehid).addClass('headerSortDown');
		} else {
			$('#visits-' + vehid).removeClass('headerSortDown');
			$('#visits-' + vehid).addClass('headerSortUp');
		}
		$('#visits-' + vehid).removeClass('backupdown');
	}
}

//document.getElementById('poi').selectedIndex = <php echo $poi?>;
function changeIcon(id) {
	/*alert(id)
	document.getElementById(id).style.backgroundImage = "../images/up1.png";*/
}

function showHide(veh, id) {
	if (document.getElementById('tr-' + veh + '-' + id).style.display == "none") {
		document.getElementById('tr-' + veh + '-' + id).style.display = "table-row";
		document.getElementById("div-" + veh + "-" + id).innerHTML = "▼"
		document.getElementById("td1-" + veh + "-" + id).style.fontWeight = "bold";
		document.getElementById("td2-" + veh + "-" + id).style.fontWeight = "bold";
		document.getElementById("td1-" + veh + "-" + id).style.color = "blue";
		document.getElementById("td2-" + veh + "-" + id).style.color = "blue";
		document.getElementById("div-" + veh + "-" + id).style.color = "blue";
		document.getElementById("div_-" + veh + "-" + id).style.color = "blue";
	} else {
		document.getElementById('tr-' + veh + '-' + id).style.display = "none";
		document.getElementById("div-" + veh + "-" + id).innerHTML = "▶"
		document.getElementById("td1-" + veh + "-" + id).style.fontWeight = "normal";
		document.getElementById("td2-" + veh + "-" + id).style.fontWeight = "normal";
		document.getElementById("td1-" + veh + "-" + id).style.color = "#2F5185";
		document.getElementById("td2-" + veh + "-" + id).style.color = "#2F5185";
		document.getElementById("div-" + veh + "-" + id).style.color = "#2F5185";
		document.getElementById("div_-" + veh + "-" + id).style.color = "#2F5185";
	}		
	//debugger;
	//display: table-cell;
	/*var parentDisplay = ($('#tab-' + veh + '-' + id).parent())[0].attributes[1];

	if (parentDisplay.nodeValue == "display: none;") {
			document.getElementById("div-" + veh + "-" + id).innerHTML = "▼"
			//document.getElementById("div-" + veh + "-" + id).style.position = "bottom"
			document.getElementById("td1-" + veh + "-" + id).style.fontWeight = "bold";
			document.getElementById("td2-" + veh + "-" + id).style.fontWeight = "bold";
			document.getElementById("td1-" + veh + "-" + id).style.color = "blue";
			document.getElementById("td2-" + veh + "-" + id).style.color = "blue";
			document.getElementById("div-" + veh + "-" + id).style.color = "blue";
			document.getElementById("div_-" + veh + "-" + id).style.color = "blue";
	} else {
			document.getElementById("div-" + veh + "-" + id).innerHTML = "▶"
			//document.getElementById("div-" + veh + "-" + id).style.position = "relative"
			document.getElementById("td1-" + veh + "-" + id).style.fontWeight = "normal";
			document.getElementById("td2-" + veh + "-" + id).style.fontWeight = "normal";
			document.getElementById("td1-" + veh + "-" + id).style.color = "#2F5185";
			document.getElementById("td2-" + veh + "-" + id).style.color = "#2F5185";
			document.getElementById("div-" + veh + "-" + id).style.color = "#2F5185";
			document.getElementById("div_-" + veh + "-" + id).style.color = "#2F5185";
	}*/
}

function closedialog()
{
	$('#dialog-map').dialog('destroy');
}

 function getWidthHeight() {
        var h_ = document.getElementById('footer-rights-new').offsetTop
        return h_;
 }
 
if (<?php echo $ifNot ?> == <?php echo pg_num_rows($dsVh)?>) {
    document.getElementById('icons').innerHTML = "<div style='float:right'><span id='iconSCH'><img src='../images/sch.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span> </div><div style='float:right'><span id='iconEMAIL' ><img src='../images/eEmail.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span></div><div style='float:right;'><span id='iconPDF' ><img src='../images/epdf.png' width='16' height='16' align='absmiddle' style='opacity:0.6'>&nbsp;</span></div><div style='float:right;'><a style='text-decoration:none'><span id='iconCSV' ><img src='../images/eExcel.png' width='16' height='16' align='absmiddle' style='border:0; opacity:0.6'>&nbsp;</span></a></div>"
	//document.getElementById('poiAll').style.visibility = "hidden";
}

    function showForm() {
        var divForm = document.getElementById('div-form')
        if (divForm == null) { divForm = Create(document.body, 'div', 'div-form') }
        $(divForm).show()
        //var _l = e.pageX + 10 //document.getElementById(elID).offsetLeft
        //var _t = e.pageY + 25 //document.getElementById(elID).offsetTop
        //var _l = 150
        var _t = 35

        divForm.className = 'text2 corner5 shadow1'
        $(divForm).css({ width: '30%', height: '60%', position: 'absolute', zIndex: '999999', left: '35%', top: '14%', display: 'block', border: '1px solid #bbbbbb', backgroundColor: '#d9d9d9', padding: '4px 4px 4px 4px', color: '#2f5185' })

        divForm.innerHTML = "<div style='text-align:center; font-weight:bold; position:absolute; top:44%; left:37%'><img src='../images/loading.gif' border='0' align='absmiddle' width='14' height='14' />&nbsp;L O A D I N G..</div>";

        //divForm.innerHTML = "<table><tr><td align=center style='font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#2f5185; text-decoration: none; font-weight:bold;'>SCHEDULER</td></tr><tr><td style='font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#2f5185; text-decoration: none; font-weight:bold;'>Vehicles</td><td style='font-family:Arial, Helvetica, sans-serif; font-size:12px; font-weight:normal; color:#2f5185; text-decoration: none; font-weight:bold;'>Period</td></tr></table>"
        $("#div-form").load('scheduler.aspx')
        if (divForm.offsetLeft + divForm.offsetWidth > document.body.clientWidth) { divForm.style.left = (document.body.clientWidth - divForm.offsetWidth - 10) + 'px' }
    }

    function showEmailForm() {
        var divEmailForm = document.getElementById('div-Emailform')
        if (divEmailForm == null) { divEmailForm = Create(document.body, 'div', 'div-Emailform') }
        $(divEmailForm).show()

        var _t = 35

        divEmailForm.className = 'text2 corner5 shadow1'
        $(divEmailForm).css({ width: '30%', height: '32%', position: 'absolute', zIndex: '999999', left: '35%', top: '26%', display: 'block', border: '1px solid #bbbbbb', backgroundColor: '#d9d9d9', padding: '4px 4px 4px 4px', color: '#2f5185' })

        divEmailForm.innerHTML = "<div style='text-align:center; font-weight:bold; position:absolute; top:44%; left:37%'><img src='../images/loading.gif' border='0' align='absmiddle' width='14' height='14' />&nbsp;L O A D I N G..</div>";

        var x = "";
        x = document.location.href;
        var index = x.indexOf("&");
        while (index != -1) {
            x = x.replace("&", "*");
            index = x.indexOf("&");
        }

        $("#div-Emailform").load('email.aspx?report="Visited%20points%20of%20interest"&_link="' + x + '"')

        //$("#div-Emailform").load('email.aspx?report="Visited%20points%20of%20interest"')
        if (divEmailForm.offsetLeft + divEmailForm.offsetWidth > document.body.clientWidth) { divEmailForm.style.left = (document.body.clientWidth - divEmailForm.offsetWidth - 10) + 'px' }

    }  

	function OptionsChangeVeh(vehid){
		var _id = $("#poi-" + vehid).find('option:selected').attr("id");
		var val = $("#poi-" + vehid).find('option:selected').val();
		
		//$(".218099").hide();
		//alert(idPoi)
		if(_id == "0") {
			$("." + vehid + "-columns").show();		
			for(var i = 0; i < idPoi.split(",").length-1;i++)
				$("." + idPoi.split(",")[i]).show();
		} else {
			
			//alert('tr-' + vehid + '-' + val)
			document.getElementById('tr-' + vehid + '-' + val).style.display = "table-row";
			//document.getElementById('tr-' + vehid + '-' + val).innerHTML = "▼"
			$("." + vehid + "-columns").hide();		
			
			for(var i=0;i < idPoi.split(",").length-1;i++) {
				if(idPoi.split(",")[i] != _id)
					$("." + vehid + "-" + idPoi.split(",")[i]).hide();
				else {
					$("." + vehid + "-" + idPoi.split(",")[i]).show();
					//ifAny += vehid + ";";
				}
			}
			
		}
	}

	function OptionsChangeAll(){
		selpoi = $('#poi_').find('option:selected').attr("id");
		var _id = $("#poi_").find('option:selected').attr("id");
		var val = $("#poi_").find('option:selected').val();
		var poiIdx = -1;
				
		for(var j=0;j < idVeh.split(";").length-1;j++) {
			//$("#div-" + idVeh.split(";")[j]).show();
			$("#tab-" + idVeh.split(";")[j]).show();
			$("#noData-" + idVeh.split(";")[j]).hide();
			$("#poi-" + idVeh.split(";")[j]).show();
					
			$('#duration-' + (idVeh.split(";")[j])).attr('class', 'text2 backupdown');
			$('#duration-' + (idVeh.split(";")[j])).css('cursor', 'pointer');
			$('#visits-' + (idVeh.split(";")[j])).attr('class', 'text2 backupdown');
			$('#visits-' + (idVeh.split(";")[j])).css('cursor', 'pointer');
		}
			
		if(_id == "0")
		{
			allone = 0;
			//$("." + vehid + "-columns").show();		
			for(var i = 0; i < idPoi.split(",").length-1;i++)
				for(var j=0;j < idVeh.split(";").length-1;j++) {
						$("." + idVeh.split(";")[j] + "-" + idPoi.split(",")[i]).show();
						var v = $('.' + idVeh.split(";")[j] + '-' + idPoi.split(",")[i]).attr("value");
						if (document.getElementById('tr-' + idVeh.split(";")[j] + '-' + v)) {
							//alert('tr-' + idVeh.split(";")[j] + '-' + v)
							document.getElementById('tr-' + (idVeh.split(";")[j]) + '-' + v).style.display="none";
							document.getElementById("div-" + (idVeh.split(";")[j]) + '-' + v).innerHTML = "▶"
							document.getElementById("td1-" + (idVeh.split(";")[j]) + '-' + v).style.fontWeight = "normal";
							document.getElementById("td2-" + (idVeh.split(";")[j]) + '-' + v).style.fontWeight = "normal";
							document.getElementById("td1-" + (idVeh.split(";")[j]) + '-' + v).style.color = "#2F5185";
							document.getElementById("td2-" + (idVeh.split(";")[j]) + '-' + v).style.color = "#2F5185";
							document.getElementById("div-" + (idVeh.split(";")[j]) + '-' + v).style.color = "#2F5185";
							document.getElementById("div_-" + (idVeh.split(";")[j]) + '-' + v).style.color = "#2F5185";
		
							//showHide(idVeh.split(";")[j], v);
							//debugger;
							//document.getElementById('tr-' + idVeh.split(";")[j] + '-' + v).style.color = "red";
						}
						}
		} else
		{	
			allone = 1;
			
			//alert('tr-' + vehid + '-' + val)
			//document.getElementById('tr-' + vehid + '-' + val).style.display = "table-row";
			//document.getElementById('tr-' + vehid + '-' + val).innerHTML = "▼"
			//$("." + vehid + "-columns").hide();	
			
				
			for(var i=0;i < idPoi.split(",").length-1;i++)
				if(idPoi.split(",")[i] != _id) {
					for(var j=0;j < idVeh.split(";").length-1;j++) {
						$("." + idVeh.split(";")[j] + "-" + idPoi.split(",")[i]).hide();
					}
				}
				else {
					for(var j=0;j < idVeh.split(";").length-1;j++) {
						$("." + idVeh.split(";")[j] + "-" + idPoi.split(",")[i]).show();
						//alert($('.2060-218038').attr("value"))
						var v = $('.' + idVeh.split(";")[j] + '-' + idPoi.split(",")[i]).attr("value");
						//alert($("." + idVeh.split(";")[j] + "-" + idPoi.split(",")[i]).val())
						if (document.getElementById('tr-' + idVeh.split(";")[j] + '-' + v)) {
							//document.getElementById('tr-' + idVeh.split(";")[j] + '-' + v).style.display = "table-row";
							//document.getElementById('div-' + idVeh.split(";")[j] + '-' + v).innerHTML = "▼"
							//showHide(idVeh.split(";")[j], v);
							poiIdx = i;
							document.getElementById('tr-' + (idVeh.split(";")[j]) + '-' + v).style.display = "table-row";
							document.getElementById('div-' + (idVeh.split(";")[j]) + '-' + v).innerHTML = "▼";
							document.getElementById("td1-" + (idVeh.split(";")[j]) + '-' + v).style.fontWeight = "bold";
							document.getElementById("td2-" + (idVeh.split(";")[j]) + '-' + v).style.fontWeight = "bold";
							document.getElementById("td1-" + (idVeh.split(";")[j]) + '-' + v).style.color = "blue";
							document.getElementById("td2-" + (idVeh.split(";")[j]) + '-' + v).style.color = "blue";
							document.getElementById("div-" + (idVeh.split(";")[j]) + '-' + v).style.color = "blue";
							document.getElementById("div_-" + (idVeh.split(";")[j]) + '-' + v).style.color = "blue";
						}
							
					}
				}
				
			for(var j=0;j < idVeh.split(";").length-1;j++) {
				$('#duration-' + (idVeh.split(";")[j])).attr('class', 'text2');
				$('#duration-' + (idVeh.split(";")[j])).css('cursor', 'default');
				$('#visits-' + (idVeh.split(";")[j])).attr('class', 'text2');
				$('#visits-' + (idVeh.split(";")[j])).css('cursor', 'default');
								
				if ($('#poi-' + idVeh.split(";")[j] + ' tr:visible').length <= 1) {
					//$("#div-" + idVeh.split(";")[j]).hide();
					var poiNamesarr = poiNames.split(',');
					$("#spanpoi-" + idVeh.split(";")[j]).html((poiNamesarr[poiIdx].toLowerCase()).charAt(0).toUpperCase() + (poiNamesarr[poiIdx].toLowerCase()).slice(1));
					$("#noData-" + idVeh.split(";")[j]).show();
					$("#tab-" + idVeh.split(";")[j]).hide();
					$("#poi-" + idVeh.split(";")[j]).hide();
					/*$("#poi-" + idVeh.split(";")[j]).html("<tr><td colspan=3>nema podatoci</td></tr>");
					$("#tab-" + idVeh.split(";")[j]).hide();*/
				} else {
					$("#noData-" + idVeh.split(";")[j]).hide();
					$("#tab-" + idVeh.split(";")[j]).show();
					$("#poi-" + idVeh.split(";")[j]).show();
					
					//$("#div-" + idVeh.split(";")[j]).show();
					//alert("#table-" + idVeh.split(";")[j])
					//debugger;
					$("#tab-" + idVeh.split(";")[j]).hide();
				}
			}	
				//$('#poi-2059 tr:visible').length
				//debugger;
		}
	}
	
	var idPoi = '<?php echo $idPoi?>';
	var poiNames = '<?php echo $idPoiNames?>';
	var idVeh = '<?php echo $idVeh?>';
	//alert(poiNames)
SetHeightLite()
iPadSettingsLite()
top.HideLoading()

$(document).ready(function () {
    top.HideWait();
	    selpoi = $('#poi_').find('option:selected').attr("id");
});





if (Browser()=='iPad') {top.iPad_Refresh()}
</script>
