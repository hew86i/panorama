<?php include "include/functions.php" ?>
<?php include "include/db.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php

	opendb();

	

	closedb();
	
?>

