﻿<?php include "./maps/include/functions.php" ?>
<?php include "./maps/include/db.php" ?>
<?php include "./maps/include/params.php" ?>
<?php session_start()?>
<?php
	set_time_limit(0);
	opendb();

	$lat = str_replace("'", "''", NNull($_GET['lat'], ''));
	$lon = str_replace("'", "''", NNull($_GET['lon'], ''));
	
	//echo "select getGeocode(" . $lat . "," . $lon . ") geocode";
	$temp = query("select getGeocode('" . $lat . "','" . $lon . "') geocode");
	
	echo pg_fetch_result($temp, 0, "geocode");
	
  	closedb();  
?>