<?php include "include/functions.php" ?>
<?php include "include/db.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php

	$today = now();
	
	opendb();
	
	$sqlMain = 'select distinct vehicleid, "DateTime" dt, null, di1, status, "Location" loc, speed, \'1\', \'\' from currentposition where ("DateTime" <  \'' . addToDate($today, -2, "days") . '\' 
	or ("DateTime" <  \'' . addToDate($today, -5, "minutes") . '\' and di1=\'1\'))
	and (select active from vehicles where id = vehicleid) = \'1\' 
	and (select active from clients where id = (select clientid from vehicles where id = vehicleid)) = \'1\'
	and vehicleid not in (select vehicleid from admin_vehiclestatus) and vehicleid not in (select vehicleid from admin_vehiclestatus where active=\'0\' union 
	select vehicleid from admin_vehiclestatusdone where active=\'0\') and (select count(*) from admin_vehiclestatus k1 where k1.vehicleid=vehicleid and startdt="DateTime") = 0';
	$dsMain = query($sqlMain);
	while ($drMain = pg_fetch_array($dsMain)) {
		$cntMain = dlookup("select count(*) from admin_vehiclestatus where vehicleid=".$drMain["vehicleid"]." and startdt='".$drMain["dt"]."'");
		if ($cntMain == 0) {
			$sqlInsert = "insert into admin_vehiclestatus (vehicleid, startdt, enddt, ignition, status, location, speed, active, comment)
			values (".$drMain["vehicleid"].", '".$drMain["dt"]."', null, '".$drMain["di1"]."', '".$drMain["status"]."', '".$drMain["loc"]."', ".$drMain["speed"].", '1', '')";
			echo $sqlInsert . "<br>";
			$r = runSQL($sqlInsert);
		}
	}

	/*$dsMain1 = query('insert into admin_vehiclestatus (vehicleid, startdt, enddt, ignition, status, location, speed, active, comment)
	select vehicleid, "DateTime", null, di1, status, "Location", speed, \'1\', \'\' from currentposition where ("DateTime" <  \'' . addToDate($today, -2, "days") . '\' 
	or "DateTime" <  \'' . addToDate($today, -5, "minutes") . '\')
	and (select active from vehicles where id = vehicleid) = \'1\' 
	and (select active from clients where id = (select clientid from vehicles where id = vehicleid)) = \'1\'
	and vehicleid not in (select vehicleid from admin_vehiclestatus) and vehicleid not in (select vehicleid from admin_vehiclestatus where active=\'0\' union 
	select vehicleid from admin_vehiclestatusdone where active=\'0\') and (select count(*) from admin_vehiclestatus k1 where k1.vehicleid=vehicleid and startdt="DateTime") = 0');
	echo 'insert into admin_vehiclestatus (vehicleid, startdt, enddt, ignition, status, location, speed, active, comment)
	select vehicleid, "DateTime", null, di1, status, "Location", speed, \'1\', \'\' from currentposition where ("DateTime" <  \'' . addToDate($today, -2, "days") . '\' 
	or "DateTime" <  \'' . addToDate($today, -5, "minutes") . '\')
	and (select active from vehicles where id = vehicleid) = \'1\' 
	and (select active from clients where id = (select clientid from vehicles where id = vehicleid)) = \'1\'
	and vehicleid not in (select vehicleid from admin_vehiclestatus) and vehicleid not in (select vehicleid from admin_vehiclestatus where active=\'0\' union 
	select vehicleid from admin_vehiclestatusdone where active=\'0\') and (select count(*) from admin_vehiclestatus k1 where k1.vehicleid=vehicleid and startdt="DateTime") = 0';
echo "<br>";*/
	/*$dsMain2 = query('insert into admin_vehiclestatus (vehicleid, startdt, enddt, ignition, status, location, speed, active, comment)
	select vehicleid, "DateTime", null, di1, status, "Location", speed, \'1\', \'\' from currentposition where "DateTime" <  \'' . addToDate($today, -5, "minutes") . '\' and 		di1=\'1\' 
	and (select active from vehicles where id = vehicleid) = \'1\' 
	and (select active from clients where id = (select clientid from vehicles where id = vehicleid)) = \'1\'
	and vehicleid not in (select vehicleid from admin_vehiclestatus) and vehicleid not in (select vehicleid from admin_vehiclestatus where active=\'0\' union 
	select vehicleid from admin_vehiclestatusdone where active=\'0\') and (select count(*) from admin_vehiclestatus k1 where k1.vehicleid=vehicleid and startdt="DateTime") = 0');*/
	
	$dsUpdateTemp = query('select * from(select dtcurrpos, (select startdt from admin_vehiclestatus where vehicleid = vid) dtadmin, vid from (
	select "DateTime" dtcurrpos, vehicleid vid from currentposition where vehicleid in (
	select vehicleid from admin_vehiclestatus where enddt is null)) s) s1 where s1.dtcurrpos <> s1.dtadmin');
	echo 'select * from(select dtcurrpos, (select startdt from admin_vehiclestatus where vehicleid = vid) dtadmin, vid from (
	select "DateTime" dtcurrpos, vehicleid vid from currentposition where vehicleid in (
	select vehicleid from admin_vehiclestatus where enddt is null)) s) s1 where s1.dtcurrpos <> s1.dtadmin';
	echo "<br>";
	while ($drUpdate = pg_fetch_array($dsUpdateTemp)) {

		$idData = runSQL("insert into admin_vehiclestatusdone (id, vehicleid, startdt, enddt, ignition, status, location, speed, active, comment, useridcomm)
		select id, vehicleid, startdt, '" . $drUpdate["dtcurrpos"] . "', ignition, status, location, speed, active, comment, useridcomm 
		from admin_vehiclestatus where vehicleid=" . $drUpdate["vid"] . " returning id");

		//runSQL("delete from admin_vehiclestatus where id = " . $idData);
		runSQL("delete from admin_vehiclestatus where vehicleid=" . $drUpdate["vid"]);

		//$idUpdate = dlookup("update admin_vehiclestatus set enddt = '" . $drUpdate["dtcurrpos"] . "' where vehicleid=" . $drUpdate["vid"] . " returning id");
		//echo "update admin_vehiclestatus set enddt = '" . $drUpdate["dtcurrpos"] . "' where vehicleid=" . $drUpdate["vid"] . " returning id" . "<br>";
		//runSQL("insert into admin_vehiclestatusdone select * from admin_vehiclestatus where id = " . $idUpdate);
		//echo "insert into admin_vehiclestatusdone select * from admin_vehiclestatus where id = " . $idUpdate . "<br>";
		//runSQL("delete from admin_vehiclestatus where id = " . $idUpdate);
		//echo "delete from admin_vehiclestatus where id = " . $idUpdate . "<br>";
	}	
		
	closedb();
	
?>

