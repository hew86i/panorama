
<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
	//Ispituvame dali ima najaven korisnik. Ako nema mora da se odi na Login

	$txt_file = file_get_contents('lang.txt');
	$rows = explode("\n", $txt_file);
	array_shift($rows);
	
	foreach($rows as $row => $data)
	{
	    //get row data
	    $row_data = explode('","', $data);
	
	    $info[$row]['id'] = $row_data[1];
	    $info[$row]['mk'] = $row_data[2];
	    $info[$row]['en'] = $row_data[3];
	    $info[$row]['fr'] = $row_data[4];
	
	    //display data
	    echo "<\\".$info[$row]['id'].">".$info[$row]['fr']."<\/".$info[$row]['id'].">";
	    //echo 'Row ' . $row . ' MK: ' . $info[$row]['mk'] . '<br />';
	    //echo 'Row ' . $row . ' EN: ' . $info[$row]['en'] . '<br />';
	    //echo 'Row ' . $row . ' FR: ' . $info[$row]['fr'] . '<br />';
	
	    //display images
	    
	
	    echo '<br />';
	}
	
	/*
	$doc = new DOMDocument();
	$doc->load('./language/'.$cLang.'.xml');
	$employees = $doc->getElementsByTagName("login");
	
	echo $employees->length;
		
	if($doc->getElementsByTagName('logintitle')->item(0).'' == '')
		echo "2";
	else
		echo "1";
	exit;*/
	exit;
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>Panorama - Geonet GPS Fleet Management Solution</title>
	<link rel="stylesheet" type="text/css" href="./style.css">
	<LINK REL="SHORTCUT ICON" HREF="./images/icon.ico">
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/roundIE.js"></script>
	<script type="text/javascript" src="./js/share.js"></script>
</head>
<body>
	<div id="main-blue-track"></div>
	<div id="main-container">
		<img id="img-logo" src="./images/Logo.png" width="200" height="94" alt="" />
		<div id="div-advert" class="textTitle">
			<?php echo dic('logintitle')?><br><br>
		</div>
		<div id="div-lang">
			<a id="icon-mk" href="./lang.php?l=mk"><img src="./images/mk.png" width="30" height="30" border="0" align="absmiddle" style=""/></a>&nbsp;&nbsp;&nbsp;
			<a id="icon-en" href="./lang.php?l=en"><img src="./images/en.png" width="30" height="30" border="0" align="absmiddle"/></a>&nbsp;&nbsp;&nbsp;
			<a id="icon-logout" href="./logout/?l=<?php echo $cLang?>"><img src="./images/exit1.png" width="30" height="30" border="0" align="absmiddle"/></a>&nbsp;<br>
		</div>
	</div>
</body>
</html>