﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>

	<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	
	</head>
	
	<body></body>
	</html>

<?php

  $to = getQUERY("to");
  $msg = str_replace("'", "", getQUERY("msg"));
 
  $allowedIP = array("217.16.79.81", "92.55.94.4", "92.55.94.3", "92.55.94.2", "92.55.94.5");
  $myIP = getIP();
  
  $ifOk = 0;
  for($i=0; $i < count($allowedIP); $i++) {
	 if ($allowedIP[$i] == $myIP)
	 	$ifOk = 1;
  }
  /*echo $to . " *** " . $msg;
  exit();*/
  
  if ($ifOk == 1) {
  	echo "Ок!";
	opendb();
	RunSQL("insert into sms_gsm (userid, tonumber, fromnumber, message, answer, flag, datetime, messagedate, indeks, modem)
	values (1, '" . $to . "', '+38970411226', '" . $msg . "', 'yes', 'ToSend', '" . now() . "', '', 0, 'a')");  
	closedb();
  }	  else {
  	echo "Немате дозвола за праќање смс преку оваа ip адреса!";
  }
  
?>
