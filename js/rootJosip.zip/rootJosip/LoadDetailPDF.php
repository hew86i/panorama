﻿<?php include "../include/db.php" ?>
<?php include "../include/functions.php" ?>
<?php include "../include/params.php" ?>
<?php include "../include/dictionary2.php" ?>

<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../style.css">
<style type="text/css">
.style1 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#F5F5F5; border-left:1px solid #999999; border-top:1px solid #999999; border-bottom:1px solid #999999; 
}
.style2 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#F5F5F5; border-top:1px solid #999999; border-bottom:1px solid #999999; 
}
.style3 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#F5F5F5; border-right:1px solid #999999; border-top:1px solid #999999; border-bottom:1px solid #999999; 
}
.style4 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#C0D692; border:1px solid #77992E 
}
.style5 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#E39896; border:1px solid #AD3B37 
}
.style6 {
	font-family: Arial, Helvetica, sans-serif; font-size: 11px; padding:3px 3px 3px 3px;
	background-color:#F7962B; border:1px solid #FF6633 
}
</style>

<?php
	if (nnull(is_numeric(nnull(getQUERY("uid"))), 0)>0){
		$uid = getQUERY("uid");
	} else {
		$uid = session("user_id");
	}
	$testignoff = 0;
	opendb();
	
$metric = dlookup("select metric from users where id=" . $uid);
if ($metric == 'mi') {
			$metricvalue = 0.621371;
			$metricvalue1 = 1.0936;
			$speedunit = "mph";
			$metric1 = "yards";
		}	
		else {
			$metricvalue = 1;
			$metricvalue1 = 1;
			$speedunit = "Km/h";
			$metric1 = dic_("Reports.Meters");
		}
		

	$v = getQUERY("v");
	$dsVehicle = query("select * from vehicles where id = " . $v);
	$d = getQUERY("d");
	$sd = getQUERY("sd");
	$ed = getQUERY("ed");
	
	$reg = dlookup("select trim(registration) from vehicles where id=" . $v);
	$code = dlookup("select code from vehicles where id=" . $v);
	$alias = dlookup("select alias from vehicles where id=" . $v);
	$orgid = dlookup("select organisationid from vehicles where id=" . $v);

	$allowedCanBus = dlookup("select allowcanbas from vehicles where id=" . $v);
	$capacity = dlookup("select fuelcapacity from vehicles where id=" . $v);
	$currfuel = 0;
	$lastfuel = 0;
	$currfuel1 = 0;
	$lastfuel1 = 0;	

	$liqunit1 = dlookup("select liquidunit from users where id=" . $uid);
	if ($liqunit1 == 'galon') {
		$liqvalue = 0.264172;
		$liqunit = "gal";
	}
	else {
		$liqvalue = 1;
		$liqunit = "lit";
	}

	//$CreationDate = now();     
	/*format na datum*/
	$datetimeformat = dlookup("select datetimeformat from users where id=" . $uid);
	$datfor = explode(" ", $datetimeformat);
	$dateformat = $datfor[0];
	$timeformat =  $datfor[1];
	if ($timeformat == 'h:i:s') $timeformat = $timeformat . " a";
	
	if ($timeformat == "H:i:s") {
		$e_ = " 23:59";
		$e1_ = "_23:59";
		$s_ = " 00:00";
		$s1_ = "_00:00";
		$tf = " H:i";
	}	else {
		$e_ = " 11:59 PM";
		$e1_ = "_11:59_PM";
		$s_ = " 12:00 AM";
		$s1_ = "_12:00_AM";
		$tf = " h:i a";
	}		
	
	//$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
	
       
	$tzone = dlookup("select tzone from users where id=" . $uid);  
	$CreationDate = strtoupper(DateTimeFormat(addToDateU(now(), $tzone, "hour", "Y-m-d H:i"), $datetimeformat));  

	/*format na datum*/
	$fullname = dlookup("select fullname from users where id='" . getQUERY("uid") . "'");
	$company = dlookup("select name from clients where id in (select clientid from users where id=" . getQUERY("uid") . " limit 1) limit 1");

 	if ($orgid == 0) $orgName = dic_("Reports.UngroupedVehicles");
	else $orgName = dlookup("select name from organisation where id=" . $orgid);


?>

<div style="padding-left:40px; padding-top:10px; width:500px" class="textTitle">
			<?php echo mb_strtoupper(dic_("Reports.Detail"), 'UTF-8') ?>&nbsp;&nbsp;&nbsp;&nbsp;
			<div style="font-size:18px" class="textTitle"><?php echo $reg . " (" . $code . ")"?><br><span style="font-size: 14px;"><?php echo $alias?></span><br><br></div>
			<span class="text5"> <?php dic("Reports.User")?>: <strong><?php echo $fullname?></strong></span><br>
			<span class="text5"> <?php dic("Reports.Company")?>: <strong><?php echo $company?></strong></span><br>
			<?php
			
			$allDrivers = dlookup("select getdrivernew2('" . $sd . "', '" . $ed . "', " . $v . ")");
			$allDrivers = implode("; ", (array_unique(explode("; ", $allDrivers))));
			$allDrivers = substr($allDrivers, 0, -2);
			if ($allDrivers <> '') {
			?>
			<span class="text5"> <?php dic("Reports.Drivers") ?>: <strong><?php echo $allDrivers?></strong></span><br>	
			<?php
			}
			?>
			<span class="text5"> <?php dic("Reports.OrgUnit") ?>: <strong><?php echo $orgName?></strong></span><br>
			<span class="text5"> <?php dic("Reports.CreationDate")?>: <strong><?php echo $CreationDate?></strong></span><br>
			<span class="text5"> <?php dic("Reports.DateTimeRange")?>: <strong><?php echo DateTimeFormat(getQUERY("d"), $dateformat) . " " . $s_?></strong> - <strong><?php echo DateTimeFormat(getQUERY("d"), $dateformat) . " " . $e_?></strong></span><br><br>_
		</div>

  	
<table width="99%" border="0" cellpadding="0" cellspacing="0">
<?php
   
		
	
	
	$cid = dlookup("select clientid from vehicles where id=" . $v);
	$ct = dlookup("select clienttypeid from clients where id=" . $cid);
		

	$meseci = array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
    	
	$idleover = dlookup("select idleover from users where id=" . $uid);	

	$ignition = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=1");

	$allowFuel = dlookup("select allowFuel from vehicles where id=" . $v);
	$noports = dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid in (select id from porttypes where name like '%gorivo%')");
	$fuel = "";
	$seatsColumn = "";
	if ($allowedCanBus == 1) {
			$fuel = "cbfuel fuel, ";
	}	
	else {
	if ($allowFuel == '1') {
		$seatsColumn = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=9");
	
		if ($v == 2399 or $v == 2524) {
			$fuel = "4.997 * " . $seatsColumn . "- 14.13" . " fuel, "; 
		} else {
			if ($v == 2397 or $v == 2522) {
				$fuel = "5.655 *" . $seatsColumn . " + 6.355" . " fuel, ";
			} else {
				if ($v == 2398 or $v == 2523) {
					$fuel = "5.504 *" . $seatsColumn . "+ 24.16" . " fuel, ";
				} else {
					if ($v == 2557) {
						$fuel = "6.487 * " . $seatsColumn . "- 3.907" . " fuel, ";
					} else {
						if($v == 2555) {
							$fuel = "6.549 * " . $seatsColumn . "- 2.532" . " fuel, ";
						} else {
							if($v == 2556) {
								$fuel = "6.704 * " . $seatsColumn . " + 2.193" . " fuel, ";
							} else {
								if ($v == 2594 ) {
									$fuel = "7.173 *" . $seatsColumn . "- 6.307" . " fuel, ";
								} else {
									if ($v == 2659 ) {
										$fuel = "-0.009 * " . $seatsColumn . " * " . $seatsColumn . "+ 4.243 * " . $seatsColumn . " - 5.459 fuel, ";
									} else {
										if($v == 2595) {
											//$noports = dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid in (select id from porttypes where name like '%gorivo%')");
											//if ($noports == 1)
												$fuel = "4.917 *" . $seatsColumn . "- 18.94" . " fuel1, ";
											//if ($noports > 1) {
												$seatsColumn1 = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=14");
												$fuel .= "4.955 *" . $seatsColumn1 . "- 13.48" . " fuel2, ";
											//}
										} else {
											if($v == 2605) {
												//$fuel = "7.190 * " . $seatsColumn . "+ 0.408" . " fuel, ";
												$fuel = "11.61 * " . $seatsColumn . "+ 1.536" . " fuel, ";
											} else {
												if($v == 2725) {
													//$fuel = "7.190 * " . $seatsColumn . "+ 0.408" . " fuel, ";
													$fuel = "1.975 * " . $seatsColumn . "- 0.137" . " fuel, ";
												} else {
													if($v == 2737) {
														//$fuel = "7.190 * " . $seatsColumn . "+ 0.408" . " fuel, ";
														$fuel = "1.731 * " . $seatsColumn . "+ 0.293" . " fuel, ";
													} else {
														if($v == 2723) {
															//$fuel = "7.190 * " . $seatsColumn . "+ 0.408" . " fuel, ";
															$fuel = "1.831 * " . $seatsColumn . "- 0.693" . " fuel, ";
														} else {
															if($v == 2722) {
																//$fuel = "7.190 * " . $seatsColumn . "+ 0.408" . " fuel, ";
																$fuel = "1.199 * " . $seatsColumn . "- 1.128" . " fuel, ";
															} else {
																//$fuel = ($seatsColumn * $capacity) / 100 . " fuel, ";
																$fuel = ($seatsColumn . "*" . $capacity) ."/ 100" . " fuel, ";
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	}
		

	$taximeter = "";
	$seats = "";
	$temp = "";
	$interv = "";
	$pump = "";
	$caps = "";
	$rpm = "";
	$sednatpatnik = "";
	
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=2") > 0)	
		$taximeter = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=2");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=5") > 0)
		$seats = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=5");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=13") > 0)
		$temp = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=13");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=4") > 0)
		$interv = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=4");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=15") > 0)
		$pump = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=15");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=7") > 0)
		$caps = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=7");	
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=16") > 0)
		$rpm = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=16");
	if (dlookup("select count(*) from vehicleport where vehicleid=" . $v . " and porttypeid=11") > 0)
		$sednatpatnik = dlookup("select portname from vehicleport where vehicleid=" . $v . " and porttypeid=11");
	
	$colspan = 8;
	if ($temp <> "") $colspan ++;
	if ($ct == 2) $colspan ++;
	if ($allowedCanBus == '1') $colspan += 4;
	if ($allowFuel == '1') $colspan ++;
	if ($interv <> "") $colspan ++;
	if ($pump <> "") $colspan ++;
	if ($caps <> "") $colspan ++;
	if ($rpm <> "") $colspan ++;
	if ($sednatpatnik <> "") $colspan ++;
	
	/*if ($taximeter <> "" && $seats <> "" && $temp <> "") {			
	    $sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, 
	    " . $ignition . " ignition, " . $taximeter . " Taximeter, " . $seats . " Seats, " . $temp . " Temperature, location   
	    from historylog where vehicleid=" . $v . " and datetime>='" . $d . " 00:00:00' 
	    and datetime<='" . $d . " 23:59:59' and Status='1' order by DateTime asc";		
  	} else {
  		if ($taximeter <> "") {
  			$sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, 
		    " . $ignition . " ignition, " . $taximeter . " Taximeter, location   
		    from historylog where vehicleid=" . $v . " and datetime>='" . $d . " 00:00:00' 
		    and datetime<='" . $d . " 23:59:59' and Status='1' order by DateTime asc";
  		} else {
  			if ($seats <> "") {
	  			$sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, 
			    " . $ignition . " ignition, " . $seats . " Seats, location   
			    from historylog where vehicleid=" . $v . " and datetime>='" . $d . " 00:00:00' 
			    and datetime<='" . $d . " 23:59:59' and Status='1' order by DateTime asc";
		    } else {
		    	$sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, 
			    " . $ignition . " ignition, location   
			    from historylog where vehicleid=" . $v . " and datetime>='" . $d . " 00:00:00' 
			    and datetime<='" . $d . " 23:59:59' and Status='1' order by DateTime asc";
		    }
  		}
  	}*/
  
	$diffcbdist = 0;
	$lastcbdist = 0;  	
	$taxiCol = "";
	$seatsCol = "";
	$tempCol = "";
	$intervCol = "";
	$pumpCol = "";
	$capsCol = "";
	$rpmCol = "";
	$sednatpatnikCol = "";
	
if ($taximeter <> "") $taxiCol = ", " . $taximeter . " taximeter";
if ($seats <> "") $seatsCol = ", getpassengers(" . $seats . ") seats";
if ($temp <> "") $tempCol = ", " . $temp . " Temperature";
if ($interv <> "") $intervCol = ", " . $interv . " intervention";
if ($pump <> "") $pumpCol = ", " . $pump . " pump";
if ($caps <> "") $capsCol = ", " . $caps . " caps";
if ($rpm <> "") $rpmCol = ", " . $rpm . " rpm";
if ($sednatpatnik <> "") $sednatpatnikCol = ", " . $sednatpatnik . " sednatpatnik";

$prevignhl = dlookup("select " . $ignition . " ignition from historylog where vehicleid= " . $v . " and datetime < '" . $sd . "' and datetime > '1980-12-31' order by datetime desc limit 1");
$prevign = dlookup("select ignition from rshortreport where vehicleid= " . $v . " and datetime < '" . $sd . "' and datetime > '1980-12-31' order by datetime desc limit 1");
$previgndt = dlookup("select datetime from rshortreport where vehicleid= " . $v . " and datetime < '" . $sd . "' and datetime > '1980-12-31' order by datetime desc limit 1");
//$dist = dlookup("select * from getdistance('" . $previgndt . "', '" . pg_fetch_result($dsDetail, 0, "datetime") . "', " . $v . ")") * $metricvalue1;

$sdFinal = DateTimeFormat($sd, 'Y-m-d H:i:s');
$edFinal = DateTimeFormat($ed, 'Y-m-d H:i:s');
	
if (DateTimeFormat($sd, 'H:i:s') == "00:00:00" and DateTimeFormat($ed, 'H:i:s')  == "23:59:59")	{
	 $sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, poinames, zonenames,
	" . $ignition . " ignition, location " . $taxiCol . $seatsCol . $tempCol . $intervCol . $pumpCol . $capsCol . $rpmCol . $sednatpatnikCol . ", " . $fuel . " cbrpm, cbtemp, cbdistance, cbfuel 
	from historylog where vehicleid=" . $v . " and datetime>='" . DateTimeFormat($sd, 'Y-m-d H:i:s') . "' 
	and datetime<='" . DateTimeFormat($ed, 'Y-m-d H:i:s') . "' order by DateTime asc";		
} else {
	$prevign_ = dlookup("select " . $ignition . " from historylog where vehicleid= " . $v . " and datetime < '" . DateTimeFormat($sd, 'Y-m-d H:i:s') . "' and datetime > '1980-12-31' order by datetime desc limit 1");
	$lastign_ = dlookup("select " . $ignition . " from historylog where vehicleid= " . $v . " and datetime < '" . DateTimeFormat($ed, 'Y-m-d H:i:s') . "' order by datetime desc limit 1");
	$sdTemp = "";
	$edTemp = "";
	
	if ($prevign_ == "1") {
		$sdTemp = dlookup("select datetime from rshortreport where vehicleid= " . $v . " and datetime <= '" . DateTimeFormat($sd, 'Y-m-d H:i:s') . "' and datetime >= '1980-12-31' and ignition='1' order by datetime desc limit 1");
	} else {
		$sdTemp = DateTimeFormat($sd, 'Y-m-d H:i:s');
	}
	
	if ($lastign_ == "1") {
		$edTemp = dlookup("select datetime from rshortreport where vehicleid= " . $v . " and datetime >= '" . DateTimeFormat($ed, 'Y-m-d H:i:s') . "' and ignition='0' order by datetime asc limit 1");
	} else {
		$edTemp = DateTimeFormat($ed, 'Y-m-d H:i:s');
	}
		
	$sql_ ="select cast(longitude as numeric(18,6)) longitude, cast(latitude as numeric(18,6)) latitude, speed, datetime, poinames, zonenames,
	" . $ignition . " ignition, location " . $taxiCol . $seatsCol . $tempCol . $intervCol . $pumpCol . $capsCol . $rpmCol . $sednatpatnikCol . ", " . $fuel . " cbrpm, cbtemp, cbdistance, cbfuel 
	from historylog where vehicleid=" . $v . " and datetime>='" . $sdTemp . "' 
	and datetime<='" . $edTemp . "' order by DateTime asc";	
	
	$sdFinal = $sdTemp;
	$edFinal = $edTemp;	
}

	$dsDetail = query($sql_);
	$ifIgnOn = 0;

	while ($_d = pg_fetch_array($dsDetail)) {
		if ($_d["ignition"] == '1') $ifIgnOn = 1;
	}

	$dsDetail = query($sql_);

	if (pg_num_rows($dsDetail) > 0 and $ifIgnOn <> 0) {
		
    $langArr = explode("?", getQUERY("l"));
	$cLang = $langArr[0];
    
    //$_dsPOI = query("select id, geom, name, radius from pointsofinterest where clientid=" . $cid);
	
	$startOdometer = 0;
	$endOdometer = 0;
	$dali = 0;
	$dist = 0;
	$llon = 0;
	$llat = 0;
    $tim;
    $maxSpeed = 0;
	$maxTemp = -40;
    $i = 0;
$j = 0;
    $totalSpeed = 0;
	$totalTemp = 0;
	$maxCBTemp = -40;
	$totalCBTemp = 0;
	$cbj = 0;

	while ($_d = pg_fetch_array($dsDetail)) {
				
        $langArr = explode("?", getQUERY("l"));
		$cLang = $langArr[0];
		
        /*Dim poi As New sPOI
        poi = getNiarestPOI(_d("Latitude"), _d("Longitude"), _dsPOI)*/
        //$poi = nnull(dlookup("select getpoiname(" . $_d["latitude"] . ", " . $_d["longitude"] . ", " . $cid . " )"), "");
		$loc = nnull($_d["location"], ""); //"location";//dlookup("select getgeocode (" . $_d["latitude"] . ", " . $_d["longitude"] . ")");	

if ($idleover <> 0) {				
        If ($dali == 0 And $_d["ignition"] == 1) {
			if ($testignoff == 0 and $prevign == '1') {
           		//$disttotal = dlookup("select * from getdistance('" . $previgndt . "', '" . pg_fetch_result($dsDetail, 0, "datetime") . "', " . $v . ")");
			} 
			$startOdometer = 0;
			$endOdometer = 0;
            $dist = 0;
            $tim = $_d["datetime"];
            $maxSpeed = 0;
	    $maxTemp = -40;
			$maxCBTemp = -40;
            $i = 0;
	$j=0;
            $totalSpeed = 0;
            $totalTemp = 0;
			$totalCBTemp = 0;	
			$cbj = 0;		
			$diffcbdist = 0;
?>		
	<tr>
    	<td width="25px"></td>
    	<?php
    			
    	if ($prevign == '0' or $prevign == null or $testignoff == '1' or DateTimeFormat($previgndt, $dateformat) == DateTimeFormat($d, $dateformat)) {	
    		//$dist = 0;
    	?>
       			<td colspan="<?php echo $colspan-1?>" class="style4" height="20px"><strong><?php echo strtoupper(DateTimeFormat($_d["datetime"], $timeformat))?></strong>&nbsp;&nbsp;&nbsp;<?php dic("Reports.EngineON1") ?></td>
    <?php
		} else {
			//$dist = dlookup("select * from getdistance('" . $previgndt . "', '" . pg_fetch_result($dsDetail, 0, "datetime") . "', " . $v . ")") * $metricvalue1;
			?>
				<td colspan="<?php echo $colspan-1?>" class="style4" height="20px"><strong><?php echo DateTimeFormat($previgndt, $datetimeformat)?></strong>&nbsp;&nbsp;&nbsp;<?php dic("Reports.EngineON1") ?><!-- и до сега има поминато <strong><?php echo round($disttotal*$metricvalue1)?> <?php echo $metric ?>--></strong></td>
			<?php
		}
		?>
    </tr>
    <tr>
    	<td width="25px"></td>
		<td width="25px"></td>
		<td width="60px" class="style1" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.Vreme") ?></b></td>
		<td width="70px" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.Aktivnost") ?></b></td>
		<td width="60px" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.Speed") ?></td>
		<td width="90px" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.DistCum") ?></b></td>
		<?php
		if ($temp <> "") {
		?>
			<td width="105px" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.TempCargo") ?></b></td>
		<?php
		}
		if ($ct == 2) {
			?>
			<td width="60px" align="center" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php dic("Reports.Passengers") ?></b></td>
			<?php
			$t = dic_("Reports.Taximeter");
		}	
		
		if ($allowedCanBus == '1') {
			?>
			<td width="60px" align="left" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Odometer")?></b></td>
			<td width="60px" align="left" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.RPM")?></b></td>
			<td width="70px" align="left" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.EngTemp")?></b></td>
			<td width="60px" align="left" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.FuelLevel")?></b></td>
			
			
			<?php
		}
		if ($allowFuel == '1') {
		?>
		<td width="60px" class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.FuelLevel")?></b></td>
		<?php	
		}

		if ($interv <> "") {
		?>
			<td width="105px" class="style2" align="center" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Intervention")?></b></td>
		<?php
		}

		if ($pump <> "") {
		?>
			<td width="105px" class="style2" align="center" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Pump")?></b></td>
		<?php
		}

		if ($caps <> "") {
		?>
			<td width="105px" class="style2" align="center" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Caps")?></b></td>
		<?php
		}

		if ($rpm <> "") {
		?>
			<td width="105px" class="style2" align="center" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Load")?></b></td>
		<?php
		}
		
		if ($sednatpatnik <> "") {
		?>
			<td width="105px" class="style2" align="center" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.FrontPassenger")?></b></td>
		<?php
		}
		
		?>
		
		<td width="60px" align="center"  class="style2" style="background-color:#E5E3E3; border-top:0px"><b><?php echo $t?></b></td>
		
		<td class="style3" align="right" style="background-color:#E5E3E3; border-top:0px"><b><?php echo dic_("Reports.Location")?></b></td>
	
    </tr>
    
    
   	<tr>
    	<td width="100%" colspan="<?php echo $colspan?>" height="2px"></td>
    </tr>
<?php
			$dali = 1;
		} //end if
	} else {
If ($dali == 0 And $_d["ignition"] == 1 And $_d["speed"] > 3) {
            $dist = 0;
			$diffcbdist = 0;
            $tim = $_d["datetime"];
            $maxSpeed = 0;
			$maxTemp = -40;
			$maxCBTemp = -40;
            $i = 0;
$j=0;
            $totalSpeed = 0;
			$totalTemp = 0;
			$totalCBTemp = 0;
			$cbj = 0;
?>		
	<tr>
    	<td width="25px"></td>
        <td colspan="<?php echo $colspan-1?>" class="style4" height="20px"><strong><?php echo strtoupper(DateTimeFormat($_d["datetime"], $timeformat))?></strong>&nbsp;&nbsp;&nbsp;<?php dic("Reports.EngineON1") ?></td>
    </tr>
   	<tr>
    	<td width="100%" colspan="<?php echo $colspan?>" height="2px"></td>
    </tr>
<?php
			$dali = 1;
}
}
		if ($dali == 1 and $_d["ignition"] == 0) {
			$testignoff = 1;	
			$sumpominati = "<span style='padding-left:10px; color:#000; font-size:11px; '>Вкупно поминати   <b style='color:#800'>" . round($dist) . "</b> метри</span>";
$driver = "";
$driver = str_replace("<br>", " ", dlookup("select getdrivernew1('" . $_d["datetime"] . "', '" . $tim . "', " . $v . ")"));
$driver = substr($driver, 0, -2);

if ($driver <> " " and $driver <> "")
	$driver_ = "&nbsp;&nbsp;&nbsp;<strong>" . dic_("Reports.Driver") . ": </strong>" . nnull($driver, "/");
else
	$driver_ = "";
if ($temp <> "") {
	if ($maxTemp < 50 and $maxTemp > -40) {
		$mt = $maxTemp . " °C";
		$at = round($totalTemp/$j,0) . " °C";
	} else {
		$mt = "/";
		$at = "/";
	}
	$temp_ = "<strong>". dic_("Reports.MaxTemp") . ": </strong>" . $mt;
	$tempavg_ = "<strong>" . dic_("Reports.AverageTemp"). ": </strong>" . $at;
} else {
	if ($allowedCanBus == '1') {
		$mcbt = intval($maxCBTemp) . " °C";
		$acbt = round($totalCBTemp/$cbj,0) . " °C";
		$temp_ = "<strong>". dic_("Reports.MaxEngTemp") . ": </strong>" . $mcbt;
		$tempavg_ = "<strong>" . dic_("Reports.AvgEngTemp"). ": </strong>" . $acbt;
	} else {
		$temp_ = "";
		$tempavg_ = "";
	}
}
?>		
	
        <?php
        if ($allowedCanBus == '1') {
        	?>
        	 <tr>
       			 <td width="25px"></td>
       			 <td colspan=3 class="style5" style="border-right:0px; border-bottom:0px" height="20px"><strong><?php echo strtoupper(DateTimeFormat($_d["datetime"], $timeformat))?></strong>&nbsp;&nbsp;&nbsp;<?php dic("Reports.EngineOFF1") ?></td>
        	     <td colspan="<?php echo $colspan-4?>" style="border-left:0px; border-bottom:0px" class="style5" height="20px"><strong><?php echo dic_("Reports.TotalTime")?>:</strong> <?php echo sec2str(abs(strtotime($tim)-strtotime($_d["datetime"]))) ?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.PominatoRastojanie")?>:</strong> <?php echo number_format(round($diffcbdist*$metricvalue1)) ?> <?php echo $metric1?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.StartOdometer")?>:</strong> <?php echo number_format(($startOdometer/1000)*$metricvalue)?> <?php echo $metric?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.EndOdometer")?>:</strong> <?php echo number_format(($endOdometer/1000)*$metricvalue)?> <?php echo $metric?></td>
        	 </tr>
        	 <tr>
        	 	 <td width="25px"></td>
        	 	 <td colspan=3 class="style5" height="20px" style="border-top:0px; border-right:0px">&nbsp;</td>
        	     <td colspan="<?php echo $colspan-4?>" class="style5" style="border-top:0px; border-left:0px" height="20px"><strong><?php echo dic_("Reports.MaximumSpeed")?>: </strong><?php echo round($maxSpeed*$metricvalue,0)?> <?php echo $speedunit?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.AVGSpeed")?>: </strong><?php echo round($totalSpeed*$metricvalue/$i) ?> <?php echo $speedunit?><?php echo $driver_?>&nbsp;&nbsp;&nbsp;<?php echo $temp_?>&nbsp;&nbsp;&nbsp;<?php echo $tempavg_?></td>
        	 </tr>
        	<?php
		} else {
			?>
			<tr>
       			 <td width="25px"></td>
				 <td colspan="<?php echo $colspan-1?>" class="style5" height="20px"><strong><?php echo strtoupper(DateTimeFormat($_d["datetime"], $timeformat))?></strong>&nbsp;&nbsp;&nbsp;<?php dic("Reports.EngineOFF1") ?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.TotalTime")?>:</strong> <?php echo sec2str(abs(strtotime($tim)-strtotime($_d["datetime"]))) ?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.PominatoRastojanie")?>:</strong> <?php echo number_format(round($dist*$metricvalue1)) ?> <?php echo $metric1?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.MaximumSpeed")?>: </strong><?php echo round($maxSpeed*$metricvalue,0)?> <?php echo $speedunit?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.AVGSpeed")?>: </strong><?php echo round($totalSpeed*$metricvalue/$i) ?> <?php echo $speedunit?><?php echo $driver_?>&nbsp;&nbsp;&nbsp;<?php echo $temp_?>&nbsp;&nbsp;&nbsp;<?php echo $tempavg_?></td>
			</tr>
			<?php
		}
        	
        ?>
   
    <tr>
        <td width="100%" colspan="<?php echo $colspan?>" height="10px"></td>
    </tr>
	<?php
	    $dali = 0;
	
		} //end if
			if ($dali == 1 and $_d["ignition"] == 1) {
		   		 If ($llon <> 0) {
		   		 	
		       		 //$dist += 0;//abs(getDistance($llat, $llon, $_d["latitude"], $_d["longitude"], "K") * 1000);
		       		 $dist += dlookup("select dist_lonlat(" . $llat . ", " . $llon . ", " . $_d["latitude"] . ", " . $_d["longitude"] . ")");
					 $diffcbdist += $_d["cbdistance"] - $lastcbdist;
					 
					 
	
				 }
	        	 
				if ($startOdometer == 0)
						 $startOdometer = $_d["cbdistance"];
					 $endOdometer = $_d["cbdistance"];
				
				$_Status = "<b style='color:#6A9905'>" . dic_("Reports.ActivityOn") . "</b>";
				$checkIdle = 1;
				if ($_d["speed"] < 3) {
					$_Status = "<b style='color:#BFBD0D'>" . dic_("Reports.Standing") . "</b>";
					$checkIdle = 0;
				}	
				$_taxi = "&nbsp;";
				$_patnici = "&nbsp;";
				$_temp = "&nbsp;";
				$_cbtemp = "&nbsp;";
				if ($ct == 2) {
					if ($taximeter <> "") {
						if ($_d["taximeter"] == true) $_taxi = dic_("Reports.ON1");
						else $_taxi = dic_("Reports.OFF1");
					}
					if ($seats <> "") {
						/*if ($_d["seats"] > 0)*/ $_patnici = "<b style='color:#800'>" . $_d["seats"] . "</b>";
					}
				}
				if ($temp <> "") {
					if (round($_d["temperature"] * 20 - 70, 0) < -40 or round($_d["temperature"] * 20 - 70, 0) > 50) {
						$_temp = ": " . "/";
					} else {
						$_temp = round($_d["temperature"] * 20 - 70, 0) . " °C";
						$totalTemp += round($_d["temperature"] * 20 - 70, 0);
						$j += 1;
					}
				}
				
	    If (round($_d["speed"]) > $maxSpeed) {
	        $maxSpeed = round($_d["speed"]);
	    }


	    if ($temp <> "") {
			If (round(round($_d["temperature"] * 20 - 70, 0)) > $maxTemp) {
		        $maxTemp = round($_d["temperature"] * 20 - 70, 0);
		   }
		}
		
		if ($allowedCanBus == "1") {
			If ($_d["cbtemp"] > $maxCBTemp) {
		        $maxCBTemp = $_d["cbtemp"];
		   }
			$_cbtemp = "<b style='color:#800'>" . intval($_d["cbtemp"]) . "</b>" . " °C";
			$totalCBTemp += $_d["cbtemp"];
			$cbj += 1;			
		}
		
	    $i += 1;
	    $totalSpeed += round($_d["speed"]);
			
//echo $_Status . " " . dic_("Reports.Standing") . ";";

	    if (($idleover == 0 && $checkIdle <> 0) || $idleover <> 0) {
	?>
	
	<tr>
	    <td width="25px"></td>
		<td width="25px"></td>
		<td width="50px" class="style1"><b><?php echo strtoupper(DateTimeFormat($_d["datetime"], $timeformat))?> </b></td>
		<td width="60px" class="style2"><?php echo $_Status?></td>
		<td width="60px" class="style2"><b style="color:#800"><?php echo round($_d["speed"]*$metricvalue)?></b> <?php echo $speedunit?></td>
		<?php
		if ($allowedCanBus == '1') {
		?>
			<td width="60px" align="left" class="style2"><b style="color:#800"><?php echo number_format(round($diffcbdist*$metricvalue1))?> </b> <?php echo $metric1?></td>
		<?php
		} else {
			?>
			<td width="60px" align="left" class="style2"><b style="color:#800"><?php echo number_format(round($dist*$metricvalue1))?> </b> <?php echo $metric1?></td>	
			<?php
		}
		?>
		
<?php
if ($temp <> "") {
?>
<td width="60px" class="style2"><?php echo $_temp?></td>
<?php
}

if ($ct == 2) {
?>
<td width="60px" align="center" class="style2"><?php echo $_patnici?></td>
<?php
}

if ($allowedCanBus == '1') {
?>
<td width="100px" align="left" class="style2"><b style="color:#800"><?php echo number_format(($_d["cbdistance"]/1000) * $metricvalue)?></b> <?php echo $metric ?></td>
<td width="60px" align="left" class="style2" style="color:#800"><b><?php echo number_format($_d["cbrpm"])?></b></td>
<td width="60px" align="left" class="style2"><?php echo $_cbtemp?></td>
<td width="60px" align="left" class="style2"><b style="color:#800"><?php echo (intval($_d["cbfuel"] * $capacity) / 100) * $liqvalue ?></b> <?php echo $liqunit ?></td>


<?php	
}
if ($allowFuel == '1') {
	if ($noports > 1) {
		$currfuel = round($_d["fuel1"]* $liqvalue);
		$currfuel1 = round($_d["fuel2"]* $liqvalue);
	}
	else {
		$currfuel = round($_d["fuel"]* $liqvalue);
	}

	$percent = dlookup("select _percent from addfueltable where " . $capacity . " >= _from and " . $capacity . " <= _to");
	$a = "";
	
	if ($noports > 1) {
		if (($lastfuel <> 0 || $lastfuel1 <> 0) && (($currfuel - $lastfuel) > ($capacity * ($percent/100)) || ($currfuel1 - $lastfuel1) > ($capacity * ($percent/100))) && $_d["speed"] < 5) {
			$a = "<img height='16px' border='0' align='absmiddle' style='position:relative; margin-top:-4px; margin-left:-15px' src='../images/petrol.png'>";
		}
	} else {
		if ($lastfuel <> 0 && (($currfuel - $lastfuel) > ($capacity * ($percent/100))) && $_d["speed"] < 5) {
			$a = "<img height='16px' border='0' align='absmiddle' style='position:relative; margin-top:-4px; margin-left:-15px' src='../images/petrol.png'>";
		}
	}
	if ($noports > 1) {
		?>
		<td width="60px" align="left" class="style2"><b style="color:#800"><?php echo $a?> <?php echo $currfuel?> | <?php echo $currfuel1?></b> <?php echo $liqunit ?></td>
		<?php
	} else {
		?>
		<td width="60px" align="left" class="style2"><b style="color:#800"><?php echo $a?> <?php echo $currfuel?> </b> <?php echo $liqunit ?></td>
		<?php
	}
?>


<?php	
}

if ($interv <> "") {
	$style = "";
	if ($_d["intervention"] == "1") $style = "color:#880000; font-weight: bold";
?>
<td width="60px" align="center" class="style2" style="<?php echo $style?>"><?php echo $_d["intervention"]?></td>
<?php
}

if ($pump <> "") {
	if ($_d["pump"] == "1") {
		$pumpa = dic_("Reports.ActivePump");
		$colorPumpa  = "#6A9905";
	} else {
		$pumpa = dic_("Reports.InactivePump");
		$colorPumpa  = "#000";
	}
?>
<td width="60px" align="center" class="style2" style="color: <?php echo $colorPumpa?>"><?php echo $pumpa?></td>
<?php
}

if ($caps <> "") {
	if ($_d["caps"] == "1") {
		$kapaci = dic_("Reports.Opened");
		$colorKapaci  = "#6A9905";	
	} else {
		$kapaci = dic_("Reports.Closed");
		$colorKapaci  = "#000";	
	}
?>
<td width="60px" align="center" class="style2" style="color: <?php echo $colorKapaci?>"><?php echo $kapaci?></td>
<?php
}

if ($rpm <> "") {
	
	$showRPM = pg_fetch_result($dsVehicle, 0, "showrpm");
	if ($showRPM == "") $showRPM = "percent";
	$limitRPM = pg_fetch_result($dsVehicle, 0, "rpmlimit");
	//$limitSpeed = pg_fetch_result($dsVehicle, 0, "speedlimit");

	if ($showRPM == "percent") {
		$rpmValue = round($_d["rpm"]*10);
		if ($rpmValue >= $limitRPM) {
			$color = "#6A9905";
		} else {
			$color = "#880000";
		}
		$rpmMetric= "%";
	}
	if ($showRPM == "rpm") {
		$rpmmin = pg_fetch_result($dsVehicle, 0, "rpm_min");
		$rpmmax = pg_fetch_result($dsVehicle, 0, "rpm_max");
		$rpmValue = round((($rpmmax - $rpmmin) * $_d["rpm"] / 10) + $rpmmin);
		
		if ($rpmValue >= $limitRPM) {
			$color = "#6A9905";
		} else {
			$color = "#880000";
		}	
		$rpmMetric = dic_("Reports.Obrtai");
	}
	
	?>
	<td width="60px" class="style2" align="center" ><span style="color: <?php echo $color?>"><strong><?php echo number_format($rpmValue)?></strong></span> <?php echo $rpmMetric?></td>
	<?php
}

if ($sednatpatnik <> "") {
	if ($_d["sednatpatnik"] == 0) {
		$sp = dic_("Reports.No");
		$color = "#880000";
	} else {
		$sp = dic_("Reports.Yes");
		$color = "#6A9905";
	}
	?>
	<td width="60px" class="style2" align="center" ><span style="color: <?php echo $color?>"><strong><?php echo $sp?></strong></span></td>
	<?php
}

?>
<td width="60px" align="center" class="style2" style="color:#800"><b><?php echo $_taxi?></b></td>
       <?php
	$poi = $_d["poinames"];
	$zones = $_d["zonenames"];
	
	$strAdd = "&nbsp;";
	if ($loc <> "") {
		$strAdd = "<img width='14px' height='14px' src='../images/shome.png'>&nbsp;" . $loc;
	} 
	
	if ($poi <> "" || $zones <> "") {
		//$strAdd .= " - ";
		$strAdd .= " ";
	}
		
	if ($poi <> "" && $zones <> "") {
		$strAdd .= "<img width='14px' height='14px' src='../images/poiButton.png'> <span style='color:#800; font-weight: bold'>" . $poi . "</span> - <img width='14px' height='14px' src='../images/zoneButton.png'>
		<span style='color:#880000; font-weight: bold'>" . $zones . "</span>";
	} else {
		if ($poi <> "") {
			$strAdd .= "<img width='14px' height='14px' src='../images/poiButton.png'> <span style='color:#800; font-weight: bold'>" . $poi . "</span>";
		} else {
			if ($zones <> "")
				$strAdd .= "<img width='14px' height='14px' src='../images/zoneButton.png'> <span style='color:#880000; font-weight: bold'>" . $zones . "</span>";
			else 
				$strAdd .= "<span style='color:#880000; font-weight: bold'>" . $zones . "</span>";
			
		}
	}
	
	?>
			
		<td  class="style3" align="right"><?php echo $strAdd?></td>
    </tr>
    <tr><td width="100%" colspan="<?php echo $colspan?>" height="2px"></td></tr>
   	<?php
		}
	?>

<?php		
		} //end if
		$llon = $_d["longitude"];
		$llat = $_d["latitude"];
		        
		if ($allowedCanBus == "1") {
			$lastcbdist = $_d["cbdistance"];
		}	    
        $langArr = explode("?", getQUERY("l"));
		$cLang = $langArr[0];

	if ($allowFuel == 1) {
		if ($noports > 1) {
			$lastfuel = round($_d["fuel1"]* $liqvalue);
			$lastfuel1 = round($_d["fuel2"]* $liqvalue);
		}
		else {
			$lastfuel = round($_d["fuel"]* $liqvalue);
		}
	}
	} //end while
	$totalPastDist = number_format(dlookup("select getdistancenew0503('" . $sdFinal . "', '" . $edFinal . "', " . $v . ")") * $metricvalue) . " " . $metric;
	$totalMaxSpeed = round(dlookup("select max(speed) from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "'") * $metricvalue) . " " .$speedunit;
	$totalAvgSpeed = round(dlookup("select avg(speed) from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "' and " . $ignition. " ='1'") * $metricvalue) . " " .$speedunit;
	$firstIgnon = dlookup("select datetime from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "' and di1='1' order by datetime asc limit 1");
	$lastIgnOff = dlookup("select datetime from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "'
		and di1='0' and datetime > (select datetime from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "'
		and di1='1' and datetime < (select datetime from historylog where vehicleid = " . $v . " and datetime between '" . $sdFinal . "' and '" . $edFinal . "'
		and di1='0' order by datetime desc limit 1) order by datetime desc limit 1) order by datetime asc limit 1");
?>
	 <tr>
	 	<td></td>
	 	<td height="20px" class="style6" colspan="<?php echo $colspan-1?>">
	 		<strong><?php echo dic_("Reports.FirstIgnOn")?>:</strong> <?php echo DateTimeFormat($firstIgnon, $timeformat)?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.LastIgnOff")?>:</strong> <?php echo DateTimeFormat($lastIgnOff, $timeformat)?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.PominatoRastojanie")?>:</strong> <?php echo $totalPastDist?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.MaximumSpeed")?>:</strong> <?php echo $totalMaxSpeed?>&nbsp;&nbsp;&nbsp;<strong><?php echo dic_("Reports.AVGSpeed")?>:</strong> <?php echo $totalAvgSpeed?>
	 	</td>
	 </tr>
	<tr>
		<td colspan="<?php echo $colspan?>" height=20px></td>
	</tr>
	<?php
	}else {
		?>
		<br>
		<?php
			if ($prevign == '0') {
			?>
		      	<div id="noData" style="padding-left:40px; font-size:18px; font-style:italic; padding-bottom:40px; height:5px" class="text4">
		      		<?php dic("Reports.NoDataDay")?>
		      	</div>	
		    <?php
			} else {
		    ?>  
		    <div style="padding-left:40px; font-size:18px; font-style:italic; padding-bottom:40px; height:5px; color:#B3B109" class="text4">
		    	<?php echo dic_("Reports.DRNOSatelite")?>
		    </div>	
		    <?php
			}
		    ?>	
		<script>
			//window.parent.document.getElementById('iconCSV').title = "5";
			changeTitle();
		</script>
		<?php
	}
	closedb();
	
?>
</table>
