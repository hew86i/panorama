﻿<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>

<?php include "./include/params.php" ?>
<?php session_start()?>
<?php
    
    header("Expires: Mon, 20 Jul 2000 05:00:00 GMT");
    header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
    header("Cache-Control: no-store, no-cache, must-revalidate");
    header("Cache-Control: post-check=0, pre-check=0", FALSE);
    header("Pragma: no-cache");
	set_time_limit(0);
	opendb();

	$osmid = str_replace("'", "''", NNull($_GET['osmid'], ''));
	$name = str_replace("'", "''", NNull($_GET['name'], ''));
	
	$temp = query("select way from planet_osm_line where osm_id= " . $osmid);
	//echo "insert into tempinsertdelete (osm_id, name, ipaddress, type, way) values ('" . $osmid . "', '" . $name . "', '" . getIP() . "', 'delete', '" . pg_fetch_result($temp, 0, "way"). "')";
	$testDel = query("insert into tempinsertdelete (osm_id, name, ipaddress, type, way) values ('" . $osmid . "', '" . $name . "', '" . getIP() . "', 'delete', '" . pg_fetch_result($temp, 0, "way") . "')");
	
	$test = query("delete from planet_osm_line where osm_id=" . $osmid);
	//$strName = pg_fetch_result($dsName, 0, "name");
	//$strLonLat = pg_fetch_result($dsName, 0, "way");
    print "Успешно избришан патот <b>".$name."</b> !!!";
  	closedb();  
?>