﻿<?php include "include/db.php" ?>
<?php include "include/functions.php" ?>
<?php include "include/params.php" ?>
<?php include "include/dictionary2.php" ?>

<?php session_start()?>
<?php 
	header("Content-type: text/html; charset=utf-8");
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 <link rel="stylesheet" href="http:////code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
  <script>
			lang = '<?php echo $cLang?>'
	</script>
	<link rel="stylesheet" type="text/css" href="style.css">

	<script type="text/javascript" src="/js/jquery.js"></script>
	
	<link href="/css/ui-lightness/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css" />
    <script src="/js/jquery-ui.js"></script>
    
<style>
	.hov123:hover{ color: red; opacity: 0.8; }
</style>
</head>
	
<?php
		opendb();
		$cntHavaData = 0;
		$Allow = getPriv("distance", $uid);
		if ($Allow == false) echo header ('Location: ../permission/?l=' . $cLang);
			   
		$user_id = $uid; //154;//$_SESSION['user_id'];//nnull(dlookup("select id from users where [guid]='" . $uid . "'"), -1);
		$client_id = $cid;//154;// $_SESSION['client_id'];//nnull(dlookup("select id from clients where [guid]='" . $cid . "'"), -1);
				    
		$_SESSION['role_id'] = nnull(dlookup("select roleid from users where id=" . $user_id), 0 );
		
	    
?>

<body style="margin:0px 0px 0px 0px; padding:0px 0px 0px 0px" onResize="SetHeightLite()">
<div id="scrolldiv" style="width:100%; height:100%; text-align:left; background-color:#fff; overflow-y:auto; overflow-x:hidden" class="corner5">
	
<?php
		
?>

<div style="width:98%; border:1px solid #bbb; background-color:#fafafa; margin-left:1%;" class="corner5">
	<table align="center" width=90% class="text5" style="margin-top:10px; font-size: 11px;">
		<tr>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Реден број</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>ID возило</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Код</strong></td>
			<td width="300px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Регистрација</strong></td>
			<td width="300px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Клиент</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>ID Клиент</strong></td>
			<td width="50px" align="center" height="22px" class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; padding-left:7px"><strong>Бриши</strong></td>
		</tr>
	<?php
	$cnt = 1;
	$dsph = query("select distinct vehicleid, code, registration, clientname, clinetid from phoenixclients order by clientname");
	while($row = pg_fetch_array($dsph)) {
		?>
		<tr class="hov123">
			<td class="citiesin text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$cnt?></td>
			<td class="citiesin text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["vehicleid"]?></td>
			<td class="citiesin text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["code"]?></td>
			<td class="text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["registration"]?></td>
			<td class="text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["clientname"]?></td>
			<td class="text2;" align="center" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;"><?=$row["clinetid"]?></td>
			<td onclick="deleteveh('<?=$row["vehicleid"]?>')" class="text2;" align="center" style="cursor: pointer; background-color:#fff; border:1px dotted #B8B8B8; padding-left:7px;">Бриши</td>
		</tr>
		<?php
		$cnt++;
	}
	?>
	</table>
</div><br><br>
</div>
<?php


closedb();
?>
</body>
</html>
<script>
	setInterval('autoreload()', 60000);
	function autoreload(){
		<?php 
			closedb(); 
		?>
		
		location.reload();
	}
	function deleteveh(_vehid) {
		if (confirm('Are you sure?')) {
			$.ajax({url: './phoenixdel.php?vehid='+_vehid}).done(function(_data) {
				location.reload();
			})
		}
	}
</script>