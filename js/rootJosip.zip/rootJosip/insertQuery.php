<?php include "./include/db.php" ?>

<?php

	opendb();
	
	runsql("insert into querytable (datecreate, query)
	values (now(), (select current_query from pg_stat_activity where current_query <> '<IDLE>' and 
	current_query not like '%current_query%' and 
	current_query not like '%VACUUM%' and current_query <> ''))");
	
	closedb();
	
?>

