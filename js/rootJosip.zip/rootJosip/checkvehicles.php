<?php include "./include/functions.php" ?>
<?php include "./include/db.php" ?>

<?php include "./include/params.php" ?>
<?php include "./include/dictionary1.php" ?>
<?php session_start()?>
<html>
<head>
	<script>
    	var m;
		lang = '<?php echo $cLang?>';
    </script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?php echo dic("Reports.PanoramaGPS")?></title>
	<link rel="stylesheet" type="text/css" href="./style.css">  
	<script type="text/javascript" src="./js/jquery.js"></script>
	<script type="text/javascript" src="./js/jquery-ui.js"></script>	
	
</head>
	
<?php 
	opendb();
	$r = nnull(getQUERY("req"), 0);
?>

<body>
	 <div style="width: 100%; margin: 50px auto;">
		<div align="center">
			<select id="selectOpt" class="text2" style="font-size:14px" onChange="changeSelect()">
				<option value=0>-Избери-</option>
				<option value=1>Возила со ign=1, податок постар од 1h</option>
				<option value=2>Возила со податок постар од 24h</option>
			</select>
		</div>
		<br><br>
		
		<?php
		if ($r == 1) {
		?>
		<table align="center" width=920px>
			<tr>
				<td colspan=10 class="text2" style="color:#fff; font-size:14px; border:1px solid #ff6633; background-color:#f7962b; padding: 5px; padding-left: 10px ">
					<b>Возила со ign=1, податок постар од 1h</b>
				</td>
			</tr>
			<tr>
				<td width=30px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Бр.</b></td>
				<td width=116px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Возило</b></td>
				<td width=50px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>VehID</b></td>
				<td width=133px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Клиент</b></td>
				<td width=135px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Датум</b></td>
				<td width=63px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Мотор</b></td>
				<td width=62px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Статус</b></td>
				<td width=62px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Брзина</b></td>
				<td width=267px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Локација</b></td>
				<td width=2px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px">&nbsp;</td>
			</tr>
		</table>
		
		<div align="center" style="height: 500px; width:920px; overflow-y: scroll; margin:0 auto;">
			<table align="center" border="0" cellpadding="2" cellspacing="2">
				<?php
					$cnt = 1;
					$LastHour = addToDate(now(), "-1", "hour");
					$str = 'select * from currentposition where "DateTime" < \'' . $LastHour .'\' order by "DateTime" desc';
														
					$dsCurrPos = query($str);
					while ($drCurrPos = pg_fetch_array($dsCurrPos)) {
						$ign = dlookup("select coalesce((select portname from vehicleport where vehicleid=" . $drCurrPos["vehicleid"]. " and porttypeid=1), '')");
						
						if (nnull($drCurrPos["" . $ign . ""], "/") == 1) {
							$client = dlookup("select name from clients where id = (select clientid from vehicles where id=" . $drCurrPos["vehicleid"] . ")");
							$reg = dlookup("select registration from vehicles where id=" . $drCurrPos["vehicleid"]. "");
							$loc = dlookup("select getGeocode(" . $drCurrPos["latitude"] . ", " . $drCurrPos["longitude"] . ")");
					?>
					<tr>
						<td width=30px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo $cnt?>
						</td>
						<td width=105px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($reg, "/")?>
						</td>
						<td width=55px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["vehicleid"], "/")?>
						</td>
						<td width=125px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($client, "/")?>
						</td>
						<td width=125px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull(DatetimeFormat($drCurrPos["DateTime"], 'd-m-Y H:i:s'), "/")?>
						</td>
						<td width=75px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["" . $ign . ""], "/") ?>
						</td>
						<td width=75px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["status"], "/")?>
						</td>
						<td width=75px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull(intval($drCurrPos["speed"]), "/")?>
						</td>
						<td width=255px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($loc, "/")?>
						</td>
					</tr>
					<?php	
						}
						$cnt++;
					}
				?>
			</table>
		</div>
		<?php
		}
		?>
		
		
		<?php
		if ($r == 2) {
		?>
		<table align="center" width=920px>
			<tr>
				<td colspan=10 class="text2" style="color:#fff; font-size:14px; border:1px solid #ff6633; background-color:#f7962b; padding: 5px; padding-left: 10px ">
					<b>Возила со ign=1, податок постар од 1h</b>
				</td>
			</tr>
			<tr>
				<td width=30px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Бр.</b></td>
				<td width=116px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Возило</b></td>
				<td width=50px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>VehID</b></td>
				<td width=133px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Клиент</b></td>
				<td width=135px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Датум</b></td>
				<td width=63px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Мотор</b></td>
				<td width=62px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Статус</b></td>
				<td width=62px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Брзина</b></td>
				<td width=267px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px"><b>Локација</b></td>
				<td width=2px class="text2" style="background-color:#E5E3E3; border:1px dotted #2f5185; font-size:14px; padding-left: 10px">&nbsp;</td>
			</tr>
		</table>
		
		<div align="center" style="height: 500px; width:920px; overflow-y: scroll; margin:0 auto;">
			<table align="center" border="0" cellpadding="2" cellspacing="2">
				<?php
					$cnt = 1;
					$LastDay = addToDate(now(), "-1", "day");
					$str = 'select * from currentposition where "DateTime" < \'' . $LastDay .'\' order by "DateTime" desc';
															
					$dsCurrPos = query($str);
					while ($drCurrPos = pg_fetch_array($dsCurrPos)) {
						$ign = dlookup("select coalesce((select portname from vehicleport where vehicleid=" . $drCurrPos["vehicleid"]. " and porttypeid=1), '')");
						$reg = dlookup("select registration from vehicles where id=" . $drCurrPos["vehicleid"]. "");
						$loc = dlookup("select getGeocode(" . $drCurrPos["latitude"] . ", " . $drCurrPos["longitude"] . ")");
						$client = dlookup("select name from clients where id = (select clientid from vehicles where id=" . $drCurrPos["vehicleid"] . ")");
					?>
					<tr>
						<td width=30px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo $cnt?>
						</td>
						<td width=103px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($reg, "/")?>
						</td>
						<td width=55px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["vehicleid"], "/")?>
						</td>
						<td width=107px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($client, "/")?>
						</td>
						<td width=127px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull(DatetimeFormat($drCurrPos["DateTime"], 'd-m-Y H:i:s'), "/")?>
						</td>
						<td width=80px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["" . $ign . ""], "/") ?>
						</td>
						<td width=78px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($drCurrPos["status"], "/")?>
						</td>
						<td width=75px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull(intval($drCurrPos["speed"]), "/")?>
						</td>
						<td width=265px class="text2" style="background-color:#fff; border:1px dotted #B8B8B8; padding-left: 10px">
							<?php echo nnull($loc, "/")?>
						</td>
					</tr>
					<?php	
						$cnt++;
					}
				?>
			</table>
		</div>
		<?php
		}
		?>
	</div>
</body>

<?php
	closedb();
?>



<script type="text/javascript">

	document.getElementById('selectOpt').selectedIndex = '<?php echo $r?>';
	
	function changeSelect() {
		var myselect = document.getElementById("selectOpt");
 		var value = myselect.options[myselect.selectedIndex].value;
 		
 		document.location.href = "http://panorama.gps.mk/checkvehicles.php?req=" + value;
	}
	
</script>
<?php
	closedb();
?>
</html>